package com.setcount

import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

/**
  * Created by vtpl on 12/7/16.
  */
object ReadParquet {

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._


    //read data from text file
    val rdd = sparkContext.textFile("src/main/resources/data.txt")
    val ds = sparkSession.read.json("src/main/resources/people.json")

    //write in parquet and append
   ds.write.format("parquet").mode(org.apache.spark.sql.SaveMode.Append).parquet("src/main/resources/data.parquet")//.saveAsTable("parquetdataFile")
       println("dataset" + ds);

    /*    ds.write.parquet("src/main/resources/people.parquet")
    println("dataset" + ds);*/



    //read in parquet
    val parquetFile = sparkSession.read.parquet("src/main/resources/data.parquet")
    parquetFile.show()
    // Parquet files can also be used to create a temporary view and then used in SQL statements.
    parquetFile.createOrReplaceTempView("parquetdataFile")


    //search in parquet
    val teenagers = sparkSession.sql("SELECT name FROM parquetdataFile WHERE age >= 13 AND age <= 19")
    teenagers.map(t => "Name: " + t(0)).collect().foreach(println)

/*    val wordsDs = ds.flatMap(value => value.split("\\s+"))
    val wordsPairDs = wordsDs.groupByKey(value => value)
    val wordCountDs = wordsPairDs.count
    wordCountDs.show()

    ds.cache()

    val filteredDS = wordsDs.filter(value => value =="301")
    filteredDS.show()*/

  }

}

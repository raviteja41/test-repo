package com.setcount

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.expressions.{Literal, Multiply}
import org.apache.spark.sql.catalyst.plans.logical.LogicalPlan
import org.apache.spark.sql.catalyst.rules.Rule

/**
  * User Defined Optimization
  */
object CustomOptimizationExample {

  object MultiplyOptimizationRule extends Rule[LogicalPlan] {
    def apply(plan: LogicalPlan): LogicalPlan = plan transformAllExpressions {
      case Multiply(left,right) if right.isInstanceOf[Literal] &&
        right.asInstanceOf[Literal].value.asInstanceOf[Double] == 1.0 =>
        println("optimization of one applied")
        left
    }
  }


  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()


    val df = sparkSession.read.option("header","true").csv("src/main/resources/sales.csv")
    val multipliedDF = df.selectExpr("amountPaid * 1")
    println(multipliedDF.queryExecution.optimizedPlan.numberedTreeString)

    //add our custom optimization
    sparkSession.experimental.extraOptimizations = Seq(MultiplyOptimizationRule)
    val multipliedDFWithOptimization = df.selectExpr("amountPaid * 1")
    println("after optimization")

    println(multipliedDFWithOptimization.queryExecution.optimizedPlan.numberedTreeString)
  }
}


case class Claims(ClaimID:Option[String],ClaimType:Option[String],MemberStatecode:Option[String],MemberState:Option[String],
                  MemberDistrictCode:Option[String],MemberDistrict:Option[String],URN:Option[String],CardType:Option[String],PolicyNumber:Option[String],
                  CompanyCode:Option[String],CompanyName:Option[String],HeadMemberID:Option[String],HeadMemberName:Option[String],PatientID:Option[String],
                  PatientName:Option[String],PatientCardGender:Option[String],PatientCardAge:Option[String],PatientGender:Option[String],PatientAge:Option[String],
                  TerminalID:Option[String],HospitalCode:Option[String],HospitalName:Option[String],HospitalState:Option[String],HospitalDistrict:Option[String],
                  HospitalAuthorityCode:Option[String],RegistrationNo:Option[String],RegistrationDesc:Option[String],RegistrationUserDate:Option[String],RegistrationSystemDate:Option[String],
                  BlockingInvoiceNo:Option[String],BlockingUserDate:Option[String],BlockingSystemDate:Option[String],UnblockingInvoiceNo:Option[String],UnblockingDesc:Option[String],
                  UnblockingSystemDate:Option[String],DischargeInvoiceNo:Option[String],DischargeDesc:Option[String],DischargeUserDate:Option[String],DischargeSystemDate:Option[String],PackageCode:Option[String],
                  ProcedureName:Option[String],PackageCost:Option[String],NoofDays:Option[String],AmountBlocked:Option[String],NoofDaysActual:Option[String],
                  AmoutClaimed:Option[String],AvailableBalance:Option[String],PolicyStartDate:Option[String],PolicyEndDate:Option[String],BCPMode:Option[String],
                  UnspecifiedAuthCode:Option[String],UnspecifiedAuthDate:Option[String],BCPAuthorizationCode:Option[String],BCPAuthorizationDate:Option[String],FPOverideCode:Option[String],FPOverideDate:Option[String],
                  Mortality:Option[String],MortalitySummary:Option[String],CSN:Option[String],FPFailureCount:Option[String],VerifiedMemberID:Option[String],
                  Version:Option[String],Signature:Option[String],BlockCode:Option[String],BlockName:Option[String],VillageCode:Option[String],
                  VillageName:Option[String],PanchayatCode:Option[String],PanchayatTownName:Option[String],TotalAmtBlockedOnCard:Option[String],TransactionCode:Option[String],VerifiedMemberName:Option[String],
                  InsufficientBalanceAmount:Option[String],uploadDateTime:Option[String],OriginalPackageCost:Option[String],PackageName:Option[String],ProcedureCode:Option[String],
                  VidalReceivedDate:Option[String],IsOP:Option[String],transactionLevelName:Option[String],patientMobileNo:Option[String],UTRNO:Option[String],
                  UTRDate:Option[String],FloatNo:Option[String],FloatDate:Option[String],PayAmount:Option[String],PaymentStatus:Option[String],
                  ClaimStatus:Option[String],Remark:Option[String],DoctorRemarks:Option[String],DeductedAmount:Option[String],DeductedRemark:Option[String],RSBYMSBY:Option[String])
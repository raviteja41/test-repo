package com.setcount.claims

import org.apache.spark.sql.SparkSession

/**
  * Created by vtpl on 12/7/16.
  */
object ReadRule {

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._

    case class RuleData(rule_name:String,rule_description:String,columnName:String,columnValue:String,columnPosition:String,columnType:String,Operator:String)

    //read data from text file
    //val rdd = sparkContext.textFile("src/main/resources/data.txt")

    //{"ID": 1,"CLIENT_ID": 1,"PROJECT_ID": 1,"MODEL_ID": 1,"RULE_DEFINITION":[{"ruleId":1,"rule_name": "URNCheck","rule_description":"This Rule checks the URN","columnName":"URN","columnValue":"17","columnPosition":"7","columnType":"Integer","Operator":"sizeOf"},{"ruleId":2,"rule_name": "URNCheck","rule_description":"This Rule checks the URN","columnName":"URN","columnValue":"17","columnPosition":"7","columnType":"Integer","Operator":"sizeOf"}]}


    val ds = sparkSession.read.json("src/main/resources/rule.json").createOrReplaceTempView("ruledef")



  /*  val json0 = """{"name":"Ravi", "schools":[{"sname":"stanford", "year":2010}, {"sname":"berkeley", "year":2012}]}"""
    val json1 ="""{"id":1}"""
    val json2 = json0.intersect(json1)
    val json3 = json0.join(json1)*/
    val csvdata = """name,age,id"""

    val str = "this is a string"
    val rdd = sparkContext.parallelize(Seq(str))
    println("rdd----------------->"+rdd)
  //  val stringRdd = sparkContext.parallelize(Seq("hi this is my string, lets word count it"))

 //   println("json--------------->"+json2)
    sparkSession.read.json(sparkContext.parallelize(csvdata :: Nil)).createOrReplaceTempView("yes")
    val jsonstring =sparkSession.sql("SELECT * FROM yes")
    jsonstring.show()

    val anotherPeopleRDD = sparkContext.parallelize(
      """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" :: Nil)


    //val read = sparkSession.read.json(json.parallelize(json :: Nil)).registerTempTable("tmp")

    /*val inline = sparkSession.sql("SELECT inline(RULE_DEFINITION) FROM ruledef")
    val teenagers = sparkSession.sql("SELECT RULE_DEFINITION.rule_name[0] FROM ruledef WHERE RULE_DEFINITION.ruleId[0] = 1 ")
    val rulecount = sparkSession.sql("SELECT RULE_DEFINITION.ruleId FROM ruledef ")
   // inline.printSchema
    inline.show()
    teenagers.show()
    rulecount.show()
    rulecount.collect().foreach(t=>println(t))*/
    
    //ds.show()
   // var dfd=ds.select(ds("dates"))





    //val dfDates = ds.select(explode(ds("dates")))
   /* val rules = ds.select("RULE_DEFINITION").collect()

    val ruleArr = rules.map(row=>row.getSeq[org.apache.spark.sql.Row](0))



    ruleArr.foreach(rules=>{


      //var data=rules.getSeq[RuleData

      rules.map(row=>

        print("----->"+row.get(0)+"------------------------"+row.get(1)))

    })*/






    /*    //write in parquet and append
       ds.write.format("parquet").mode(org.apache.spark.sql.SaveMode.Append).parquet("src/main/resources/demo.parquet")//.saveAsTable("parquetdataFile")
           println("dataset" + ds);

        //read in parquet
        val parquetFile = sparkSession.read.parquet("src/main/resources/demo.parquet")
        parquetFile.show()
        // Parquet files can also be used to create a temporary view and then used in SQL statements.
        parquetFile.createOrReplaceTempView("parquetdataFile2")


        //search in parque
        val teenagers = sparkSession.sql("SELECT RULE_DEFINITION.ruleData[0].rule_name[0] FROM parquetdataFile2 WHERE RULE_DEFINITION.ruleId[0] = 1 ")
        teenagers.map(t => "Name: " + t(0)).collect().foreach(println)*/

/*    val wordsDs = ds.flatMap(value => value.split("\\s+"))
    val wordsPairDs = wordsDs.groupByKey(value => value)
    val wordCountDs = wordsPairDs.count
    wordCountDs.show()

    ds.cache()

    val filteredDS = wordsDs.filter(value => value =="301")
    filteredDS.show()*/

  }

}

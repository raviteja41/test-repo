package com.setcount.claims

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Time window Example
  */
object WindowExample {


  def printWindow(windowDF:DataFrame, aggCol:String) ={
    windowDF.sort("window.start").select("window.start","window.end",s"$aggCol").
      show(truncate = false)
  }

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("time window example")
      .getOrCreate()

    val schemaString="cdate,ClaimID,ClaimType,MemberStatecode,MemberState,MemberDistrictCode,MemberDistrict,URN,CardType,PolicyNumber,CompanyCode,CompanyName,HeadMemberID,HeadMemberName,PatientID,PatientName,PatientCardGender,PatientCardAge,PatientGender,PatientAge,TerminalID,HospitalCode,HospitalName,HospitalState,HospitalDistrict,HospitalAuthorityCode,RegistrationNo,RegistrationDesc,RegistrationUserDate,RegistrationSystemDate,BlockingInvoiceNo,BlockingUserDate,BlockingSystemDate,UnblockingInvoiceNo,UnblockingDesc,UnblockingSystemDate,DischargeInvoiceNo,DischargeDesc,DischargeUserDate,DischargeSystemDate,PackageCode,ProcedureName,PackageCost,NoofDays,AmountBlocked,NoofDaysActual,AmoutClaimed,AvailableBalance,PolicyStartDate,PolicyEndDate,BCPMode,UnspecifiedAuthCode,UnspecifiedAuthDate,BCPAuthorizationCode,BCPAuthorizationDate,FPOverideCode,FPOverideDate,Mortality,MortalitySummary,CSN,FPFailureCount,VerifiedMemberID,Version,Signature,BlockCode,BlockName,VillageCode,VillageName,PanchayatCode,PanchayatTownName,TotalAmtBlockedOnCard,TransactionCode,VerifiedMemberName,InsufficientBalanceAmount,uploadDateTime,OriginalPackageCost,PackageName,ProcedureCode,VidalReceivedDate,IsOP,transactionLevelName,patientMobileNo,UTRNO,UTRDate,FloatNo,FloatDate,PayAmount,PaymentStatus,ClaimStatus,Remark,DoctorRemarks,DeductedAmount,DeductedRemark,RSBY_MSBY"
    val schema =
      StructType(schemaString.split(",").map(fieldName => StructField(fieldName, StringType, true)))


    val csvDF=sparkSession.read.format("parquet").load("src/main/resources/data.parquet")
    // val csvDF=sparkSession.readStream.format("parquet").load("src/main/resources/data.parquet").schema(schema)

   /* val csvDF = sparkSession
      .readStream
      .schema(schema).parquet("src/main/resources/data.parquet")
*/
    //csvDF.show()


    val csvDF1  =  csvDF.groupBy(window(csvDF.col("cdate"),"1 minute", "10 seconds", "5 seconds")).agg(count("ClaimType").as("claims_count"))
    // val csvDF1 =  csvDF.groupBy(window(csvDF.col("cdate"),"1 minute", "10 seconds", "5 seconds"))//.select("ClaimType")//.where("signal > 10")  //.agg(count("ClaimType").as("claims_count"))
    // val csvDF1 = csvDF.select("cdate","ClaimID","ClaimType","MemberStatecode","MemberState","MemberDistrictCode","MemberDistrict","URN")

    ///csvDF1.show()

    //csvDF1.writeStream.format("console").start()

    //csvDF1.writeStream .outputMode("complete") .format("console") .start()

    /*val query= csvDF1.writeStream
      .queryName("aggregates")    // this query name will be the table name
      .outputMode("complete")
      .format("console")
      .start()

    //sparkSession.sql("select * from aggregates").show()
    // how to access to external world...
    // if it fails  the object how to recover the data

    query.awaitTermination()
*/







  }
}

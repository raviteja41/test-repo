package com.setcount.claims

import org.apache.spark.sql.SparkSession

/**
  * Created by vtpl on 12/7/16.
  */
object RuleParse {

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._

    val ds = sparkSession.read.json("src/main/resources/people.json")

    //write in parquet and append
   ds.write.format("parquet").mode(org.apache.spark.sql.SaveMode.Overwrite).parquet("src/main/resources/data.parquet")//.saveAsTable("parquetdataFile")
       println("dataset" + ds);





   /* //read in parquet
    val parquetFile = sparkSession.read.parquet("src/main/resources/data.parquet")
    parquetFile.show()
    // Parquet files can also be used to create a temporary view and then used in SQL statements.
    parquetFile.createOrReplaceTempView("parquetdataFile")


    //search in parquet
    val teenagers = sparkSession.sql("SELECT name FROM parquetdataFile WHERE age >= 13 AND age <= 19")
    teenagers.map(t => "Name: " + t(0)).collect().foreach(println)
*/


  }

}

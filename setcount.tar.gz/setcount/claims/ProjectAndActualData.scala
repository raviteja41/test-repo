package com.setcount.claims

import org.apache.spark
import org.apache.spark.SparkContext
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.collection.mutable
import scala.util.parsing.json.JSONObject

/**
  * Created by vtpl on 12/7/16.
  */
object ProjectAndActualData {

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext


    //val schemaString = "cdate,cid,pid,mid,eid,ClaimID,ClaimType,MemberStatecode,MemberState,MemberDistrictCode,MemberDistrict,URN,CardType,PolicyNumber,CompanyCode,CompanyName,HeadMemberID,HeadMemberName,PatientID,PatientName,PatientCardGender,PatientCardAge,PatientGender,PatientAge,TerminalID,HospitalCode,HospitalName,HospitalState,HospitalDistrict,HospitalAuthorityCode,RegistrationNo,RegistrationDesc,RegistrationUserDate,RegistrationSystemDate,BlockingInvoiceNo,BlockingUserDate,BlockingSystemDate,UnblockingInvoiceNo,UnblockingDesc,UnblockingSystemDate,DischargeInvoiceNo,DischargeDesc,DischargeUserDate,DischargeSystemDate,PackageCode,ProcedureName,PackageCost,NoofDays,AmountBlocked,NoofDaysActual,AmoutClaimed,AvailableBalance,PolicyStartDate,PolicyEndDate,BCPMode,UnspecifiedAuthCode,UnspecifiedAuthDate,BCPAuthorizationCode,BCPAuthorizationDate,FPOverideCode,FPOverideDate,Mortality,MortalitySummary,CSN,FPFailureCount,VerifiedMemberID,Version,Signature,BlockCode,BlockName,VillageCode,VillageName,PanchayatCode,PanchayatTownName,TotalAmtBlockedOnCard,TransactionCode,VerifiedMemberName,InsufficientBalanceAmount,uploadDateTime,OriginalPackageCost,PackageName,ProcedureCode,VidalReceivedDate,IsOP,transactionLevelName,patientMobileNo,UTRNO,UTRDate,FloatNo,FloatDate,PayAmount,PaymentStatus,ClaimStatus,Remark,DoctorRemarks,DeductedAmount,DeductedRemark,RSBY_MSBY"

    val schemaString1 = "cid,pid,mid"
    val schema =
      StructType(schemaString1.split(",").map(fieldName => StructField(fieldName, StringType, true)))
    val modelData  = """{"projectData":["2015-01-01 12:01:00,CID101,PID111,MID123,EID001"],"actualData":["VD1469102,Native,22,CHHATTISGARH,19,Bemetara,22190400112398100460100"]}"""

    val modelData1="""{"cid":1}"""
    val  actualdf1= sparkSession.read.json(sparkContext.parallelize(modelData1 :: Nil))
    actualdf1.show()
    actualdf1.select("cid").collect().foreach(cd=>println(cd))
   // println(convertWrapperArrytoString(actualData1))
   /* val  actualdf= sparkSession.read.json(sparkContext.parallelize(modelData :: Nil))
    actualdf.show()
    val actualData = actualdf.select("actualData").collect()
   // val testData = actualdf.select("actualData","projectData").collect()

    val projectData = actualdf.select("projectData").collect()

    println(convertWrapperArrytoString(projectData)+","+convertWrapperArrytoString(actualData))*/
     val rowdatavalue = "1,2,3"
    convertStringToDataframe(sparkSession,rowdatavalue,schema)
    val pdata=rowdatavalue.split(",")
    val data= Row.fromSeq(pdata.toSeq)
    val dataRDD = sparkSession.sparkContext.makeRDD(Seq(data))
    val claimsdf=sparkSession.createDataFrame(dataRDD, schema)
    val claimdata = claimsdf.select("cid").show()
    claimsdf.show()
    //claimsdf.show()

    //val data1:JavaRDD[Char] =   sparkContext.parallelize(data).toJavaRDD()
   // val claimsdf=sparkSession.createDataFrame(data1, schema)
    //.foreach(cd=>println(cd))
    //println(data1)



    /*val model =sparkSession.sql("SELECT * FROM modelData")
    model.show()*/

  /*val actualdf = sparkContext.parallelize(
    newdata :: Nil)
    val actualdf1 = sparkSession.read.json(actualdf)
    actualdf1.show()*/
    //actualdf1.write.format("parquet").mode(org.apache.spark.sql.SaveMode.Append).parquet("src/main/resources/actual.parquet")//.saveAsTable("parquetdataFile")



  /*  val csvDF = sparkSession
        .readStream.format("json")
        .parquet("src/main/resources/actual.parquet")

    val claimyearly = csvDF.groupBy("actualData.ClaimID")
      .agg(count("actualData.ClaimType").as("countClaim10"))


    val query= claimyearly
      .writeStream
      .outputMode("complete")
      .format("console")
      .start()

    query.awaitTermination()*/
   /* csvDF.show()

    csvDF.createOrReplaceTempView("parquetdataFile")


    //search in parquet
    val teenagers = sparkSession.sql("SELECT actualData.ClaimID FROM parquetdataFile")
    teenagers.show()*/



/*    val modeldf = sparkContext.parallelize(
      modelData :: Nil)
    val modeldf1 = sparkSession.read.json(modeldf)
    modeldf1.show()*/




/*    sparkSession.read.json(sparkContext.parallelize(modelData :: Nil)).createOrReplaceTempView("modelData")
    val model =sparkSession.sql("SELECT * FROM modelData")
    model.show()*/



  }

  def convertStringToJson(sparkSession:SparkSession,sparkContext:SparkContext,dataValue:String): DataFrame = {
     sparkSession.read.json(sparkContext.parallelize(dataValue :: Nil))
  }

  def convertStringToDataframe(sparkSession:SparkSession,dataValue:String,schemaType:StructType): DataFrame = {
       sparkSession.createDataFrame(sparkSession.sparkContext.makeRDD(Seq(Row.fromSeq(dataValue.split(",").toSeq))), schemaType)
  }


  def convertWrapperArrytoString(data:Array[Row]): String = {
    var t1 = ""
    data.foreach(cd => {
      t1 = cd.getList(0).get(0)
    })
    t1
  }

}

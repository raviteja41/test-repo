package com.setcount.claims

import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.json4s.jackson.Json


import scala.io.BufferedSource

/**
  * Created by vtpl on 15/7/16.
  */
object ReadDatawindow {

  val sparkSession = SparkSession.builder.
    master("local")
    .appName("example")
    .getOrCreate()

  val sparkContext = sparkSession.sparkContext

  def readFile(fileToRead:String):BufferedSource={
    scala.io.Source.fromFile(fileToRead)
  }

  def readFileFormSource(){



    for (line <- readFile("src/main/resources/claimfinal.csv").getLines()) {

      convertToDF(line)

      Thread.sleep(10000)

    }


  }

  def convertToDF(rowData1:String){

    // val rowData1="VD1469102,Native,22,CHHATTISGARH,19,Bemetara,22190400112398100,,46010034141700000000,5,THE NEW INDIA ASSURANCE CO. LTD,1,UBHAY RAM,4,SHATRUPA,Female,32,Female,27,12345,22019002,District Hospital  Bemeta,CHHATTISGARH,Bemetara,CG190040,3001510201522020000000,ctt,13/10/2015 10:46:43,15/10/2015 10:47:11,30115102015220200000000,13/10/2015 10:48:53,15/10/2015 10:49:22,,,,3031510201522020000000,ctt,15/10/2015 12:23:21,21/10/2015 12:25:05,34,GYNAECOLOGY,2625,2,2625,2,2625,27375,01 Jan 2015,31 Dec 2015,N,,,,,,,N,,06001B0F100200000001564823622371,1,3,Version:2.6.0.4 Released On:17/01/2014,,4,Berla,1122500,Kharra,1270,Kharra,2625,303ABC,BALRAM,0,21/10/2015 12:55:16,2625,Conventional Tubectomy,6,21/10/2015 12:55:16,False,Approved,,,,,,2625,,Approved,,Approved,0,,MSBY"
    val schemaString="ClaimID,ClaimType,MemberStatecode,MemberState,MemberDistrictCode,MemberDistrict,URN,CardType,PolicyNumber,CompanyCode,CompanyName,HeadMemberID,HeadMemberName,PatientID,PatientName,PatientCardGender,PatientCardAge,PatientGender,PatientAge,TerminalID,HospitalCode,HospitalName,HospitalState,HospitalDistrict,HospitalAuthorityCode,RegistrationNo,RegistrationDesc,RegistrationUserDate,RegistrationSystemDate,BlockingInvoiceNo,BlockingUserDate,BlockingSystemDate,UnblockingInvoiceNo,UnblockingDesc,UnblockingSystemDate,DischargeInvoiceNo,DischargeDesc,DischargeUserDate,DischargeSystemDate,PackageCode,ProcedureName,PackageCost,NoofDays,AmountBlocked,NoofDaysActual,AmoutClaimed,AvailableBalance,PolicyStartDate,PolicyEndDate,BCPMode,UnspecifiedAuthCode,UnspecifiedAuthDate,BCPAuthorizationCode,BCPAuthorizationDate,FPOverideCode,FPOverideDate,Mortality,MortalitySummary,CSN,FPFailureCount,VerifiedMemberID,Version,Signature,BlockCode,BlockName,VillageCode,VillageName,PanchayatCode,PanchayatTownName,TotalAmtBlockedOnCard,TransactionCode,VerifiedMemberName,InsufficientBalanceAmount,uploadDateTime,OriginalPackageCost,PackageName,ProcedureCode,VidalReceivedDate,IsOP,transactionLevelName,patientMobileNo,UTRNO,UTRDate,FloatNo,FloatDate,PayAmount,PaymentStatus,ClaimStatus,Remark,DoctorRemarks,DeductedAmount,DeductedRemark,RSBY_MSBY"

      // Import Row.
      import org.apache.spark.sql.Row;

      // Import Spark SQL data types
      import org.apache.spark.sql.types.{StructType,StructField,StringType};


      println("schemaString.split(,)----->"+schemaString.split(",").length)
      // Generate the schema based on the string of schema
      val schema =
      StructType(
      schemaString.split(",").map(fieldName => StructField(fieldName, StringType, true)))


      println("rowData1.split(,)----->"+rowData1.split(",").length)

      val pdata=rowData1.split(",")
      val rowRDD= Row(pdata(0),pdata(1),pdata(2),pdata(3),pdata(4),pdata(5),pdata(6),pdata(7),pdata(8),pdata(9),pdata(10), pdata(11),pdata(12),
      pdata(13),pdata(14),pdata(15),pdata(16),pdata(17),pdata(18),pdata(19),pdata(20), pdata(21),pdata(22),pdata(23),pdata(24),pdata(25),pdata(26),pdata(27),pdata(28),pdata(29),pdata(30),
      pdata(31),pdata(32),pdata(33),pdata(34),pdata(35),pdata(36),pdata(37),pdata(38),pdata(39),pdata(40),pdata(41),pdata(42),pdata(43),pdata(44),pdata(45),pdata(46),pdata(47),pdata(48),
      pdata(49),pdata(50),pdata(51),pdata(52),pdata(53),pdata(54),pdata(55),pdata(56),pdata(57),pdata(58),pdata(59),pdata(60),pdata(61),pdata(62),pdata(63),pdata(64),pdata(65),
      pdata(66),pdata(67),pdata(68),pdata(69),pdata(70),pdata(71),pdata(72),pdata(73),pdata(74),pdata(75),pdata(76),pdata(77),pdata(78),pdata(79),pdata(80),pdata(81),pdata(82),
      pdata(83),pdata(84),pdata(85),pdata(86),pdata(87),pdata(88),pdata(89),pdata(90),pdata(91),pdata(92))
      // Convert records of the RDD (people) to Rows.
      /*val rowRDD = rowData1.split(",").map(pdata => Row(pdata(0),pdata(1),pdata(2),pdata(3),pdata(4),pdata(5),pdata(6),pdata(7),pdata(8),pdata(9),pdata(10), pdata(11),pdata(12),
          pdata(13),pdata(14),pdata(15),pdata(16),pdata(17),pdata(18),pdata(19),pdata(20), pdata(21),pdata(22),pdata(23),pdata(24),pdata(25),pdata(26),pdata(27),pdata(28),pdata(29),pdata(30),
          pdata(31),pdata(32),pdata(33),pdata(34),pdata(35),pdata(36),pdata(37),pdata(38),pdata(39),pdata(40),pdata(41),pdata(42),pdata(43),pdata(44),pdata(45),pdata(46),pdata(47),pdata(48),
          pdata(49),pdata(50),pdata(51),pdata(52),pdata(53),pdata(54),pdata(55),pdata(56),pdata(57),pdata(58),pdata(59),pdata(60),pdata(61),pdata(62),pdata(63),pdata(64),pdata(65),
          pdata(66),pdata(67),pdata(68),pdata(69),pdata(70),pdata(71),pdata(72),pdata(73),pdata(74),pdata(75),pdata(76),pdata(77),pdata(78),pdata(79),pdata(80),pdata(81),pdata(82),
          pdata(83),pdata(84),pdata(85),pdata(86),pdata(87),pdata(88),pdata(89),pdata(90),pdata(91),pdata(92)))*/
      val dataRDD = sparkSession.sparkContext.makeRDD(Seq(rowRDD))
      val claimsdf=sparkSession.createDataFrame(dataRDD, schema)
      println(claimsdf)


      claimsdf.write.format("parquet").mode(org.apache.spark.sql.SaveMode.Append).parquet("src/main/resources/claimsdata.parquet")
      val parquetFile=sparkSession.read.parquet("src/main/resources/claimsdata.parquet")
      parquetFile.show();
      println(parquetFile)
    val filterdata =  parquetFile.filter("ClaimType = 'Native'")
    println("filter data ---------------------------------> table")
    filterdata.show();

    val claimswindow = filterdata.groupBy(window(parquetFile.col("RegistrationUserDate"),"1 day","5 seconds"))
      .agg(count("ClaimType").as("claim_Average"))
    println("claim_Average ----------------------------------------->")
    printWindow(claimswindow,"claim_Average")

           /*  for (parquetclaims <- sparkSession.read.parquet("src/main/resources/data.parquet") {
                //Thread.sleep(1000)
                 writingToWindow(parquetclaims)
               // writingToWindow(parquetclaims)


             }*/
      //parquetFile  df.select("name").show()

      //parquetFile.createOrReplaceTempView("parquetTable")
      // val claimsId =sparksession.sql("SELECT ClaimType FROM parquetTable where ClaimID = 'VD1469102' ")
      // println("-------------------------------------------------------------------")
      // println("-------------------------------------------------------------------"+parquetFile.select("ClaimType").show())
      //println("-------------------------------------------------------------------")
      }

  def printWindow(windowDF:DataFrame, aggCol:String) ={
    windowDF.sort("window.start").select("window.start","window.end",s"$aggCol").
      show(truncate = false)
  }
 /* def writingToWindow(claims:Dataset[Clai]){


    val filterdata =  claims.filter("cliamType = 'Native'")
    println("filter data ---------------------------------> table")
    filterdata.show();

    val claimswindow = filterdata.groupBy(window(filterdata.col("RegistrationUserDate"),"10 seconds","5 seconds"))
      .agg(avg("claimType").as("claim_Average"))
    println("claim_Average ----------------------------------------->")
    printWindow(claimswindow,"claim_Average")

  }*/


    def main(args: Array[String]) {
      // SparkConf conf = new SparkConf().setAppName("Log Analyzer Streaming SQL");
      readFileFormSource()
    }

}

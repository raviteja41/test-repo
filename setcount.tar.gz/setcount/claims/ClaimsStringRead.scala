package com.setcount.claims

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.json4s.jackson.Json
/**
  * Created by vtpl on 13/7/16.
  */
object ClaimsStringRead {


case class Claim(ClaimID:Option[String],ClaimType:Option[String],MemberStatecode:Option[String],MemberState:Option[String],
                      MemberDistrictCode:Option[String],MemberDistrict:Option[String],URN:Option[String])


  def printWindow(windowDF:DataFrame, aggCol:String) ={
    windowDF.sort("window.start").select("window.start","window.end",s"$aggCol").
      show(truncate = false)
  }

  def main(args: Array[String]) {


   val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._



    //val str ="VD1469102,Native,22,CHHATTISGARH,19,Bemetara,22190400112398100"


    case class Obs(f1: Double, f2: Double, price: Array[String])

    val obs1 = new Obs(1,2,Array("USD", "5.00"))
    val obs2 = new Obs(2,1,Array("USD", "3.00"))

    val df = sparkSession.sparkContext.parallelize(Seq(obs1,obs2)).take(1).toString()
    println(df)
    df.length()
    //df.printSchema
    //df.show()


    //val ds = sparkSession.read.option("header", "true").option("inferSchema", "true").csv("src/main/resources/claims.csv").as[Claim]
    //val newRow = sparkSession.sparkContext.parallelize(Seq(str)).toDF(ds.columns: _*)
    //newRow.rdd
    //ds.show()

   /* val dsjson=ds.toJSON.take(1)
    ds.toJSON.take(5).foreach(println)

    val selectedDS = ds.map(_.ClaimID)

    val stocks2016 = ds.filter("ClaimType=='Native'")
    stocks2016.show()

    val tumblingWindowDS = stocks2016.groupBy(window(stocks2016.col("Date"),"1 days"))
      .agg(count("ClaimType").as("ClaimType_average"))
    println("ClaimType")
    printWindow(tumblingWindowDS,"ClaimType_average")

    println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)*/

  }





}

package com.setcount.claims

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.json4s.jackson.Json

import scala.io.Source

/**
  * Created by vtpl on 13/7/16.
  */
object ClaimsRead {


 /* case class Claim(ClaimID:Option[String],ClaimType:Option[String],MemberStatecode:Option[String],MemberState:Option[String],
                      MemberDistrictCode:Option[String],MemberDistrict:Option[String],URN:Option[String])


  def printWindow(windowDF:DataFrame, aggCol:String) ={
    windowDF.sort("window.start").select("window.start","window.end",s"$aggCol").
      show(truncate = false)
  }

  def main(args: Array[String]) {
    convertToDataset()

 /*   val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._


    val ds = sparkSession.read.option("header", "true").option("inferSchema", "true").csv("src/main/resources/stock.csv").as[Claim]

    val dsjson=ds.toJSON.take(1)
    ds.toJSON.take(5).foreach(println)

    val selectedDS = ds.map(_.ClaimID)

    val stocks2016 = ds.filter("ClaimType=='Native'")
    stocks2016.show()

    val tumblingWindowDS = stocks2016.groupBy(window(stocks2016.col("Date"),"1 days"))
      .agg(count("ClaimType").as("ClaimType_average"))
    println("ClaimType")
    printWindow(tumblingWindowDS,"ClaimType_average")

    println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)*/

  }


  def readfile(): Unit ={
    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sc = sparkSession.sparkContext
    import sparkSession.implicits._
    val rdd = sc.textFile("src/main/resources/stock.csv")
    //rdd.map(va=>println(va))

   // val sc: SparkContext // An existing SparkContext.
    //val sqlContext = sparkSession



    // rdd.flatMap(value => println(value))
  }

  def convertToDataset(): Unit ={

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._

    val ds:Dataset[Claim] = sparkSession.read.option("header", "true").option("inferSchema", "true").csv("src/main/resources/stock.csv").as[Claim]

    var dsjson=ds
    println("count------>"+dsjson.count())
    addingToWindow(dsjson)


    var data="2016-04-20,VD1469102,Native,22,CHHATTISGARH,19,Bemetara,22190400112398100,VD1469102,,22,CHHATTISGARH,19,Bemetara,22190400112398100"

    sparkSession.cre


    //Thread.sleep(1000)
    // dsjson=ds.toJSON.take(2)
    addingToWindow(dsjson)

    Thread.sleep(1000)

    //dsjson=ds.toJSON.take(3)
    addingToWindow(dsjson)

    Thread.sleep(1000)
   // dsjson=ds.toJSON.take(4)
    addingToWindow(dsjson)


    //sparkContext.parallelize(Seq(dsjson))

   // val jsonRDD = dsjson.map(x => x._2)


    //for (line <- dsjson.map()) {
     // var ds:Dataset[Claim]=line
     // println("line---"+line)


     // val ds=sparkSession.createDataset(line,Claim)
   //  addingToWindow(line)
    //}


    //Dataset<String> ds = context.createDataset(data, Encoders.STRING());
   // ds.toJSON.take(5).foreach(println)

  //  val ds=sparkContext.createDataset(data, Encoders.STRING());



  }


  def addingToWindow(dset: Dataset[Claim]): Unit ={

  // val selectedDS = dataset.map(_.ClaimID)

println("first record addingToWindow----"+dset.count())
    val stocks2016 = dset.filter("ClaimType=='Native'")
    stocks2016.show()

    val tumblingWindowDS = stocks2016.groupBy(window(stocks2016.col("Date"),"1 days")).agg(count("ClaimType").as("ClaimType_average"))
    println("ClaimType")
    printWindow(tumblingWindowDS,"ClaimType_average")

   // println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)


  }


*/



}

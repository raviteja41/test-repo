package com.setcount.claims

import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SQLContext, SparkSession}

/**
  * RDD API to Dataset API
  */
object rddclaims {


 case class Claim(ClaimID:Option[String],ClaimType:Option[String],MemberStatecode:Option[String],MemberState:Option[String],
                  MemberDistrictCode:Option[String],MemberDistrict:Option[String],URN:Option[String])

  case class Sales(transactionId:Int,customerId:Int,itemId:Int,amountPaid:Double)
  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._
    val sqlContext = new SQLContext(sparkContext)

    //read data from text file
    val rdd = sparkContext.textFile("src/main/resources/data.txt")
    val df = sqlContext.read.format("com.databricks.spark.csv").option("header","true").load("src/main/resources/stock.csv")
    //val ds =  sparkSession.read.text("src/main/resources/data.txt").as[String]


    val wordsRDD = rdd.flatMap(value => value.split("\\s+"))
    val wordsPair = wordsRDD.map(word => (word,1))
    val wordCount = wordsPair.reduceByKey(_+_)
    println(wordsPair.collect.toList)
    println(wordCount.collect.toList)


    val rddStringToRowRDD = rdd.map(value => Row(value))
    val dfschema = StructType(Array(StructField("value",StringType)))
    val rddToDF = sparkSession.createDataFrame(rddStringToRowRDD,dfschema)
    //rddToDF
    val rDDToDataSet = rddToDF.as[String]
    rDDToDataSet.show()

  }

}

package com.setcount.claims


import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.json4s.jackson.Json

import scala.io.Source
/**
  * Created by vtpl on 13/7/16.
  */
object ClaimsWindow {


case class Claim(Date:Option[String],ClaimID:Option[String],ClaimType:Option[String],MemberStatecode:Option[String],MemberState:Option[String],
                      MemberDistrictCode:Option[String],MemberDistrict:Option[String],URN:Option[String])


  def printWindow(windowDF:DataFrame, aggCol:String) ={
    windowDF.sort("window.start").select("window.start","window.end",s"$aggCol").
      show(truncate = false)
  }

  def main(args: Array[String]) {
   // SparkConf conf = new SparkConf().setAppName("Log Analyzer Streaming SQL");

 val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
/*    val streamingContext = streamingContext(sparkContext,SLIDE_INTERVAL)
    val sQLContext = sQLContext(sparkContext)

    // Start the streaming server.
    streamingContext.start();              // Start the computation
    streamingContext.awaitTermination();   // Wait for the computation to terminate*/
    import sparkSession.implicits._


     val ds = sparkSession.read.option("header", "true").option("inferSchema", "true").csv("src/main/resources/stock.csv").as[Claim]

    val dsjson=ds.toJSON.take(1)
    ds.toJSON.take(5).foreach(println)


    val selectedDS = ds.map(_.ClaimID)

    val stocks2016 = ds.filter("ClaimType=='Native'")
    stocks2016.show()

    val tumblingWindowDS = stocks2016.groupBy(window(ds.col("Date"),"1 days"))
      .agg(count("ClaimType").as("ClaimType_daily"))
    println("ClaimType")
    printWindow(tumblingWindowDS,"ClaimType_daily")

    val tumblingWindowDSweek = stocks2016.groupBy(window(stocks2016.col("Date"),"1 week", "1 seconds"))
      .agg(count("ClaimType").as("ClaimType_weekly"))
    println("ClaimType")
    printWindow(tumblingWindowDSweek,"ClaimType_weekly")



    println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)

  }


}

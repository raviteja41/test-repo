package com.setcount

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType

/**
  * Logical Plans for Dataframe and Dataset
  */
object DatasetVsDataFrame {

  case class Sales(transactionId:Int,customerId:Int,itemId:Int,amountPaid:Double)

  def main(args: Array[String]) {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()

    val sparkContext = sparkSession.sparkContext
    import sparkSession.implicits._

    val socketDF = sparkSession
      .readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 4040)
      .load()

    socketDF.isStreaming    // Returns True for DataFrames that have streaming sources

    socketDF.printSchema

    val userSchema = new StructType().add("name", "string").add("age", "integer")



    val csvDF = sparkSession
      .readStream
      .option("sep", ";")
      .schema(userSchema)      // Specify schema of the parquet files
      .csv("src/main/resources/sales.csv")    // Equivalent to format("csv").load("/path/to/directory")

    //read data from text file

    val df = sparkSession.read.option("header","true").option("inferSchema","true").csv("src/main/resources/sales.csv")
    val ds = sparkSession.read.option("header","true").option("inferSchema","true").csv("src/main/resources/sales.csv").as[Sales]
    sparkSession.readStream.format("")


    ds.toJSON.take(3).foreach(println)

    val selectedDF = df.select("itemId")

    val selectedDS = ds.map(_.itemId)

    println(selectedDF.queryExecution.optimizedPlan.numberedTreeString)

    println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)


  }

}

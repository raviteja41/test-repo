package com.setcount

import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.joda.time.DateTime

/**
  * RDD API to Dataset API
  */
object Stream {

 case class Sales(transactionId:Int,customerId:Int,itemId:Int,amountPaid:Double)



 def main(args: Array[String]) {

  val sparkSession = SparkSession.builder.
    master("local")
    .appName("example")
    .getOrCreate()

  val sparkContext = sparkSession.sparkContext
  import sparkSession.implicits._

  val socketDF = sparkSession
    .readStream
    .format("socket")
    .option("host", "localhost")
    .option("port", 4040)
    .load()

  socketDF.isStreaming    // Returns True for DataFrames that have streaming sources

  socketDF.printSchema

  val userSchema = new StructType().add("transactionId", "Int").add("customerId", "Int").add("itemId", "Int").add("amountPaid", "Int")
  val csvDF = sparkSession
    .readStream
    .option("sep", ";")
    .schema(userSchema)      // Specify schema of the parquet files
    .csv("src/main/resources/sales.csv")    // Equivalent to format("csv").load("/path/to/directory")

  println(csvDF)
  //csvDF.writeStream.start("src/main/resources/salesbackup.csv");

  //read data from text file

  /* val df = sparkSession.read.option("header","true").option("inferSchema","true").csv("src/main/resources/sales.csv")
   val ds = sparkSession.read.option("header","true").option("inferSchema","true").csv("src/main/resources/sales.csv").as[Sales]
   ds.toJSON.take(3).foreach(println)

   val selectedDF = df.select("itemId")

   val selectedDS = ds.map(_.itemId)

   println(selectedDF.queryExecution.optimizedPlan.numberedTreeString)

   println(selectedDS.queryExecution.optimizedPlan.numberedTreeString)*/


 }

}

1.export: 

mongodump -d databasename

2.scp'd my dump to my server machine:

scp -r dump user@xx.xxx.xxx.xxx:~

3.import: 

mongorestore 



*********************************888


truncate table

db.employeeInfo.drop()
db.collectionName.drop()

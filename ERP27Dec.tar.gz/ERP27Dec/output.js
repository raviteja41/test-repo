MongoDB shell version v3.4.0
connecting to: mongodb://127.0.0.1:27017/crm
MongoDB server version: 3.4.0
[ ]

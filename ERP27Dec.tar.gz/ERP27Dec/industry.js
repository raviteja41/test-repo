

db.industry.insert([
{"industryId": "01", "type": "INDUSTRY", "name": "Hospital", "value": "Hospital", "relation":"0"},
{"industryId": "02", "type": "INDUSTRY", "name": "Education", "value": "Education", "relation":"0"},
{"industryId": "03", "type": "INDUSTRY", "name": "Retail", "value": "Retail", "relation":"0"},
{"industryId": "04", "type": "INDUSTRY", "name": "Goverment", "value": "Goverment", "relation":"0"},
{"industryId": "05", "type": "INDUSTRY", "name": "MANUFACTURING", "value": "MANUFACTURING", "relation":"0"}
]);


db.menu.insert([
{"clientId":"0","industryId":"0","menuIcon":"dashboard",
"menuName":"clients","menuUrl":"app.viewClient","role":"ROLE_SADMIN",
"menuType":"parent","relationId":0.0,"sequenceId":1.0,"ischild":0.0},

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Role Mapping",
"menuUrl":"app.roleMapping","role":"ROLE_CLIENTADMIN",
"menuType":"parent","relationId":0.0,"sequenceId":2.0,"ischild":0.0},

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Users Management",
"menuUrl":"","role":"ROLE_CLIENTADMIN","menuType":"parent",
"relationId":10002,"sequenceId":3.0,"ischild":1.0},

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Doctors",
"menuUrl":"app.viewDoctor","role":"ROLE_CLIENTADMIN","menuType":"parent",
"relationId":0.0,"sequenceId":4.0,"ischild":0.0},

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Create Users",
"menuUrl":"app.viewUser","role":"ROLE_CLIENTADMIN",
"menuType":"child","relationId":"10002","sequenceId":3.1},

{"clientId" : "0", "industryId" : "0", "menuIcon" : "dashboard", "menuName" : "Dashboard", "menuUrl" : "app.employeeDashboard", "role" : "ROLE_LEVEL1", "menuType" : "parent", "relationId" : 0, "sequenceId" :8 , "ischild" : 0 },

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Master Data",
"menuUrl":"","role":"ROLE_LEVEL1","menuType":"parent",
"relationId":10002,"sequenceId":1.0,"ischild":1.0},

{"clientId":"0","industryId":"0","menuIcon":"dashboard","menuName":"Employee",
"menuUrl":"app.employee","role":"ROLE_LEVEL1","menuType":"child",
"relationId":10002,"sequenceId":1.1}
]);


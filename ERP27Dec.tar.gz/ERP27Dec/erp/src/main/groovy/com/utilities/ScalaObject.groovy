package com.utilities

class MongoDbConnection {

  def test(){
  	println "testing"
  }

}
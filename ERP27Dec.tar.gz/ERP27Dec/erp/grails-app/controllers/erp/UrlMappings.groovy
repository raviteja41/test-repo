package erp

class UrlMappings {

    static mappings = {
        delete "/$controller/$id(.$format)?"(action:"delete")
        get "/$controller(.$format)?"(action:"index")
        get "/$controller/$id(.$format)?"(action:"show")
        post "/$controller(.$format)?"(action:"save")
        put "/$controller/$id(.$format)?"(action:"update")
        patch "/$controller/$id(.$format)?"(action:"patch")


        //page load
        "/index"(view: '/index')
        "/"(view: '/home')
        "/login/auth"(controller: 'login', action: 'auth')
        "/login/authenticate"(controller: 'login', action: 'authenticate')

        //Doctor
        "/saveDoctorData" (controller: 'DB', action: 'insert')
        "/allDoctors"(controller:'DB', action:'findAll')
        "/editDoctors"(controller:'DB', action:'find')
        "/saveDoctorEducationData" (controller: 'DB', action: 'update')
        "/editDoctorsEducation"(controller:'DB',action:'findChildCollection')
        "/saveEditDoctorData"(controller:'DB',action:'updateChildCollection')      
        "/deleteDoctor"(controller:'DB',action:'removeChildCollection')


        // BDE's url mapping
        "/saveBdeData" (controller: 'DB', action: 'insert')
        "/allBdes"(controller:'DB', action:'findAll')
        "/editBdes"(controller:'DB', action:'find')
        "/saveBdeEducationData" (controller: 'DB', action: 'update')
        "/editBdesEducation"(controller:'DB',action:'findChildCollection')
        "/saveEditBdeData"(controller:'DB',action:'updateChildCollection')
        "/deleteBde"(controller:'DB',action:'removeChildCollection')
       

        //lookup
        "/lookUpData" (controller: 'DB', action: 'lookUpData') 
        
        //menu
        "/menuData"(controller:'DB',action:'findMenu')

        //client
        "/saveClientData" (controller: 'DB', action: 'saveClient') 
        "/deleteClient"(controller:'DB',action:'removeClient')
        "/findClient"(controller:'DB', action:'find')
        "/allClient"(controller:'DB', action:'findIsActive')


        //upload
        "/fileUpload"(controller: 'DB', action: 'fileUpload')
        "/saveImage"(controller:'DB', action:'saveImage')
        "/userfileUpload"(controller: 'DB', action: 'userfileUpload')

        
        //Role mapping
        "/saveRoleMapping"(controller:'DB', action:'insertRolemapping')
        "/findData"(controller:'DB', action:'findData')
        "/deleteData"(controller:'DB', action:'deleteData')
        "/findAllRoles"(controller:'DB',action:'findRoleMappingData')
        
        //user
       "/insertUser" (controller: 'DB', action: 'insertUser') 
        "/editUsers"(controller:'DB', action:'find')
        "/allUsers"(controller:'DB', action:'findAll') 
        "/saveUserUpdatedData" (controller: 'DB', action: 'update')
        "/editUsersChildCollection"(controller:'DB',action:'findChildCollection')
        "/updateUsersChildCollection"(controller:'DB',action:'updateChildCollection')      
        "/deleteUsers"(controller:'DB',action:'removeChildCollection')

        "/profileEdit"(controller:'DB', action:'findById')

   //Employee Information
     //lic
 
        "/saveData"(controller:'DB',action:'saveData')
        "/getChildData"(controller:'DB',action:'getChildData')
        "/updateLicData"(controller:'DB',action:'updateChildCollection')
     "/findAllData"(controller:'DB', action:'findAllData')


  //family
         "/saveFamilyData"(controller: 'DB', action: 'saveData') 
         "/findFamily"(controller:'DB', action:'find')  
          "/deleteFamily"(controller:'DB',action:'removeChildCollection')            
         "/allFamily"(controller:'DB', action:'findIsActive')
         "/loadFamilyData"(controller:'DB', action:'getChildData')
 "/updatefamilyData"(controller:'DB', action:'updateChildCollection')

//Employee Education

  "/saveEmployee" (controller: 'DB', action: 'saveData')

//CONTACT
 "/updateChildData" (controller: 'DB', action: 'updateChildCollection')
"/saveJobDetailsData"(controller:'DB',action:'insertJobDetails')
        //on error
        "500"(view: '/error')
        "404"(view: '/notFound')
    }
}

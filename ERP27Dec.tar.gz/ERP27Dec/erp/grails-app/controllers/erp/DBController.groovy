/*
CreatedBy:CRM Team.
Purpose:To Establish connection with MongoDB and to
        Perform CRUD Operations.
*/
package erp
import erp.User
import erp.Role    

import erp.UserRole
import com.mongodb.BasicDBObject
import com.mongodb.MongoClient
import org.bson.types.ObjectId
import grails.rest.*
import grails.converters.*
import groovy.json.JsonOutput
import groovy.json.*
import org.springframework.web.multipart.MultipartFile
import org.springframework.web.multipart.MultipartHttpServletRequest

class DBController {

  static responseFormats = ['json', 'xml']
    
  def mongoService    //including Mongo service 

  def service = new MongoService()
    
  
  def test() {
       def userRecord= User.findByUsername(principal.username)
      def roleInfo = Role.findByAuthority(userRecord.authorities)
      render "ok"
  }
  
 /*
 CreatedBy:CRM Team.
 Purpose:To Perform Insert And Update Operation.
*/



def  insertJobDetails(){ 

  def userRecord= User.findByUsername(principal.username)
  def uName=userRecord.username
  def modelData = request.JSON.model
  Date date = new Date();
  def collectionName = request.JSON.cName
  def id = request.JSON.id
  def childCollectionName=request.JSON.childColName
  def col = service.collection(collectionName)
    modelData.put("updatedBy",uName)
    modelData.put("updatedOn",date.toString())
  if (id == 0 ) {
    modelData.put("createdBy",uName)
    modelData.put("createdOn",date.toString())
    modelData.put("isActive",1)
    col.insert(modelData )
    }
    else {
      modelData.remove('_id')
      ObjectId newId = new ObjectId(id);
      col.update([_id:newId],[$set:modelData])
      }
      def dataGrid=[]
      col.find([isActive:1]).toArray().each {
        it._id = it._id.toString()
        def jsonModel = new JsonBuilder(it)
        dataGrid << jsonModel
      }
    render dataGrid
}

def insert(){ 

  def userRecord= User.findByUsername(principal.username)
  def uName=userRecord.username


  def modelData = request.JSON.model


  modelData.put('clientID',userRecord.clientId)
  modelData.put('industryID',userRecord.industryId)


  Date date = new Date();

  def collectionName = request.JSON.cName
  def id = request.JSON.id
  def childCollectionName=request.JSON.childColName
  def col = service.collection(collectionName)
  def returnId
  if (id == 0 ) {
    modelData.put("createdBy",uName)
    modelData.put("createdOn",date.toString())
    modelData.put("updatedBy",uName)
    modelData.put("updatedOn",date.toString())
    modelData.put("isActive",1)
    col.insert(modelData )
    def data = [[],[_id:1]].collect {it as BasicDBObject }  
    def dt=[_id:-1]
    col.find(data).sort(dt).limit(1).toArray().each {
      returnId = it._id
    }
    } else if(childCollectionName==''){
      modelData.put('updatedBy',uName)
      modelData.put('updatedOn',date.toString())
      ObjectId newId = new ObjectId(id);
      col.update([_id:newId],[$set:modelData])
      returnId = id
      }

      else{
        ObjectId newId = new ObjectId(id);
        ObjectId newEducationId= new ObjectId()
        def newEId = newEducationId.toString()
        modelData.put('Ed_id',newEId)
        col.update([_id:newId],[$set:[updatedBy:uName,updatedOn:date.toString()]])
        col.update([_id:newId],[$addToSet:[(childCollectionName):modelData]])
        col.find([_id:newId],[_id:0,(childCollectionName):1]).each {
          def jsonModel = new JsonBuilder(it."$childCollectionName")
          returnId=jsonModel
        }
      }
      render returnId
    }





    def insertUser(){ 
      def modelData = request.JSON.model
      def collectionName = request.JSON.cName
      def id = request.JSON.id
      def childCollectionName=request.JSON.childColName
      def usercol = service.collection(collectionName)
      def user_id
      def user_Type=request.JSON.model.userType
      def userRecord= User.findByUsername(principal.username)
      def uName=userRecord.username

      Date date = new Date();

      if (id == 0 ) {
       
        modelData.put('clientID',userRecord.clientId)
        modelData.put('industryID',userRecord.industryId)
        def email=modelData.email
        def username=modelData.userName
        def password=modelData.password

        def clientAdminRole = Role.findByAuthority(user_Type)
        def clientAdminUser = User.findByUsername(username) ?: new User(
          username: username,
          email:email,
          clientId: userRecord.clientId,
          industryId :userRecord.industryId,
          password: password,
          enabled: true,
          authorities: [clientAdminRole]).save(failOnError: true,flush: true)
        

        def returnId
        def ud = [[],[_id:1]].collect {it as BasicDBObject }  
        def dt=[_id:-1]
        def col=service.collection('user')
        col.find(ud).sort(dt).limit(1).toArray().each {
          it._id=it._id.toString()
          returnId = it._id
        }

        modelData.put("userId",returnId)
        modelData.put("createdBy",uName)
        modelData.put("createdOn",date.toString())
        modelData.put("updatedBy",uName)
        modelData.put("updatedOn",date.toString())
        modelData.put("isActive",1)

        
        usercol.insert(modelData)
        def query1 = [[],[_id:1]].collect {it as BasicDBObject }  
        def query2=[_id:-1]
        usercol.find(query1).sort(query2).limit(1).toArray().each {
          user_id = it._id
        }
        }else if(childCollectionName==''){
          modelData.put('updatedBy',uName)
          modelData.put('updatedOn',date.toString())
          ObjectId newId = new ObjectId(id);
          usercol.update([_id:newId],[$set:modelData])
          user_id = id
          }else{
            ObjectId newId = new ObjectId(id);
            ObjectId newEducationId= new ObjectId()
            def newEId = newEducationId.toString()
            modelData.put('Ed_id',newEId)
            usercol.update([_id:newId],[$set:[updatedBy:uName,updatedOn:date.toString()]])
            usercol.update([_id:newId],[$addToSet:[(childCollectionName):modelData]])
            usercol.find([_id:newId],[_id:0,(childCollectionName):1]).each {
              def jsonModel = new JsonBuilder(it."$childCollectionName")
              user_id=jsonModel
            }
          }
          render user_id
        }

   
   /*CreatedBy:CRM Team.
   Purpose:To Perform  Update Operation.*/
   
 def updateChildCollection(){
    println("updateChildCollection")
    def userRecord= User.findByUsername(principal.username)
    def uName=userRecord.username
    Date date = new Date();
    def cid = request.JSON.model.c_id
    def collectionName = request.JSON.cName
    def childCollectionName=request.JSON.childColName
    def col = service.collection(collectionName)
    def modelData = request.JSON.model
    def id=request.JSON.id
    def returnId
    ObjectId newId = new ObjectId(id);
    modelData.put('c_id',cid)
    String colId=childCollectionName+'.c_id'
    String columnName=childCollectionName+'.$'
    def data = [[(colId):cid],[$set:[(columnName):modelData]]]
    col.update([_id:newId],[$set:[updatedBy:uName,updatedOn:date.toString()]])
    col.update(data)
    col.find([_id:newId],[_id:0,(childCollectionName):1]).each {
      def jsonModel = new JsonBuilder(it."$childCollectionName")
      returnId=jsonModel
    }
    render returnId
  }


  /*CreatedBy:CRM Team.
   Purpose:To Perform  Save and Update Clients*/

  def saveClient(){
    def userRecord= User.findByUsername(principal.username)
    def uName=userRecord.username
    Date date = new Date();
    def returnId
    def returnData
    def clientAdminRole = Role.findByAuthority('ROLE_CLIENTADMIN')
    def id=request.JSON.id
    def modelData = request.JSON.model
    def collectionName = request.JSON.cName
    def username=modelData.userId
    def email=modelData.email
    def password=modelData.password
    def industry=modelData.industry
    def industryId

    def col = service.collection(collectionName)
    def indCol=service.collection('industry')
    def indData = [[name:industry],[_id:0,industryId:1]].collect {it as BasicDBObject }
    indCol.find(indData)toArray().each {
        industryId = it.industryId
    }
    if (id == 0 ) {
      modelData.put("createdBy",uName)
      modelData.put("createdOn",date.toString())
      modelData.put("updatedBy",uName)
      modelData.put("updatedOn",date.toString())
      modelData.put("isActive",1)
      col.insert(modelData )
      def data = [[],[_id:1]].collect {it as BasicDBObject }  
      def dt=[_id:-1]
      col.find(data).sort(dt).limit(1).toArray().each {
        it._id = it._id.toString()
        returnId = it._id
      }
      def clientAdminUser = User.findByUsername(username) ?: new User(
        username: username,
        email:email,
        clientId: returnId,
        industryId :industryId,
        password: password,
        enabled: true,
        authorities: [clientAdminRole]).save(failOnError: true)

      def dataGrid=[]
      col.find([isActive:1]).toArray().each {
        it._id = it._id.toString()
        def jsonModel = new JsonBuilder(it)
        dataGrid << jsonModel
      }
      render dataGrid

    }
    else{
      modelData.put("updatedBy",uName)
      modelData.put("updatedOn",date.toString())
      modelData.remove("_id")
      ObjectId newId = new ObjectId(id);
      def data = [[_id:newId],[$set:modelData]]
      col.update(data)
      def dataGrid=[]
      col.find([isActive:1]).toArray().each {
        it._id = it._id.toString()
        def jsonModel = new JsonBuilder(it)
        dataGrid << jsonModel
      }
      render dataGrid
    }
  }

  /*CreatedBy:CRM Team.
   Purpose:To Perform  Remove Client*/

  def removeClient(){
    def collectionName = request.JSON.cName
    def id = request.JSON.id
    println"id..."+id
    def col = service.collection(collectionName)
    ObjectId newId = new ObjectId(id);
    def userName
    col.find([_id:newId],[_id:0,userId:1]).toArray().each{
      userName=it.userId
    }
    col.update([_id:newId],[$set:[isActive:0]])
    def userCol=service.collection('user')
    userCol.update([username:userName],[$set:[enabled:false]])
    def dataGrid=[]

    col = service.collection(collectionName)
    col.find([isActive:1]).toArray().each {
      it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel
    }
    render dataGrid
  }

  /*CreatedBy:CRM Team.
   Purpose:To Perform  Find Particular Document*/

  def find(){
    def id = request.JSON.edit_id
    def collectionName=request.JSON.cName
    ObjectId newId = new ObjectId(id);
    def result
    def col = service.collection(collectionName)
    def data = [[_id:newId]].collect { it as BasicDBObject }    
    col.find(data).toArray().each {
      it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      result=jsonModel    
    }
    render result
  }

  /*CreatedBy:CRM Team.
   Purpose:To Perform  Find Particular SubDocument*/

  def findChildCollection(){
    def eid = request.JSON.editEdu_id
    def collectionName = request.JSON.cName
    def childCollectionName=request.JSON.childColName
    def col = service.collection(collectionName)
    String query=childCollectionName+'.Ed_id'
    String query1=childCollectionName+'.$'
    def data = [[(query):eid],[(query1):1,_id:0]].collect { it as BasicDBObject }    
    def dataGrid
    col.find(data).toArray().each {
      def jsonModel = new JsonBuilder(it."$childCollectionName")
      dataGrid =jsonModel
    }
    render dataGrid
  }

  /*
   CreatedBy:CRM Team.
   Purpose:To Perform  Remove SubDocument.
  */ 

  def removeChildCollection(){
    def userRecord= User.findByUsername(principal.username)
    def uName=userRecord.username
    Date date = new Date();
    def collectionName = request.JSON.cName
    def id = request.JSON.Id
    ObjectId newId = new ObjectId(id)
    def returnId
    def childId=request.JSON.editEdu_id
    def childCollectionName=request.JSON.childColName
    def col = service.collection(collectionName)
    col.update([_id:newId],[$set:[updatedBy:uName,updatedOn:date.toString()]])
    col.update([_id:newId],[$pull:[(childCollectionName):[Ed_id:childId]]])
    col.find([_id:newId],[_id:0,(childCollectionName):1]).each {
      def jsonModel = new JsonBuilder(it."$childCollectionName")
      returnId=jsonModel
    }
    render returnId
  }

 
  def findAll(){
    def collectionName = params.cName
    def col = service.collection(collectionName)    
    def dataGrid=[]
    col.find().toArray().each {
      it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel      
    }
    render dataGrid
  }

  def findIsActive(){
    def collectionName = params.cName
    def col = service.collection(collectionName)    
    def dataGrid=[]
    col.find([isActive:1]).toArray().each {
      it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel      
    }
    render dataGrid
  }

  /*
   CreatedBy:CRM Team.
   Purpose:To Perform  Finding LookUp for DropDown.
  */
  /* def lookUpData(){
    def collectionName = params.cName
    def col = service.collection(collectionName)
    def type = params.type
    def dataGrid=[]
    def data
    if(type != null){
    data = [[type:type],[_id:0,name:1,value:1]].collect {it as BasicDBObject }
      }else{

        data = [[],[_id:0,systemRole:1,userDefinedRole:1]].collect {it as BasicDBObject }
      }
   
 8   col.find(data).toArray().each {
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel
    }
    render dataGrid
  }*/

/*def lookUpData(){
    def data
    def collectionName = params.cName
    def col = service.collection(collectionName)
println"col......."+col
    def type = params.type
    def relation = 0
    if (params.relation) {
      relation=params.relation
    }
    def dataGrid=[]

     if(type != null){
println"if......."
    data = [[type:type, relation:relation],[_id:0,name:1,value:1,code:1]].collect {it as BasicDBObject } 
    }else{
      

        data = [[],[_id:0,systemRole:1,userDefinedRole:1]].collect {it as BasicDBObject }
      }
  
      col.find(data).toArray().each {
 println"it......."+it
      def jsonModel = new JsonBuilder(it)
 println"jsonModel......."+jsonModel
      dataGrid << jsonModel
println"dataGrid......."+dataGrids
    }
    
    render dataGrid
  }*/

  def lookUpData(){
    def data
    def collectionName
    def type
    def relation = "0"
    params.remove("controller")
    params.remove("action")
    if(params){
      collectionName = params.cName
      type = params.type

      if (params.relation) {
        relation=params.relation
      }
    }
    else{
        collectionName=request.JSON.cName
        type=request.JSON.type
        relation=request.JSON.relation
    }
    def col = service.collection(collectionName)
   
    def dataGrid=[]

    if(type!=null){
      data = [[type:type,relation:relation],[_id:0,name:1,value:1,code:1]].collect {it as BasicDBObject } 
    }
    else{
      data = [[],[_id:0,systemRole:1,userDefinedRole:1]].collect {it as BasicDBObject } 
    }
    col.find(data).toArray().each {
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel
    }
    render dataGrid
  }

    
  /*
   CreatedBy:CRM Team.
   Purpose:To Perform  Finding Data for Menu.
  */
  def findMenu(){
    def userRecord= User.findByUsername(principal.username)
    def auth=userRecord.authorities.authority
    def dataGrid=[]
    if(auth[0]!=null){
      def col = service.collection('menu')
      def data1 = [[role:auth[0]]].collect { it as BasicDBObject }    
      col.find(data1).sort([sequenceId:1]).toArray().each {
        it._id=it._id.toString()
        def jsonModel = new JsonBuilder(it)
        dataGrid << jsonModel
      }
      render dataGrid
    } 
  }
  /*
   CreatedBy:CRM Team.
   Purpose:To Perform  File upload and file save in document.
  */
  def fileUpload() {
    MultipartFile file = request.getFile( 'file' )
    def homeDir = new File(System.getProperty("user.home")) 
    File fileDest = new File(homeDir,"CRM/5December/crm/grails-app/assets/img/uploadedFiles/"+ file.originalFilename)
    file.transferTo(fileDest)
    render file.originalFilename
  }

  def userfileUpload() {
  
        MultipartFile file = request.getFile( 'file' )

        def homeDir = new File(System.getProperty("user.home")) 
        File fileDest = new File(homeDir,"CRM/5December/crm/grails-app/assets/img/userImages"+ file.originalFilename)
      
        file.transferTo(fileDest)
        
        render file.originalFilename
  }

  def saveImage(){
    def modelData = request.JSON.model
    def collectionName = request.JSON.cName
    def id = request.JSON.id
    def col=service.collection(collectionName)
    ObjectId newId = new ObjectId(id);
    def data=[[_id:newId],[$set:[imagePath:modelData]]]
    col.update(data)
  }

  def insertRolemapping(){
    def modelData = request.JSON.model
    def collectionName = request.JSON.cName
    def roleId = request.JSON.roleId
    def userData
    def col
    def dataGrid=[]
    if(roleId==0){
      
      def userRecord= User.findByUsername(principal.username)
      def userName=userRecord.username
      col=service.collection('user')
      def data=[[username:userName],[clientId:1,industryId:1,_id:0]].collect { it as BasicDBObject }  
      col.find(data).toArray().each{
        userData=it
      }
      def clientId=userData.clientId
      def industryId=userData.industryId
      col=service.collection(collectionName)
      modelData.put("clientId",clientId)
      modelData.put("industryId",industryId)
      col.insert(modelData)
      col.createIndex( ["systemRole": 1 ] , [unique: true ]  )
     
     findRoleMappingData()
       
    }
    else{
      col=service.collection(collectionName)
      ObjectId newId = new ObjectId(roleId);
      col.update([_id:newId],[$set:modelData])

      findRoleMappingData()
    }
    
  }

  def findData(){
    def id = request.JSON.Id
    def collectionName = request.JSON.cName
    ObjectId newId = new ObjectId(id);
    def col = service.collection(collectionName)
    def data = [[_id:newId],[_id:0]].collect { it as BasicDBObject }    
    def dataGrid
    col.find(data).toArray().each {
      def jsonModel = new JsonBuilder(it)
      dataGrid =jsonModel
    }

    render dataGrid
  }

  /* def findAllData(){
   
    def collectionName = request.JSON.cName
   
    def col = service.collection(collectionName)
    def data=[[]].collect { it as BasicDBObject }  
    def dataGrid=[]
    def index=0
    col.find(data).toArray().each {
      def jsonModel = new JsonBuilder(it)
      dataGrid[index] =jsonModel
      index=index+1
    }
println"dataGrid..."+dataGrid
    render dataGrid

 

  }*/

  def findAllData(){
 def collectionName = request.JSON.cName
    def col = service.collection(collectionName)    
    def dataGrid=[]
    col.find().toArray().each {
      it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      dataGrid << jsonModel      
    }
    render dataGrid

  }


  def deleteData(){
    def collectionName = request.JSON.cName
    def id = request.JSON.Id
    ObjectId newId = new ObjectId(id)
    def dataGrid=[]
    def col = service.collection(collectionName)
    col.remove([_id:newId])
    findRoleMappingData()
  }

  def findById(){
  def userRecord= User.findByUsername(principal.username)
    String id=userRecord.id
    def returnData
    def col=service.collection('person')
    col.find([userId:id]).toArray().each{
     it._id = it._id.toString()
      def jsonModel = new JsonBuilder(it)
      returnData =jsonModel
    }
   render returnData

  }

  def findRoleMappingData(){
    //def collectionName = params.cName
    def col = service.collection('roleMapping')    
    def dataGrid=[]
    def data=[[]].collect { it as BasicDBObject } 
    col.find(data).toArray().each {
      dataGrid << it      
    }
    def clientName
    def industryName
    def renderData=[]
    def allData=[]
    for(int i=0;dataGrid[i]!=null;i++){
      def id=dataGrid[i].clientId
      ObjectId newId = new ObjectId(id);
      col = service.collection('client')
      data=[[_id:newId],[_id:0,clientName:1]].collect { it as BasicDBObject }
      col.find(data).toArray().each {
        clientName=it.clientName      
      }
      
     col = service.collection('industry')
     data=[[industryId:dataGrid[i].industryId],[_id:0,name:1]].collect { it as BasicDBObject }
      col.find(data).toArray().each {
        industryName=it.name      
      }
      allData[i]=["_id":dataGrid[i]._id.toString(),"clientName":clientName,"industry":industryName,"systemRole":dataGrid[i].systemRole,"userDefinedRole":dataGrid[i].userDefinedRole]
      def jsonModel = new JsonBuilder(allData[i])
      renderData << jsonModel

    }
    render renderData
  }





def saveData(){ 

  def userRecord= User.findByUsername(principal.username)
  def uName=userRecord.username
 def jsonModel

  def modelData = request.JSON.model


  modelData.put('clientID',userRecord.clientId)
  
  Date date = new Date();

  def collectionName = request.JSON.cName
  def id = request.JSON.id
  def childCollectionName=request.JSON.childColName
  def col = service.collection(collectionName)
  def returnId

  if (id == 0 ) {
 println "IF.."
    modelData.put("createdBy",uName)
    modelData.put("createdOn",date.toString())
    modelData.put("updatedBy",uName)
    modelData.put("updatedOn",date.toString())
    modelData.put("isActive",1)
    modelData.put("avatar","assets/patients/default.jpg")
    
    col.insert(modelData )

    } 



/* for updating fields in document- single*/

    else if(childCollectionName==''){
       println "elseIF"
      modelData.put('updatedBy',uName)
      modelData.put('updatedOn',date.toString())
      ObjectId newId = new ObjectId(id);
      col.update([_id:newId],[$set:modelData])

            }

/* for insering new document in child collection-multiple*/
      else{

       println "else"
        def newId = new ObjectId(id);
          println "newId"+newId
        ObjectId newEducationId= new ObjectId()
        def newCID = newEducationId.toString()
        modelData.put('c_id',newCID)
        col.update([_id:newId],[$set:[updatedBy:uName,updatedOn:date.toString()]])
        col.update([_id:newId],[$addToSet:[(childCollectionName):modelData]])
        
/*fetching saved data

def data = [[],[_id:1]].collect {it as BasicDBObject }  
    def dt=[_id:-1]
    
    col.find(data).sort(dt).limit(1).toArray().each {
      returnId = it._id
    }

    */

    /*

db.school.find({}, {_id:0, students: 1})
    */

    col.find([_id:newId],[_id:0,(childCollectionName):1]).each {
       jsonModel = new JsonBuilder(it."$childCollectionName")
      println"jsonModel.."+jsonModel
      returnId = jsonModel
      render returnId
    }
      }

      
    }


def getChildData(){
println"getLicData.."
  def collectionName = request.JSON.cName
  def id = request.JSON.id
  def newId = new ObjectId(id);
  def childCollectionName=request.JSON.childColName
  def col = service.collection(collectionName)
  def jsonModel = null
 println"jsonModelmm.."

 col.find([_id:newId],[_id:0,(childCollectionName):1]).each {

       jsonModel = new JsonBuilder(it."$childCollectionName")

      println"jsonModel.."+jsonModel
     
    
    }

    if(jsonModel.toString()==null || jsonModel.toString()=='null' || jsonModel.toString()=='' ){
      println"if"
       render 0
    }
    else{
       println"else"
      render jsonModel  
    }
       

}



  def insertChildData()
    {
        def userRecord= User.findByUsername(principal.username)
        def uName=userRecord.username
        def modelData=request.JSON.model
        def collectionName = request.JSON.cName
        def id = request.JSON.id
       
        Date date = new Date();
      def col = service.collection(collectionName)
        modelData.put("updatedBy",uName)
        modelData.put("updatedOn",date.toString())
      if (id == 0 ) {
        modelData.put("createdBy",uName)
        modelData.put("createdOn",date.toString())
      
        modelData.put("isActive",1)
        col.insert(modelData )
        }
        else{
            println"modelData--->"+modelData
            modelData.remove("_id")
          ObjectId newId =new ObjectId(id);
          col.update([_id:newId],[$set:modelData])
        }
        def dataGrid=[]
        col.find([isActive:1]).toArray().each {
          it._id = it._id.toString()
          def jsonModel = new JsonBuilder(it)
          dataGrid << jsonModel
        }
         render dataGrid
    }
    


}








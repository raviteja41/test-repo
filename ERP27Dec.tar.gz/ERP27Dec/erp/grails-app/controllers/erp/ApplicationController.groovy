package erp

import grails.core.GrailsApplication
import grails.util.Environment
import grails.plugins.*

class ApplicationController implements PluginManagerAware {

    GrailsApplication grailsApplication
    GrailsPluginManager pluginManager

    def index() {
    	def userRecord= User.findByUsername(principal.username)
    	println " The user Info " + userRecord
        [grailsApplication: grailsApplication, pluginManager: pluginManager]
    }
}

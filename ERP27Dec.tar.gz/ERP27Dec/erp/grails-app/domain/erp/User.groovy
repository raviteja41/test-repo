package erp

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import org.bson.types.ObjectId  

@EqualsAndHashCode(includes='username')
@ToString(includes='username', includeNames=true, includePackage=false)
class User implements Serializable {

	private static final long serialVersionUID = 1

	transient springSecurityService

	ObjectId id
	String username
	String password
	String email
	String clientId
	String industryId
	boolean enabled = true
	boolean accountExpired
	boolean accountLocked
	boolean passwordExpired

	Set<Role> authorities

	/*Set<Role> getAuthorities() {
		UserRole.findAllByUser(this)*.role
	}*/

	def beforeInsert() {
		encodePassword()
	}

	def beforeUpdate() {
		if (isDirty('password')) {
			encodePassword()
		}
	}
	
	static mapWith = "mongo"

	protected void encodePassword() {
		password = springSecurityService?.passwordEncoder ? springSecurityService.encodePassword(password) : password
	}

	static transients = ['springSecurityService']

	static constraints = {
		password blank: false, password: true
		username blank: false, unique: true
		email blank: false, nullable: false
	}

	static mapping = {
		password column: '`password`'
	}

	public String getMd5HashEmail() {
        return this.email?.trim().encodeAsMD5()
    }
}

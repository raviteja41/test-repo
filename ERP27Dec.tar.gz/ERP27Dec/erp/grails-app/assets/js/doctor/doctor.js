
/*
Created By:
Purpose:Doctor Controller For Creating New Doctors Personal Details 
*/

angular.module('app').controller('doctorController', ['$scope','$http','$rootScope','$location','schemaForm','$stateParams',
  function($scope,$http,$rootScope,$location,$stateParams) {

   $scope.personalDetailsmodel = {}; 
   $rootScope.id=$scope.id;
   $scope.box_class="box"
   $scope.init=function(){
    if($scope.id!=null){
      
      var mdata = {cName:'doctor',childColName:'', edit_id:$scope.id}
      $http.post('/editDoctors',mdata).success(function(data){
      $scope.dob = new Date(data.dob);
       $scope.personalDetailsmodel = {"summary":data.summary,"doctorName":data.doctorName,"phoneNumber":data.phoneNumber,"gender":data.gender,
       "dob":$scope.dob,"email":data.email,"designation":data.designation,"department":data.department};
       
       $rootScope.doctorUpload = true;
       $rootScope.doctorEduDetail = true;
       $rootScope.doctorExpDetail = true;
       
       
     }); 

    }
  } 

  $scope.init();   


  $scope.schema1 = {

   "type": "object",
   "title": "Comment",

   "properties": {

     "doctorName": {
      "placeholder": "Enter doctor Name",
      "type": "string",
      "required":true,
      

    },

    "department":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },
    "designation":
    {

      "type": "string",
      "format" : "uiselect",

      "items": {"type": "string"}
    },
    "dob": {

      "type": "date",
      "required":true,
    },
    


    "gender":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },

    "phoneNumber":{

     "pattern":"[789][0-9]{9}",
     "type":"string",
     "required":true,
     "maxLength":10,
     "minLength":10,
     "validationMessage":""

   },

   "summary":{

    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""


  },

  "email": {
    "type": "string",
    "pattern":  "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",
    "required":true,
    "pattern": "^\\S+@\\S+$",
    "validationMessage":""

  },

  "doctorGrading":
  {

    "type": "string",
    "format" : "uiselect",

    "items": {"type": "string"}
  }
}

};


$scope.form = [

{
  "key": "doctorName",
  "title" : "Doctor Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "placeholder": "Enter Doctor Name"

},


{
  "key" : "department",
  "title" : "Department",
  "placeholder": "Select Department",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}
  
  

},
{
  "key" : "designation",
  "title" : "Designation",
  "placeholder": "Select Designation",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

},

{
  "key": "dob",
  "title": "Dob",
  "placeholder": "Select DOB",
  "type":"date",
  "feedback": false,
  "labelHtmlClass":"form-label"

},

{
  "key" : "gender",
  "title" : "Gender",
  "placeholder": "Selecte Gender",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "assets/gender.json"}}
  

},
{
  "key": "phoneNumber",
  "title": "Phone Number",
  "feedback":false,
  "placeholder": "Enter phoneNumber",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "summary",
  "title": "Summary",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "email",
  "title": "Email",
  "type":"email",
  "placeholder": "Enter email-id",
  "labelHtmlClass":"form-label",
  "feedback": false

},
{
  "key" : "doctorGrading",
  "title" : "Doctor Grading",
  "placeholder": "Select doctorGrading",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=GRADING&cName=lookUp"}}

}/*,

{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Reset"
}
*/



];
$scope.doctorPersonalDetail = true;
$scope.personalDetailsmodel={};

$scope.saveCollection = function(form) {
  
  if($scope.id ==null  ){
    
    $scope.id = 0;
  }


  var mdata = {model:$scope.personalDetailsmodel, cName:'doctor',childColName:'', id:$scope.id}
  $scope.$broadcast('schemaFormValidate');
  
  if (form.$valid) {

    $http.post('/saveDoctorData',mdata)
    .success(function(data){
      $scope.id=data;
      $rootScope.id=$scope.id;
      $rootScope.showAccordian();
      $scope.box_class="box collapsed"
      
    }) 
  }

}

$scope.cancel = function() {
$scope.personalDetailsmodel={};

}

}
]);



/*
Created By:
Purpose:Doctor2Controller For Creating New Doctors Education Details 
*/

angular.module('app').controller('doctor2Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {

    $scope.id=$rootScope.id;
    

    $scope.init=function(){
     
      if($scope.id!=null){
        
        var mdata = {cName:'doctor',childColName:'', edit_id:$scope.id}
        $http.post('/editDoctors',mdata).success(function(data){
          
         $scope.educationDetails=data.education;
         
         
       });

      }
    }
    $scope.init(); 


    $rootScope.showAccordian = function(){
      if($rootScope.id != null){

        $rootScope.doctorEduDetail = true;
      }
      else{
        $rootScope.doctorEduDetail = false;

      }

    }

    $scope.educationDetailsmodel = {};
    $scope.account= [];
    $scope.doctorEduUrl = '';

    $scope.addRow = function(){
     
      $scope.educationDetailsmodel = {};
      $scope.doctorEduUrl = "assets/Doctor/docEducationForm.html";
    };

    


    $scope.educationDetailsSubmit = function(form) {
     
     if($scope.Ed_id ==null) {

      $scope.id=$rootScope.id;
      if( $scope.id !=null){

        var mdata = {model: $scope.educationDetailsmodel, cName:'doctor', childColName:'education', id:$scope.id}

        $scope.$broadcast('schemaFormValidate');
        if (form.$valid) {
         $http.post('/saveDoctorData',mdata)
         .success(function(data){
          $scope.educationDetails=data;
          $scope.doctorEduUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();


        });

         
       }

     }

   }
   else{

    $scope.id=$rootScope.id;
    if( $scope.id !=null){
      var mdata = {model:$scope.educationDetailsmodel, cName:'doctor', childColName:'education', id:$scope.id,Ed_id:$scope.Ed_id}
      $scope.$broadcast('schemaFormValidate');
      if (form.$valid) {
        $http.post('/saveEditDoctorData',mdata)
        .success(function(data){
          $scope.educationDetails=data;
          $scope.doctorEduUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();
          $scope.Ed_id=null;

        });

        
      }

    }

  }
};


$scope.editEducation=function(edit_id){

  $scope.doctorEduUrl = "assets/Doctor/docEducationForm.html";
  var mdata = {cName:'doctor',childColName:'education',Id:$rootScope.id,editEdu_id:edit_id}
  $http.post('/editDoctorsEducation',mdata).success(function(data){

    $scope.educationDetailsmodel=data[0];
    $scope.Ed_id=$scope.educationDetailsmodel.Ed_id;
    
  })

}

$scope.deleteEducationConfirm=function(Ed_id){
 
  $scope.Ed_id=Ed_id;
  var new_dialog1 = ngDialog.open({
    id: 'fromAService4',
    template: "assets/ui-modal-eduication.html",
    className: 'ngdialog-theme-default role-width',
    scope:$scope,
    closeByDocument: false,

  });
}

$scope.deleteEducation=function(Ed_id){
  alert("+++++++"+Ed_id)
  
  var mdata = {cName:'doctor',childColName:'education',Id:$rootScope.id,editEdu_id:Ed_id}
  $http.post('/deleteDoctor',mdata).success(function(data){

    $scope.educationDetails=data;
    $scope.closeDialog();
    
  });

}

$scope.closeDialog=function(){
  ngDialog.close('fromAService1');
}

$scope.cancel = function() {

  $scope.doctorEduUrl= '';

}

$scope.schema2={

 "type": "object",
 "title": "Comment",

 "properties": {

   "qualification":
   {
    "title": "Qualification",
    "type": "string",
    "format" : "uiselect",
    "items": {"type": "string"}
  },
  
  "university": {
    "title": "University",
    "type": "string",
    "required":true,
  },
  "location": {
    "title": "Location",
    "type": "string",
    "required":true,
  },
  "comments": {
    "title":"Comments",
    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""
  },

}

};

$scope.form1=[

{
  "key" : "qualification",
  "title" : "Qualifaction",
  "placeholder": "none selected",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=QUALIFICATION&cName=lookUp"}}
},

{
  "key": "university",
  "title": "University",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "location",
  "title": "Location",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "comments",
  "title": "Comments",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

}/*,
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Cancel"
}*/

];



}
]);


/*
Created By:
Purpose:Doctor3Controller For Creating New Doctors Experince Details 
*/

angular.module('app').controller('doctor3Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {


    $scope.id=$rootScope.id;

    $scope.init=function(){
      if($scope.id!=null){
        var mdata = {cName:'doctor',childColName:'', edit_id:$scope.id}
        $http.post('/editDoctors',mdata).success(function(data){
          
         $scope.experienceDetails=data.experience;
         
         
       });

      }
    }

    $scope.init(); 


    $scope.experiencemodel = {};

    $rootScope.showExpAccordian = function(){
      if($rootScope.id != null){
        $rootScope.doctorExpDetail = true;
      }
      else{
        $rootScope.doctorExpDetail = false;
      }

    }

    $scope.doctorExpUrl = '';
    var doctorExpSet = [];

    $scope.includeExperience = function(){
      $scope.experiencemodel = {};
      $scope.doctorExpUrl = "assets/Doctor/docExperienceForm.html";
    }

    $scope.editExperience=function(edit_id){

      $scope.doctorExpUrl = "assets/Doctor/docExperienceForm.html";
      var mdata = {cName:'doctor',childColName:'experience',Id:$rootScope.id,editEdu_id:edit_id}
      $http.post('/editDoctorsEducation',mdata).success(function(data){

        $scope.experiencemodel =data[0];
        $scope.Ed_id=$scope.experiencemodel.Ed_id;
        
      })

    }

    $scope.deleteExperienceConfirm=function(Ed_id){
      $scope.Ed_id=Ed_id;
      var new_dialog1 = ngDialog.open({
        id: 'fromAService4',
        template: "assets/ui-modal-experienceDelete.html",
        className: 'ngdialog-theme-default role-width',
        scope:$scope,
        closeByDocument: false,

      });
    }

    $scope.deleteExperience=function(Ed_id){
      
      var mdata = {cName:'doctor',childColName:'experience',Id:$rootScope.id,editEdu_id:Ed_id}
      $http.post('/deleteDoctor',mdata).success(function(data){

       $scope.experienceDetails=data;
       $scope.closeDialog();
       
     });

    }
    
    $scope.closeDialog=function(){
      ngDialog.close('fromAService1');
    }

$scope.cancel = function() {

  $scope.doctorExpUrl= '';

}
    $scope.schema3={

      "type": "object",
      "title": "Comment",
      "properties": {

        "hospitalName": {
          "title": "Hospital Name",
          "type": "string",
          "required":true,
        },


        "department":
        {
          "title": "Department",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },

        "designation":
        {
          "title": "Designation",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },

        "noOfYears":
        {
          "title": "No Of Years",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"},
          "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}
        },



      }

    };


    $scope.form2=[
    {
      "key": "hospitalName",
      "title": "Hospital Name",
      "type":"string",
      "labelHtmlClass":"form-label",
      "feedback": false

    },
    {
      "key" : "department",
      "title" : "Department",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}

    },
    {
      "key" : "designation",
      "title" : "Designation",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

    },
    {
      "key" : "noOfYears",
      "title" : "No Of Years",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}

    }/*,
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-info",
      "title": "Save"
    },
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-warning",
      "title": "Reset"
    }*/



    ];

    

    

    $scope.experienceSubmit = function(form) {

      if($scope.Ed_id==null){
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model: $scope.experiencemodel, cName:'doctor', childColName:'experience', id:$scope.id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/saveDoctorData',mdata)
            .success(function(data){
              
              $scope.experienceDetails=data;
              $scope.doctorExpUrl = '';
              $scope.experiencemodel = {};
              
            })

            
          }

        }
      }
      else{
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model:$scope.experiencemodel, cName:'doctor', childColName:'experience', id:$scope.id,Ed_id:$scope.Ed_id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/saveEditDoctorData',mdata)
            .success(function(data){
              $scope.experienceDetails=data;
              $scope.doctorExpUrl = '';
              $scope.experiencemodel = {};
              $scope.Ed_id=null;

            });

            
          }

        }

      }
      
    }
    
  }
  ]);



angular.module('app').controller('menuController', ['$scope','$http',function($scope,$http) {


 $scope.menu = [];
 
 $http.get('/menuData')
 .success(function(data) {
   
  $scope.menu = data;
  
});

}
]);


angular.module('app').controller('uploadController', ['$scope','$http','$rootScope', 'Upload', '$timeout',
  function($scope,$http,$rootScope, Upload, $timeout) {

   $scope.uploadPic = function(file) {
     $scope.id=$rootScope.id;
     if( $scope.id !=null){
       
      file.upload = Upload.upload({
        url: 'fileUpload',
        data: { file: file},
      });

      file.upload.then(function (response) {
        $timeout(function () {
          file.result = response.data;
          var mdata = {model: file.result, cName:'doctor', id:$scope.id}

          $http.post('/saveImage',mdata)
          .success(function(data){
            
          })
          
        });
      }, function (response) {
        if (response.status > 0)
          $scope.errorMsg = response.status + ': ' + response.data;
      }, function (evt) {
        file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
      });


    }

  }

}]);


/*
Created By:CRM Team
Purpose:DoctorViewController For Showing all registered Doctors
*/
angular.module('app').controller('viewDoctors', ['$scope','$http','$location','schemaForm','$rootScope','$log',
      function($scope,$http,$location,$rootScope,$log) {

  /*
  Created By:CRM Team
  Purpose:AJAX call to get all registered doctors from db
  */      


$http.get('/allDoctors?cName=doctor').success(function(data){
              $scope.doctors = data;
              $scope.currentPage = 1;
              $scope.itemsPerPage = 6;
              $scope.totalItems = $scope.doctors.length;
                  })
    

    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };



/*
  Created By:CRM Team
  Purpose:Function To show creat new doctor Form
*/ 

$scope.displayDoctorTpl = function(page){
        $rootScope.doctorEduDetail = false;
        $rootScope.doctorExpDetail = false;
    $location.path('/viewDoctor' + page);
    $scope.editPage = (page === 'assets/add_doctor.html') ? 'assets/app_viewDoctor.html' : 'assets/add_doctor.html';
}

/*
  Created By:CRM Team
  Purpose:Function To show Edit Doctor Screen
*/  

$scope.editDoctorTpl = function(id){

     var mdata = {model:$scope.personalDetailsmodel, cName:'doctor',childColName:'', edit_id:id}
     $http.post('/editDoctors',mdata).success(function(data){
      
         $scope.personalDetailsmodel=data;
        })

}


}]);
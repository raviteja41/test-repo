angular.module('app').factory('userService', function() {
var modelData = {};

return {
    
    setmodelData: function(model) {
        modelData = model;
    },
    getmodelData: function() {
        return modelData;
    }
   
};
});

/*

angular.module('app').controller('employeeinfoController', 
  ['$scope','$http','$rootScope','$location','userService',
    function($scope,$http,$rootScope,$location,userService) {
  

    $scope.schema={
   "type": "object",
   "title": "Comment",
   "properties": {
       "Emp_Code": {
         "type": "integer",
         "title":"Employee Code",
          "required":true,
          "minLength":2,
          "validationMessage":"              "
        },
       "First_Name": {
          "type": "string",
           "title":"First Name",
          "required":true,
          "validationMessage":"              "
        },
       "Middle_Name": {
          "type": "string",
           "title":"Middle Name",
          "validationMessage":"              "
        },
    "Last_Name": {
       "title":"Last Name",
          "type": "string",
          "validationMessage":"              "
        },
     "Short_Name": {
       "title":"Short Name",
          "type": "string",
          "validationMessage":"              "
        },
    "dob": {
           "type": "date",
           "required":true,
          "validationMessage":"              "
        },
    "Father_Name": {
      "title":"Father Name",
          "type": "string",
          "validationMessage":"              "
        },
    "Spouse_Name": {
      "title":"Spouse Name",
          "type": "string",
          "validationMessage":"              "
        },
    "Mobile":{
        "title":"Mobile",
          "type": "number",
          "pattern":"[789][0-9]{9}",
          "maxLength":10,
          "minLength":10,
          "validationMessage":"              "
        },
       
    
         "Gender" :{
            "title" : "Gender",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Place_Of_Birth": {
         "title":"Place Of Birth",
          "type": "string",
          "validationMessage":"              "
        },
        "Religion" :{
            "title" : "religion",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Marital_status" :{
            "title" : "Marital status",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Nationality" :{
            "title" : "Nationality",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
//     "caste" :{
//            "title" : "caste",
//            "type" : "array",
//            "items": {"type":"string"},
//            "maxItems": 1,
//         },
        "caste" :{
                "title":"caste",
                "type" :"array",
                "items":{"type":"string"}
               
                         },
        "Language_Known" :{
                "title":"Language Known",
                "type" :"array",
                "items":{"type":"string"}
               
                         },
       "Mother_Tongue" :{
            "title" : "Mother Tongue",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
      
       "Identification_Mark": {
        "title":"Identification Mark",
          "type": "string",
          "validationMessage":"              "
        },
        "Blood_Group":{
            "title" : "Blood Group",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
    
       "Weight": {
          "type": "number",
          "validationMessage":"              "
        },
       
       "Height": {
          "type": "number",
          "validationMessage":"              "
        },
       
       "Remarks": {
          "type": "string",
          "validationMessage":"              "
        },

}
   };

$scope.form = [
{
     "key": "Emp_Code",
     "feedback":false,
     "htmlClass":" form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
{
     "key": "First_Name",
     "feedback":false,
     "htmlClass":" form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Middle_Name",
     "feedback":false,
     "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Last_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Short_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "dob",
     "title":"Date of birth",
     "feedback":false,
    "labelHtmlClass":"form-label",
    "htmlClass":"form-group controls ",
     "type": "date"
     
   },
    {
     "key": "Father_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
  {
     "key": "Spouse_Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Mobile",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
        "key" : "Gender",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/gender.json"
                        }
                    }

        },
     {
     "key": "Place_Of_Birth",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     
    {
        "key" : "Religion",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/religion.json"
                        }
                    }

        },
     {
        "key" : "Marital_status",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/maritalStatus.json"
                        }
                    }

        },
     {
        "key" : "Nationality",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/nationality.json"
                        }
                    }

        },

    {
    "key" : "caste",
    "type": "strapselect",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                "placeholder": "None selected",
                "options": {
                     "multiple" : "true",
                    "httpGet": {
                        
                        "url": "assets/caste.json"
                    },

                }

    },
   
    {
    "key" : "Language_Known",
    "type": "strapselect",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                "placeholder": "None selected",
                "options": {
                    "multiple" : "true",
                    "httpGet": {
                         
                        "url": "assets/language.json"
                    },

                }

    },
     {
        "key" : "Mother_Tongue",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/mothertongue.json"
                        }
                    }

        },
    {
     "key": "Identification_Mark",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     {
        "key" : "Blood_Group",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/bloodgroup.json"
                        }
                    }

        },
    {
     "key": "Weight",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Height",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Remarks",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   }
     
    
   
 ];

*/
/*alert("roottscope"+$rootScope.modelEmpInfo)
$scope.modelEmpInfo = $rootScope.modelEmpInfo;

  

  $scope.submitEmpInfo = function(form) {
    // First we broadcast an event so all fields 
    //validate themselves

   // $scope.$broadcast('schemaFormValidate');
 var mdata = {model: $scope.modelEmpInfo, cName:'employee', childColName:'', id:0}

    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/saveData',mdata)
         .success(function(data){
         alert("submitTED")
           $location.path('assets/Employee/employeeinfo.html');
         
        });

    }
  }

    }]);


*/

angular.module('app').controller('familyInfoController', ['$scope','$http','$rootScope','ngDialog','$timeout',
  function($scope,$http,$rootScope,ngDialog,$timeout) {
 

$scope.loadFamilyData=function(){

 var mdata = {cName:'employee',childColName:'family', id:'585b9fc6ba6f9074593ff18d'}
   
$http.post('/loadFamilyData',mdata)
         .success(function(data){
          $scope.familyData=data;
         })
  }



 $scope.id=$rootScope.id;
    alert("familyInfoController")

    


    $scope.familyDetailsModel = {};
    $scope.account= [];
    $scope.doctorEduUrl = '';

    $scope.addRow = function(){
      
     
      $scope.familyDetailsModel = {};
      $scope.familyUrl = "assets/Employee/familyForm.html";
    };

   


  $scope.saveFamily = function(form) {
 
   $scope.$broadcast('schemaFormValidate');

    if($scope.id==null){
        $scope.id = 0;
    }
   // var mdata = {model:$scope.familyDetailsModel, cName:'family', id:$scope.id}
   var mdata = {model:$scope.familyDetailsModel, cName:'employee',childColName:'family', id:'585b9fc6ba6f9074593ff18d'}
 
    $scope.$broadcast('schemaFormValidate');
  
    if(form.$valid) {
    $http.post('/saveFamilyData',mdata)
    .success(function(data){
        $scope.familyDetails=data;
        $scope.familyUrl = '';
        $scope.id=null;
        $scope.message = "Family is added Successfully"  
        $scope.showMessage("SUCCESS",  $scope.message);    
     }) 
    .error(function(data){ console.log(data)
              $scope.message = "Error Occured pleas check the entry "
              $scope.showMessage("ERROR", $scope.message)
                  });
  }
}

/* $scope.editFamily=function(edit_id){
    
    
    $scope.familyUrl = "assets/Employee/familyForm.html";
    //$scope.readonly = { formDefaults: { readonly : true } };
    var mdata = {cName:'family',Id:$rootScope.id,edit_id:edit_id}
    $http.post('/findFamily',mdata).success(function(data){
        $scope.familyDetailsModel=data;
        $scope.id=$scope.familyDetailsModel._id;
    })
  }

*/



$scope.editFamily=function(modelEdit){

  $scope.familyUrl='';
  $scope.updateBtn=true;
  $scope.saveBtn=false;
  $scope.familyDetailsModel=modelEdit
   //alert(modelEdit.c_id)

//var mdata = {model: $scope.modelLic, cName:'employee', childColName:'licInfo', id:"585b9fc6ba6f9074593ff18d"}
 $timeout(function(){
    $scope.familyUrl="assets/Employee/familyForm.html";},500)
  
}

$scope.onUpdateFamily=function(form){

var mdata = {model:$scope.familyDetailsModel, cName:'employee', childColName:'family', id:'585b9fc6ba6f9074593ff18d'}
      
//var mdata = {model: form, cName:'employee', childColName:'family', id:"585b9fc6ba6f9074593ff18d"}
//alert(mdata.model.Policy_No)
    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/updatefamilyData',mdata)
         .success(function(data){
           $scope.urls='';
           $scope.loadFamilyData();
         
        });

    }

}










   $scope.deleteFamilyConfirm=function(Id){
    
    $scope.Id=Id;
    
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/Employee/ui-modal-Delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,

    });

  }

   $scope.deleteFamily=function(Id){
    var mdata = {cName:'employee',Id:'585b9fc6ba6f9074593ff18d',editEdu_id:Id, childColName:'family'}
    $http.post('/deleteFamily',mdata).success(function(data){
      $scope.familyDetails=data;
      $scope.Id = '';
      $scope.closeDialog();
      $scope.message = "Family details deleted Successfully"  
      $scope.showMessage("SUCCESS",  $scope.message); 
      
    });
    
  $scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  }





  $scope.schema12 = {
  "type": "object",
  "title": "Comment",
  "properties": {

"firstName":{
"title" : "First Name",
"type" : "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},


"middleName": {
"title": "Middle Name",
"type": "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},
"lastName":{
"title" : "Last Name",
"type" : "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},

"relation":  {
"title": "Relation",
"required":true,
"type": "string",
"format" : "uiselect",
"items": {"type": "string"}
},
"gender":  {
"title": "Gender",
"required":true,
"type": "string",
"format" : "uiselect",
"items": {"type": "string"}
},
"dob": {

      "type": "date",
      "required":true,
    },


"isDependent": {
"title": "Is Dependent?",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},



"pfNominee": {
"title": "PF Nominee",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},

"isEmployee": {
"title": "Is Employee?",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},
"isMinor": {
"title": "Is Minor?",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},


"occupation": {
"title": "Occupation",
"type": "string",
"required":true,
"minLength": 10,
"validationMessage":"              "

},
"remarks": {
"title": "Remarks",
"type": "string",
"required":true,
"minLength": 10,
"validationMessage":"              "

},




}





};



 $scope.form12 = [
{
"key": "firstName",
"type":"string",
"feedback":false,
"placeholder": "Enter First here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "middleName",
"type":"string",
"feedback":false,
"placeholder": "Enter Middle here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},


{
"key": "lastName",
"type":"string",
"feedback":false,
"placeholder": "Enter Last here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key" : "relation",
"type": "strapselect",
"placeholder": "None selected",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",
"options":
{

"httpGet": {"url": "assets/relation.json"}
}
},
{
"key" : "gender",
"type": "strapselect",
"placeholder": "None selected",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",
"options":
{

"httpGet": {"url": "assets/gender.json"}
}
},
{
  "key": "dob",
  "title": "Dob",
  "placeholder": "Select DOB",
  "type":"date",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
"key": "isDependant",
"title": "Is Dependent?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",
"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "isEmployee",
"title": "Is Employee?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",

"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "isMinor",
"title": "Is Minor?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",

"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "pfNominee",
"title": "PF Nominee?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",
"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "occupation",
"type":"string",
"placeholder": "Enter Occupation here",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "remarks",
"type":"string",
"placeholder": "Enter Remarks here",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



}



];



}
]);




/**
 * Created by pranesh on 15/12/2016.
 */

/*var app = angular.module('MyForm', );*/
    
    angular.module('app').controller('educationController', ['$scope','$http','ngDialog','$rootScope','$location','schemaForm','$stateParams',
  function($scope,$http,ngDialog,$rootScope,$location,$stateParams) {
    
     $scope.addRow = function(){

        $scope.EduUrl = "assets/Employee/education.html";
        $scope.educationModel={}
    };

     $scope.schema = {
        "type": "object",
        "title": "Comment",
        "properties": {

            "CourseCode": {
                "title": "Course Code",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":20,
                "minLength":3
            },
         "Course": {
                "title": "Course",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                 "maxLength":20,
                "minLength":3
            },
            "Duration": {
                "title": "Duration",
                "type": "number",
                "minimum": 1,
                "maximum": 5,
                "validationMessage": "              ",
                 "required":true
                 
            },
            "StartYear": {
                "title": "Start Year",
                type: "number",
                "minimum": 1900,
                "maximum": 2100,
                "validationMessage": "              ",
                 "required":true
            },
            "EndYear": {
                "title": "End Year",
               type: "number",
                "minimum": 1901,
                "maximum": 2100,
                "validationMessage": "              ",
                "required":true
            },
            "Class": {
                "title": "Class",
                "type": "string",
                "validationMessage": "              ",
                 "required":true
            },
            "Percentage": {
                "title": "Percentage (%)",
                 type: "number",
                "minimum":0,
                "maximum": 100,
                "validationMessage": "              ",
                 "required":true
            },
            "SplAchievement": {
                "title": "Spl Achievement",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":100,
                "minLength":5
            },
            "UniversityName": {
                "title": "University Name",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":50,
                "minLength":4
            },
            "InstitutionName": {
                "title": "Institution Name",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":50,
                "minLength":5
            },
            "City": {
                "title": "Duration",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":20,
                "minLength":3
            },
            "State": {
                "title": "State",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":20,
                "minLength":3
            },
            "Country": {
                "title": "Country",
                "type": "string",
                "validationMessage": "              ",
                 "required":true,
                "maxLength":20,
                "minLength":3
            },
            "PinCode": {
                "title": "Pin Code",
                "type": "string",
                "pattern":"[0-9]{6}",
                "minlength":6,
                "maxLength":6,
                "validationMessage": "              ",
                "required":true
            },
            "Comments": {
                "title": "Comments",
                "type": "string",
                "validationMessage": "              ",
               "required":true,
                "maxLength":200,
                "minLength":10
            }
        }

 }
    $scope.form = [

        {
            "key": "CourseCode",
            "title": "Course Code",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "Course Code",
            "disableSuccessState": true

        },
        {
            "key": "Course",
            "title": "Course",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Course",
            "disableSuccessState": true
        },
        {
            "key": "Duration",
            "title": "Duration",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Duration",
            "disableSuccessState": true
        },
        {
            "key": "StartYear",
            "title": "Start Year",
            "feedback":false,
            type:"number",
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Start Year",
            "disableSuccessState": true
        }, {
            "key": "EndYear",
            "title": "End Year",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "End Year",
            "disableSuccessState": true
        },
        {
            "key": "Class",
            "title": "Class",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "Class",
            "disableSuccessState": true

        },
        {
            "key": "Percentage",
            "title": "Percentage (%)",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Percentage (%)",
            "disableSuccessState": true
        },
        {
            "key": "SplAchievement",
            "title": "Spl Achievement",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Spl Achievement",
            "disableSuccessState": true
        },
        {
            "key": "UniversityName",
            "title": "University Name",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "University Name",
            "disableSuccessState": true
        }, {
            "key": "InstitutionName",
            "title": "Institution Name",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Institution Name",
            "disableSuccessState": true
        }, {
            "key": "City",
            "title": "City",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "City",
            "disableSuccessState": true
        },
        {
            "key": "State",
            "title": "State",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "State",
            "disableSuccessState": true

        },
        {
            "key": "Country",
            "title": "Country",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Country",
            "disableSuccessState": true
        },
        {
            "key": "PinCode",
            "title": "Pin Code",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Pin Code",
            "disableSuccessState": true
        },
        {
            "key": "Comments",
            "title": "Comments",
            "feedback":false,
            "type":"textbox",
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Comments",
            "disableSuccessState": true
        }
    ]
    $scope.educationModel={}
     if($scope.id ==null  ){
    
    $scope.id = 0;
  }

$scope.saveEducation=function(myForm){
    $scope.$broadcast('schemaFormValidate');
    // var mdata = {model:$scope.educationModel, cName:'employee',id:$scope.id}
    var mdata = {model:$scope.educationModel, cName:'employee',childColName:'education', id:'585b9fc6ba6f9074593ff18d'}
 
    alert(JSON.stringify(mdata));
    $http.post('/saveEmployee',mdata).success(function(data){
    $scope.educationDetails=data;
        
 }) 
    $scope.EduUrl = "";
};

   $scope.editEducation=function(edit_id){
    
    $scope.EduUrl = "assets/education.html";
    $scope.readonly = { formDefaults: { readonly : true } };
    var mdata = {cName:'education',Id:$rootScope.id,edit_id:edit_id}
    $http.post('/findClient',mdata).success(function(data){
        $scope.educationModel=data;
        $scope.id=$scope.educationModel._id;
    })
  }

  /*
   CreatedBy:CRM Team.
   Purpose:To Perform Delete Operation.
   */

   $scope.deleteEducationConfirm=function(Id){
    
    $scope.Id=Id;
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/ui-model-education_delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,

    });

  }
   
  $scope.deleteClient=function(Id){
    
    var mdata = {cName:'education',id:$scope.Id}
    $http.post('/deleteClient',mdata).success(function(data){
      $scope.educationDetails=data;
      $scope.Id = '';
      $scope.closeDialog();
      $scope.message = "Educaion details deleted Successfully"  
      $scope.showMessage("SUCCESS",  $scope.message); 
      
    });

  }


  $scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  $scope.cancel=function(){

      $scope.EduUrl = "";

  }




    $scope.cancel=function(){
        $scope.EduUrl = "";
    };

}]);

angular.module('app').controller('experienceController', ['$scope','$http','ngDialog','$timeout','$rootScope','$window',
  function($scope,$http,ngDialog,$timeout,$rootScope,$window) {

    $scope.alertUrl="assets/alert.tpl.html";

    $scope.showMessage=function(type, messsage){
    $scope.successalert=false;
    $scope.dangeralert=false;
    $scope.isVisible = true;

    if(type=="SUCCESS"){
     
        $scope.successalert=true;
        $timeout(function (){
            $scope.isVisible = false;
            $scope.message = messsage
        }, 3000);

    }else{
        $scope.dangeralert=true;
        $timeout(function (){
            $scope.isVisible = false;
        }, 3000);
    }
};

    $scope.addnew = function(){
      
      $scope.employeeDetailsmodel = {};
      $scope.ExpUrl = "assets/Employee/employeeExp.html";
      $scope.readonly = { formDefaults: { readonly: false } };
      
    };
    
     $scope.schema = {

        "type": "object",
        "title": "Comment",
        "properties": {
            "CompanyName":
            {
                "title": "Company Name",
                "type": "string"
            },


            "FromDate":
            {
                   "type": "date"
                  // "required":true,
            },


            "ToDate":
            {
                "type" : "date"
            },

            "Experience":
            {
                "title": "Experience",
                "type": "number",
                "minimum": 0
            },

            "Designation":
            {
                "title": "Designation",
                "type": "string",
            },

            "RelievingReason":
            {
                "title": "Relieving Reason",
                "type": "string",
            },

            "LastSalaryDrawn":
            {
                "title": "Last Salary Drawn",
                "type": "number",
                "minimum": 0
            },

            "Duties":
            {
                "title": "Duties",
                "type": "string",
            },

            "Achievements":
            {
                "title": "Achievements",
                "type" : "string",
            },

            "ReferencePerson":
            {
                "title": "Reference Person",
                "type": "string",
            },

            "Address":
            {
                "title": "Address",
                "type": "string",
            },

             "city" :
             {
               "title" : "city",
               "type" : "array",
               "items": {"type":"string"},
               "maxItems": 1,
             },


            "state" :
            {
                "title" : "state",
                "type" : "array",
                "items": {"type":"string"},
                "maxItems": 1,

            },

           "country" :
           {
               "title" : "country",
               "type" : "array",
               "items": {"type":"string"},
               "maxItems": 1,

           },


        }
    };
$scope.form=[

        {
            "key": "CompanyName",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Company Name"
        },

        {
          "key": "FromDate",
          "title": "From Date",
          "placeholder": "Select From Date",
          "type":"date",
          "feedback": false,
          "labelHtmlClass":"form-label"

        },

        {
          "key": "ToDate",
          "title": "To Date",
          "placeholder": "Select To Date",
          "type":"date",
          "minDate": "FromDate",
          "feedback": false,
          "labelHtmlClass":"form-label",
          "format":"yyyy-mm-dd"
        },

        {
            "key": "Experience",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "your experience is"

        },

        {
            "key": "Designation",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Designation "
        },


        {
            "key": "RelievingReason",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Relieving Reason"
        },


        {
            "key": "LastSalaryDrawn",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Last Salary Drawn "
        },


        {
            "key": "Duties",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter the Duties you Performed "
        },


        {
            "key": "Achievements",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Achievements "
        },


        {
            "key": "ReferencePerson",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Reference Person's Name "
        },


        {
            "key": "Address",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Address"
        },


        {
             "key" : "city",
             "type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/city.json"}
             }
        },


        {
             "key" : "state",
             "type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/state.json"}
             }
        },


        {
            "key" : "country",
            "type": "strapselect",
            "placeholder": "None selected",
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "options":
            {
             "multiple" : "true",
             "httpGet": {"url": "assets/country.json"}
            }
        }
    ];
/*
 CreatedBy:CRM Team.
 Purpose:To Perform Insert Operation.
 */
 $scope.employeeDetailsmodel={};

 
 $scope.saveCollection = function() {
 //var ex= $scope.employeeDetailsmodel.ToDate.getFullYear()-$scope.employeeDetailsmodel.FromDate.getFullYear();
  if($scope.id == null){
    $scope.id = 0;
  }

  var mdata = {model:$scope.employeeDetailsmodel, cName:'employee', id:$scope.id}
  $scope.$broadcast('schemaFormValidate');

    $http.post('/saveEmployeeData',mdata)
    .success(function(data){

        $scope.employeeDetails=data;
        $scope.employeeUrl = '';  
        $scope.message = "employee is added Successfully"  
        $scope.showMessage("SUCCESS",  $scope.message);    
     }) 

    .error(function(data){ console.log(data)
              $scope.message = "Error Occured pleas check the entry "
              $scope.showMessage("ERROR", $scope.message)
                  });

        $scope.ExpUrl="";
  }


  /*
   CreatedBy:CRM Team.
   Purpose:To Perform Update Operation.
   */
   $scope.editEmployee=function(edit_id){
    $scope.id=edit_id;
    $scope.ExpUrl = "assets/Employee/employeeExp.html";
    $scope.readonly = { formDefaults: { readonly : true } };
    var mdata = {cName:'employee',id:$scope.id}
    $http.post('/findEmployee',mdata).success(function(data){
        $scope.employeeDetailsmodel=data;
        $scope.id=$scope.employeeDetailsmodel._id;
    })
  }

  /*
   CreatedBy:CRM Team.
   Purpose:To Perform Delete Operation.
   */

   $scope.deleteEmployeeConfirm=function(Id){
    
    $scope.Id=Id;
    
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/Employee/ui-model-employee_Delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,

    });

  }

  $scope.deleteEmployee=function(Id){
    var mdata = {cName:'employee',id:$scope.Id}
    $http.post('/deleteEmployee',mdata).success(function(data){
      $scope.employeeDetails=data;
      $scope.Id = '';
      $scope.closeDialog();
      $scope.message = "Employee deleted Successfully"  
      $scope.showMessage("SUCCESS",  $scope.message); 
      
    });

  }


  $scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  $scope.cancel=function(){

      $scope.employeeUrl = '';

  }

}
]);






angular.module('app').controller('licInfoController', 
  ['$scope','$http','$timeout',function($scope,$http,$timeout) {


 $scope.schema={
   "type": "object",
   "title": "Comment",
   "properties": {
       
       
         "Type" :{
            "title" : "Type",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Policy_No": {
          "type": "number",
          "validationMessage":"              "
        },
       "Policy_Name": {
          "type": "string",
          "validationMessage":"              "
        },
        "Issued_Date": {
          "type": "date",
         "validationMessage":"              "
        },
        "Expiry_Date": {
          "type": "date",
          "validationMessage":"              "
        },
       "Insured_Amount": {
          "type": "number",
          "validationMessage":"              "
        },
       "Premium_Amount": {
          "type": "number",
          "validationMessage":"              "
        },
       "Nominee_Name": {
          "type": "string",
          "validationMessage":"              "
        },
       "Salary_Deductible?": {
          "type": "string",
          "validationMessage":"              "
        },
       "Deductible_Amount": {
          "type": "number",
          "validationMessage":"              "
        },
}
   };

$scope.form = [

    {
        "key" : "Type",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls ",
        "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/type.json"
                        }
                    }

        },
     {
     "key": "Policy_No",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Policy_Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Issued_Date",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "date"
     
   },
    {
     "key": "Expiry_Date",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "date"
     
   },
    {
     "key": "Insured_Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Premium_Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
   {
     "key": "Nominee_Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     {
     "key": "Salary_Deductible?",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Deductible_Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    
   
 ];



    

  $scope.modelLic = {};
  $scope.updateBtn=false;
  $scope.saveBtn=false;
    
    $scope.addnew=function()
    {
    $scope.urls='';
    $scope.updateBtn=false;
    $scope.saveBtn=true;
    $scope.modelLic = {};

 $timeout(function(){$scope.urls="assets/Employee/addemp_lic_info.html";},500)
       
    }

  $scope.onSubmitLic = function(form) {
    // First we broadcast an event so all fields 
    //validate themselves

   // $scope.$broadcast('schemaFormValidate');
 var mdata = {model: $scope.modelLic, cName:'employee', childColName:'licInfo', id:"585b9fc6ba6f9074593ff18d"}

    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/saveData',mdata)
         .success(function(data){
           $scope.urls='';
           
           $scope.loadLicData();
         
        });

    }
  }


  $scope.loadLicData=function(){

 var mdata = {cName:'employee',childColName:'licInfo', id:"585b9fc6ba6f9074593ff18d"}
   
$http.post('/getChildData',mdata)
         .success(function(data){
          $scope.licData=data;
         })
  }

$scope.editLic=function(modelEdit){
  $scope.urls='';
  $scope.updateBtn=true;
  $scope.saveBtn=false;
  $scope.modelLic=modelEdit
   alert(modelEdit.c_id)

//var mdata = {model: $scope.modelLic, cName:'employee', childColName:'licInfo', id:"585b9fc6ba6f9074593ff18d"}
 $timeout(function(){$scope.urls="assets/Employee/addemp_lic_info.html";},500)
  
}

$scope.onUpdateLic=function(form){

var mdata = {model: $scope.modelLic, cName:'employee', childColName:'licInfo', id:"585b9fc6ba6f9074593ff18d"}
alert(mdata.model.Policy_No)
    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/updateLicData',mdata)
         .success(function(data){
           $scope.urls='';
           $scope.loadLicData();
         
        });

    }

}

$scope.cancelLic= function(){
   $scope.urls='';

}

    }



    ]);

angular.module('app').controller('ErpCtrl', ['$scope','$http','ngDialog','$rootScope','$location','schemaForm','$stateParams',
  function($scope,$http,ngDialog,$rootScope,$location,$stateParams) {

    $scope.addRow = function(){
            
                  $scope.vehiclemodel={};
                  $scope.erp="assets/Employee/vehicleinfo.html";
                 }     

//                   $scope.showMessage=function(type, messsage){
//     $scope.successalert=false;
//     $scope.dangeralert=false;
//     $scope.isVisible = true;

//     if(type=="SUCCESS"){
     
//         $scope.successalert=true;
//         $timeout(function (){
//             $scope.isVisible = false;
//             $scope.message = messsage
//         }, 3000);

//     }else{
//         $scope.dangeralert=true;
//         $timeout(function (){
//             $scope.isVisible = false;
//         }, 3000);
//     }
// };


$scope.schema = {
            "type": "object",
            "title": "Comment",
            "properties": {
            "VehicleType": {
                                "title": "Vehicle Type",
                                "type": "string",
                                "required":true,
                                 "enum": [
                                              "Two Wheeler",
                                              "Three Wheeler",
                                              "Four Wheeler",
                                              "Six Wheeler"
                                           ]
             },

             "VehicleColorType":{
                                 "title":"Vehicle Color Type",
                                 "type":"string",
                                 "required":true,
                                 "enum": [
                                              "RED",
                                              "BLUE",
                                              "GREEN",
                                              "BLACK",
                                              "WHITE"
                                           ]
              },

              "VehicleMake": {

                                 "title": "Vehicle Make",
                                 "type": "string",
                                   //  "required": true,
                                 "validationMessage": "              "
               },

               "vehicleReg No":{

                                 "title":"vehicle Reg No",
                                 //  "pattern":"[789][0-9]{9}",
                                 "type":"integer",
                                 "validationMessage":"          ",
                                 "maxLength":10
                                   //"minLength":10,
                },

                "vehicleModel": {

                                 "title": "vehicle Model",
                                 "type": "string",
                                      //"pattern": "[0-9A-Za-z]{1,64}[\@][0-9a-zA-Z\-]{1,63}[\.][a-zA-Z\-]{2,24}",
                                      //"required":true,
                                     // "maxLength": 20
                                 "validationMessage":"     "
                 },


                "VehicleRegistration":{
                                            "title":"Vehicle Registration",
                                            "type":"integer",
                                            //"required":true,
                                            "validationMessage":"              "
                                        //    "minLength":4,
                                          //   "min":1
                  },

                  "VehicleOwner":{
                                              "title":"Vehicle Owner",
                                              "type":"string",
                                                              //"required":true,
                                              "validationMessage":"              "
                                             // "minLength":4,
                                             // "min":1
                    },

                    "VehicleDescription":{
                                         "title":"Vehicle Description",
                                         "type":"string",
                                         //"required":true,
                                         "validationMessage":"              "
                                        // "minLength":4,
                                        // "min":1
                     },

                     "ParkingSticker Issue Date ":{
                                           "title":" Parking Sticker Issue Date ",
                                           "type":"date",
                                       //"required":true,
                                           "validationMessage":"              "
                                          // "minLength":4,
                                           //"min":1
                      },

                      "ParkingSticker Expiry Date":{
                                            "title":"Parking Sticker Expiry Date",
                                            "type":"date",
                                            //"required":true,
                                            "validationMessage":"              "
                                           // "minLength":4,
                                           // "min":1
                       },

                       "Parking Slot":{
                                            "title":"Parking Slot",
                                            "type":"date",
                                             //"required":true,
                                            "validationMessage":"              "
                                            //"minLength":4,
                                            //"min":1
                       }
             }
        }

$scope.form=[
            {
                            "key": "VehicleType",
                            "feedback": false,
                            "htmlClass":"form-group control",
                            "labelHtmlClass":"form-label",
                            "placeholder": "SELECT TYPE"
            },

            {
                            "key": "VehicleColorType",
                            //"type":"string",
                            "feedback":false,
                            "htmlClass":"form-group control",
                            "labelHtmlClass":"form-label",
                            "placeholder": "SELECT VEHICLE COLOR"

            },

            {
                             "key": "VehicleMake",
                             "feedback":false,
                             "htmlClass":"form-group control",
                             "labelHtmlClass":"form-label",
                             "placeholder": " Makers Name ",
                             "disableSuccessState":true


            },

            {
                             "title":"vehicle Reg No",
                             "key": "vehicleRegNo",
                             "type":"string",
                             "feedback":false,
                             "htmlClass":"form-group control",
                             "labelHtmlClass":"form-label",
                             "placeholder": "ENTER REG NO",
                             "disableSuccessState":true
            },

            {
                              "title":"vehicle Model",
                              "key": "vehicleModel",
                              "type": "string",
                              "placeholder": "ENTER VEHILCE MODEL",
                              "htmlClass":"form-group control",
                              "labelHtmlClass":"form-label",
                              "disableSuccessState":true
 
            },


            {
                              "title":"Vehicle Registration",
                               "key": "VehicleRegistration",
                               "type":"number",
                               "feedback":false,
                               "placeholder":"ENTER VEHICLE REGISTRATION ",
                               "htmlClass":"form-group control",
                               "labelHtmlClass":"form-label",
                               "disableSuccessState":true

            },

            {
                                "title":"Vehicle Owner",
                                "key": "VehicleOwner",
                                "type":"string",
                                "feedback":false,
                                "placeholder":"ENTER VEHICLE OWNER",
                                "htmlClass":"form-group control",
                                "labelHtmlClass":"form-label",
                                "disableSuccessState":true

             },

             {
                                  "title":"Vehicle Description",
                                  "key": "VehicleDescription",
                                  "type":"string",
                                  "feedback":false,
                                  "placeholder":"DESCRIPTION",
                                  "htmlClass":"form-group control",
                                  "labelHtmlClass":"form-label",
                                  "disableSuccessState":true

              },

             {
                                   "title":"Parking Sticker Issue Date",
                                   "key": "ParkingStickerIssueDate",
                                   "type":"date",
                                   "feedback":false,
                                   "placeholder":"dd/mm/yyyy",
                                   "htmlClass":"form-group control",
                                   "labelHtmlClass":"form-label",                            
                                   "disableSuccessState":true
              },

              {
                                    "title":"Parking Sticker Expiry Date",
                                    "key": "ParkingStickerExpiryDate",
                                    "type":"date",
                                    "feedback":false,
                                    "placeholder":"dd/mm/yyyy",
                                    "htmlClass":"form-group control",
                                    "labelHtmlClass":"form-label",
                                    "disableSuccessState":true

              },

              {
                                     "title":"Parking Slot",
                                     "key": "Parkingslot",
                                      "type":"string",
                                      "feedback":false,
                                      "placeholder":"ENTER PARKING SLOT LOCATION",
                                      "htmlClass":"form-group control",
                                      "labelHtmlClass":"form-label",
                                      "disableSuccessState":true

               }

        ]



$scope.vehiclemodel={};

$scope.vehicleSubmit = function(form) 
{

  if($scope.id ==null  ){
    
                       $scope.id = 0;
                  }
           
  var mdata = {model:$scope.vehiclemodel, cName:'vehicle', id:$scope.id}
    
    $scope.$broadcast('schemaFormValidate');
  
     if (form.$valid) {

        $http.post('/saveVehicleData',mdata)
        .success(function(data){
                             $scope.VehicleDetails=data;

                             $scope.erp = '';  
                             $scope.message = "Vehicle is added Successfully"  
                             $scope.showMessage("SUCCESS",  $scope.message);    
                                 })
              
        .error(function(data){ console.log(data)
                           $scope.message = "Error Occured pleas check the entry "
                           $scope.showMessage("ERROR", $scope.message)
                           });
            }
     
        // $scope.erp = "";
}

$scope.editVehicle=function(edit_id){
    
    $scope.erp = "assets/Employee/vehicleinfo.html";
    $scope.readonly = { formDefaults: { readonly : true } };
    var mdata = {cName:'vehicle',Id:$rootScope.id,edit_id:edit_id}
    $http.post('/findVehicle',mdata).success(function(data){
        $scope.vehiclemodel=data;
        $scope.id=$scope.vehiclemodel._id;
    })
  }

   $scope.deleteVehicleConfirm=function(Id){
    
    $scope.Id=Id;
    
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/Employee/ui-model-vehicle_Delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,

    });

  }

  $scope.deleteVehicle=function(Id){
    var mdata = {cName:'vehicle',id:$scope.Id}
    $http.post('/deleteClient',mdata).success(function(data){
      alert(JSON.stringify(data))
      $scope.VehicleDetails=data;
      $scope.Id = '';
      $scope.closeDialog();
      $scope.message = "Vehicle deleted Successfully"  
      $scope.showMessage("SUCCESS",  $scope.message); 
      
    });

  }
  $scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  $scope.cancel=function(){

      $scope.erp = '';
      $rootScope.id=null;
      $state.go($state.$current, null, { reload: true });

  }

  }]);
     

 angular.module('app').controller('jobStatusTableController', ['$scope','$http','ngDialog','$timeout','$rootScope','$window',
  function($scope,$http,ngDialog,$timeout,$rootScope,$window) {


// $scope.addEmployee=function()
// {
//   alert("hiiiiii")
//   $scope.JobUrl="assets/jobdetails.html";

// };


        $scope.addEmployee = function(){

            $scope.jobUrl = "assets/Employee/jobdetails.html";
        }
$scope.cancel = function(){
            
            $scope.jobUrl = "";
        }

// $scope.save= function(){
//             $scope.jobDetailsModel.push({ 'id':$scope.id, 'status': $scope.status, 'department':$scope.department,'designation': $scope.designation, 'reportingManager':$scope.reportingManager,'fromDate': $scope.fromDate, 'toDate':$scope.toDate });
//   $scope.id='';
//   $scope.status='';
//   $scope.department='';
//   $scope.designation='';
//   $scope.reportingManager='';
//   $scope.fromDate='';
//   $scope.toDate='';

//         }





$scope.schema={
 "type": "object",
        "title": "Comment",
        "properties": {

"Category":{
  "title":"Category",
  "type":"string",
  "required":true,

  "validationMessage":"required"

  },
  "Department":{
   "title":"Department",
   "type":"string",
   "required":true,
   "validationMessage":"required"
  },
  "Designation":{
  "title":"Designation",
  "type":"string",
  "required":true,
  "validationMessage":"required"
    },
   "ReportingManager":{
  "title":"Reporting Manager",
   "type":"string",
   "required":true,
   "validationMessage":"required"
   },
   "FromDate":{
  
    "type":"date",
    "validationMessage":"required"

   },
   "ToDate":{
   
    "type":"date",
    "validationMessage":"required"
   // "format":"date"
   },
   "RelievingReson":{
     "title":"Relieving Reson",
      "type":"string",
      "required":true,
      "validationMessage":"required"
      },
      "RefferedpersonName":{
      "title":"Reffered person Name",
      "type":"string",
      "required":true,
        "validationMessage":"required"
      },
      "Remarks":{
      "title":"Remarks",
      "type":"string",
       "required":true,
         "validationMessage":"required"
      }
}

}
$scope.form=[

{
"key":"Category",
"placeholder":"Enter Category",
"type":"select",
"titleMap": [
      {
        "value": "a",
        "name": "TRAINEE"
      },
      {
        "value": "b",
        "name": "PERMANENT"
      },
      {
        "value": "c",
        "name": "CONTRACT"
      },
      {
           "value": "d",
              "name": "PROBATIONARY"
            }
    ]

},
{
"key":"Department",
"placeholder":"Enter Department"

},
{
"key":"Designation",
"placeholder":"Enter Designation"

},
{
"key":"ReportingManager",
"placeholder":"Enter ReportingManager"

},
{
"key":"FromDate",
"placeholder":"DD/MM/YYYY",
"title":"From Date",
"type":"date"
},
{
"key":"ToDate",
"title":"To Date",
"placeholder":"DD/MM/YYYY",
"type":"date"

},
{
"key":"RelievingReson",
"placeholder":"Enter Relieving Reson"

},
{
"key":"RefferedpersonName",
"placeholder":"Enter Reffered PersonName"

},
{
"key":"Remarks",
"type":"textarea"

}

];
$scope.modelJob={};

$scope.saveCollection = function() {


    if($scope.id==null){
        $scope.id = 0;
    }
    var mdata = {model:$scope.modelJob, cName:'jobdetails', id:$scope.id}
    $http.post('/saveJobDetailsData',mdata)
    .success(function(data){
        $scope.jobDetailsModel=data;
        $scope.jobUrl = '';
        $scope.id=null;
        $scope.message = "Job is added Successfully"  
        $scope.showMessage("SUCCESS",  $scope.message);    
     }) 
    .error(function(data){ console.log(data)
              $scope.message = "Error Occured please check the entry "
              $scope.showMessage("ERROR", $scope.message)
                  });
}

$scope.editEmployee=function(edit_id){    
    $scope.id=edit_id;
     $scope.jobUrl = "assets/Employee/jobdetails.html";
    var mdata = {cName:'jobdetails',Id:$scope.id}
    $http.post('/jobData',mdata).success(function(data){
      alert(data);
                 $scope.modelJob=data;
          })
  }

$scope.delete=function(Id){
    $scope.Id=Id;
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/Employee/ui-model-employee_Delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,
    });
  }

  $scope.deleteJob=function(Id){
    
    var mdata = {cName:'jobdetails',Id:Id}
    $http.post('/deleteJob',mdata).success(function(data){
              $scope.jobDetailsModel=data;
              $scope.Id=null;
              $scope.closeDialog();
              $scope.message = "job deleted Successfully"  
              $scope.showMessage("SUCCESS",  $scope.message); 
        })
  }
$scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  $scope.cancel=function(){
      $scope.jobUrl = '';
  }  

}]);

angular.module('app').controller('contactController', ['$scope','$rootScope','$http',
    function($scope,$rootScope,$http) {


var mdata = {cName:'employee',childColName:'contact', id:$rootScope.modelEmpInfo._id}
 alert("$rootScope.modelEmpInfo._id.."+$rootScope.modelEmpInfo._id)

$http.post('/getChildData',mdata)
         .success(function(data){
       alert("data.."+data)
       if(data==0){
        $scope.modelContact={}
        $scope.savefield=1
       }
       else{
           $scope.modelContact=data[0];
            $scope.savefield=0
       }
         
         
         })
     

  

         $scope.schema = {
        "type": "object",
        "title": "Comment",
        "properties": {
            "Phone No": {
                "title": "Phone Number",
                "type": "string",
                "pattern": "[0-9]{3}[-][0-9]{6,8}",
                "validationMessage": "Please Enter a Valid Phone Number eg. 044-444444",
                "validationState":false
            },

            "Mobile No 1":{
                 "title": "Mobile Number 1",
                 "type": "string",
                "required": true,
                "pattern":"^[0-9()\\-\\.\\s]+$",
                "minLength":10,
                 "maxLength":10,
                 "validationMessage": "Please Enter a Valid 10-digit Mobile Number 1",
                    },

            "Mobile No 2": {
                "title": "Mobile Number 2",
                "type": "string",
               //"required": true,
                "pattern":"^[0-9()\\-\\.\\s]+$",
                "minLength":10,
                "maxLength":10,
                "validationMessage": "Please Enter a Valid 10-digit Mobile Number 2",
                        },


            "Email Id": {
                "title": "Email Id",
                "type": "string",
               //"required": true,
               "pattern":"^\\S+@\\S+$",
                "validationMessage": "Please Enter a Valid Email Id",
                        }

        }
    }

    $scope.form=[

        {
            "key": "Phone No",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Valid Phone Number"
        },

        {
            "key": "Mobile No 1",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Valid Mobile Number"

        },

        {
            "key": "Mobile No 2",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Pager Number"
        },

        {
            "key": "Email Id",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Valid Email Id"
        }
    ]





  //  $scope.modelContact={};

    $scope.onSubmitContact = function(form) {
     
      if (form.$valid) {

       if($scope.savefield==1){

       var mdata = {model: $scope.modelContact, cName:'employee', childColName:'contact', id:$rootScope.modelEmpInfo._id}

    // Then we check if the form is valid
   
          $http.post('/saveData',mdata)
         .success(function(data){
         
      $scope.employeePageUrl="assets/Employee/bankinfo.html";
                
         
        });

    }
    else{
       var mdata = {model: $scope.modelContact, cName:'employee', childColName:'contact', id:$rootScope.modelEmpInfo._id}
//childColName,cName,model.c_id,id
     
          $http.post('/updateChildData',mdata)
         .success(function(data){
         
      $scope.employeePageUrl="assets/Employee/bankinfo.html";

    })

     }
    


    }

    }

   } ]);
angular.module('app').controller('bankInfoController', ['$scope','$rootScope','$http',
    function($scope,$rootScope,$http) {

alert("bankController")
var mdata = {cName:'employee',childColName:'bankInfo', id:$rootScope.modelEmpInfo._id}
 alert("$rootScope.modelEmpInfo._id.."+$rootScope.modelEmpInfo._id)


$http.post('/getChildData',mdata)
         .success(function(data){
       alert("data.."+data)
       if(data==0){
        $scope.modelBank={}
        $scope.savefield=1
       }
       else{
           $scope.modelBank=data[0];
            $scope.savefield=0
       }
         alert(" $scope.savefield..."+ $scope.savefield)
         
         })
     



      
         $scope.schema = {
  "type": "object",
  "title": "Comment",
  "properties": {

"Bank IFSC":{
"title" : "Bank IFSC",
"type" : "string",
"required":true


},

"Bank A/C": {
"title": "Bank A/C",
"validationMessage": "",
"type": "number",
"required":true
},

"Branch Address": {
"title": "Branch Address",

"type": "string",
"required":true


},

"Salary Account": {
"title": "Salary Account",


"type": "string",
"required":true,

},

},

};

$scope.form = [


{
"key": "Bank IFSC",
"type": "string",
"feedback":false,
"placeholder":"enter bank ifsc",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key":"Bank A/C",
"type": "number",
"placeholder":"enter bank a/c",
"feedback": false,
"htmlClass": "form-group  controls",
"labelHtmlClass": "form-label",



},


{
"key": "Branch Address",
"type":"string",
"placeholder":"enter branch address",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "Salary Account",
"type":"string",
"placeholder":"enter salary account",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



}


];

  //$scope.model = {};

 $scope.submitBank = function(form) {
     alert("form.$valid.."+form.$valid)
     
      if (form.$valid) {

       if($scope.savefield==1){

       var mdata = {model: $scope.modelBank, cName:'employee', childColName:'bankInfo', id:$rootScope.modelEmpInfo._id}

    // Then we check if the form is valid
   
          $http.post('/saveData',mdata)
         .success(function(data){
         
       $scope.employeePageUrl="assets/Employee/skilldetails.html";
                   
         
        });

    }
    else{
       var mdata = {model: $scope.modelContact, cName:'employee', childColName:'bankInfo', id:$rootScope.modelEmpInfo._id}
//childColName,cName,model.c_id,id
     
          $http.post('/updateChildData',mdata)
         .success(function(data){
         
     $scope.employeePageUrl="assets/Employee/skilldetails.html";
      
    })

     }
    


    }

    }

   } ]);



angular.module('app').controller('skilldetailsController', ['$scope','$rootScope','$http',
    function($scope,$rootScope,$http) {


var mdata = {cName:'employee',childColName:'skillInfo', id:$rootScope.modelEmpInfo._id}
 
 alert("$rootScope.modelEmpInfo._id.."+$rootScope.modelEmpInfo._id)


$http.post('/getChildData',mdata)
         .success(function(data){
       alert("data.."+data)
       if(data==0){
        $scope.modelSkill={}
        $scope.savefield=1
       }

       else{

            $scope.modelSkill=data;
            $scope.savefield=0
       }
      
         
         })
     

 
        $scope.schema = {

        "type": "object",
        "title": "Comment",
        "properties": {


             "skill" :
             {
               "title" : "Skills",
               "type" : "array",
               "items": {"type":"string"},
                //"maxItems": 1,
             }


        }
    }

    $scope.form=[



        {
             "key" : "skill",
             "type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/skill.json"}
             }
        },



    ]

    



    $scope.saveSkill = function(form) {

     if (form.$valid) {

       if($scope.savefield==1){

       var mdata = {model: $scope.modelSkill, cName:'employee', childColName:'skillInfo', id:$rootScope.modelEmpInfo._id}

    // Then we check if the form is valid
   
          $http.post('/saveData',mdata)
         .success(function(data){
         
      $scope.employeePageUrl="assets/Employee/empphoto.html";
                    
         
        });

    }
    else{
       var mdata = {model: $scope.modelSkill, cName:'employee', childColName:'skillInfo', id:$rootScope.modelEmpInfo._id}
//childColName,cName,model.c_id,id
     
       $http.post('/updateChildData',mdata)
         .success(function(data){
         
     $scope.employeePageUrl="assets/Employee/empphoto.html";
          
    })

     }
    


    }

    }

   } ]);


angular.module('app').controller('emp_lic_info_tableController', ['$scope','$http',
    function($scope,$http) {
        $scope.schema={
   "type": "object",
   "title": "Comment",
   "properties": {
       
       
         "Type" :{
            "title" : "Type",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Policy No": {
          "type": "string",
           "required":true,
          "validationMessage":"              "
        },
       "Policy Name": {
          "type": "string",
          "validationMessage":"              "
        },
        "Issued Date": {
          "type": "string",
          "required":true,
          "validationMessage":"              "
        },
        "Expiry Date": {
          "type": "string",
          "validationMessage":"              "
        },
       "Insured Amount": {
          "type": "string",
          "validationMessage":"              "
        },
       "Premium Amount": {
          "type": "string",
          "validationMessage":"              "
        },
       "Nominee Name": {
          "type": "string",
          "validationMessage":"              "
        },
       "Salary Deductible?": {
          "type": "string",
          "validationMessage":"              "
        },
       "Deductible Amount": {
          "type": "string",
          "validationMessage":"              "
        },
}
   };

$scope.form = [

    {
        "key" : "Type",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls col-lg-7 col-md-7 col-sm-7 col-xs-7",
        "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/type.json"
                        }
                    }

        },
     {
     "key": "Policy No",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Policy Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Issued Date",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "date"
     
   },
    {
     "key": "Expiry Date",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "date"
     
   },
    {
     "key": "Insured Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Premium Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
   {
     "key": "Nominee Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     {
     "key": "Salary Deductible?",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Deductible Amount",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    
  
 ];



  $scope.model = {};
    
    $scope.addnew=function()
    {
       
        $scope.urls="assets/Employee/addemp_lic_info.html";
    }

  $scope.onSubmit = function(form) {
    // First we broadcast an event so all fields validate themselves
    $scope.$broadcast('schemaFormValidate');

    // Then we check if the form is valid
    if (form.$valid) {
      // ... do whatever you need to do with your data.
    }
  }
    }
    ]);


// lazyload config

angular.module('app')
    /**
   * jQuery plugin config use ui-jq directive , config the js and css files that required
   * key: function name of the jQuery plugin
   * value: array of the css js file located
   */
  .constant('JQ_CONFIG', {
      easyPieChart:   [   'assets/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.fill.js'],
      plot:           [   'assets/bower_components/flot/jquery.flot.js',
                          'assets/bower_components/flot/jquery.flot.pie.js', 
                          'assets/bower_components/flot/jquery.flot.resize.js',
                          'assets/bower_components/flot.tooltip/js/jquery.flot.tooltip.js',
                          'assets/bower_components/flot.orderbars/js/jquery.flot.orderBars.js',
                          'assets/bower_components/flot-spline/js/jquery.flot.spline.js'],
      knob:           [   'assets/bower_components/jquery-knob/dist/jquery.knob.min.js', 'js/jq/chart-knobs.js'],
     /* isotobe:          [  'js/uport_isotobe.js',
                            'js/uport_isotobe_script.js'],*/
      dataTable:      [   'assets/bower_components/datatables/media/js/jquery.dataTables.min.js',
                          'assets/bower_components/plugins/integration/bootstrap/3/dataTables.bootstrap.js',
                          'assets/bower_components/plugins/integration/bootstrap/3/dataTables.bootstrap.css'],
      footable:       [ 'assets/bower_components/footable/dist/footable.all.min.js',
                          'assets/bower_components/footable/css/footable.core.css'],
      fullcalendar:   [   'assets/bower_components/moment/moment.js',
                          'assets/bower_components/fullcalendar/dist/fullcalendar.min.js',
                          'assets/bower_components/fullcalendar/dist/fullcalendar.css',],
      vectorMap:      [   'assets/bower_components/bower-jvectormap/jquery-jvectormap-1.2.2.min.js', 
                          'assets/bower_components/bower-jvectormap/jquery-jvectormap-world-mill-en.js',
                          'assets/bower_components/bower-jvectormap/jquery-jvectormap-us-aea-en.js',
                          'assets/bower_components/bower-jvectormap/jquery-jvectormap-1.2.2.css'],
      sortable:       [   'assets/bower_components/html5sortable/jquery.sortable.js'],
      nestable:       [   'assets/bower_components/nestable/jquery.nestable.js'],
      moment:         [   'assets/bower_components/moment/moment.js'],
      daterangepicker:[   'assets/bower_components/moment/moment.js',
                          'assets/bower_components/bootstrap-daterangepicker/daterangepicker.js',
                          'assets/bower_components/bootstrap-daterangepicker/daterangepicker.css'],
      tagsinput:      [ 'assets/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.js',
                          'assets/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.css'],
      jqueryui:        [  'assets/bower_components/jquery-ui/ui/minified/jquery-ui.min.js',
                          'assets/bower_components/jquery-ui/themes/smoothness/jquery-ui.css',
                          'js/controllers/ui.slider.js'],
      TouchSpin:      [   'assets/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js',
                          'assets/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css'],
      chosen:         [   'assets/bower_components/chosen/chosen.jquery.min.js',
                          'assets/bower_components/bootstrap-chosen/bootstrap-chosen.css'],
      wysiwyg:        [   'assets/bower_components/bootstrap-wysiwyg/bootstrap-wysiwyg.js',
                          'assets/bower_components/bootstrap-wysiwyg/external/jquery.hotkeys.js'],
      sparkline:       [   'assets/bower_components/jquery.sparkline/dist/jquery.sparkline.retina.js']
    }
  )

  // oclazyload config
  .config(['$ocLazyLoadProvider', function($ocLazyLoadProvider) {
      // We configure ocLazyLoad to use the lib script.js as the async loader
      $ocLazyLoadProvider.config({
          debug:  true,
          events: true,
          modules: [
              {
                  name: 'ngMorris',
                  files: [
                      'assets/bower_components/raphael/raphael.js',
                      'assets/bower_components/mocha/mocha.js',
                      'assets/bower_components/morrisjs/morris.js',
                      'assets/bower_components/ngmorris/src/ngMorris-full.js',
                      'assets/bower_components/morrisjs/morris.css'
                  ]
              },
              {
                  name:'cgNotify',
                  files: [
                      'assets/bower_components/angular-notify/dist/angular-notify.min.js',
                      'assets/bower_components/angular-notify/dist/angular-notify.min.css'
                  ]
              },
              {
                  name:'countTo',
                  files: [
                      'assets/bower_components/angular-count-to/build/angular-count-to.min.js'
                  ]
              },
                                      
              {
                  name:'angularFileUpload',
                  files: [
                    'assets/bower_components/angular-file-upload/dist/angular-file-upload.min.js'
                  ]
              },
              {
                  name: 'textAngular',
                  series: true,
                  files: [
                      'assets/bower_components/textAngular/dist/textAngular.css',
                      'assets/bower_components/textAngular/dist/textAngular-rangy.min.js',
                      'assets/bower_components/textAngular/dist/textAngular.min.js'
                  ]
              },
              {
                  name: 'vr.directives.slider',
                  files: [
                      'assets/bower_components/venturocket-angular-slider/build/angular-slider.min.js',
                      'assets/bower_components/venturocket-angular-slider/build/angular-slider.css'
                  ]
              },
              {
                  name: 'ngGrid',
                  files: [
                      'assets/bower_components/ng-grid/build/ng-grid.min.js',
                      'assets/bower_components/ng-grid/ng-grid.min.css',
                      'assets/bower_components/ng-grid/ng-grid.bootstrap.css'
                  ]
              },
              {
                  name: 'ui.grid',
                  files: [
                      'assets/bower_components/angular-ui-grid/ui-grid.min.js',
                      'assets/bower_components/angular-ui-grid/ui-grid.min.css'
                  ]
              },
              {
                  name: 'chart.js',
                  files: [
                      'assets/bower_components/angular-chart.js/dist/angular-chart.js',
                      'assets/bower_components/angular-chart.js/dist/angular-chart.css'
                  ]

              },
              {
                  name: 'angular-rickshaw',
                  files: [
                    'assets/bower_components/rickshaw/rickshaw.min.css',
                    'assets/bower_components/rickshaw/rickshaw.min.js',
                    'assets/bower_components/angular-rickshaw/rickshaw.js'
                  ]

              },
              {
                  name: 'xeditable',
                  files: [
                      'assets/bower_components/angular-xeditable/dist/js/xeditable.min.js',
                      'assets/bower_components/angular-xeditable/dist/css/xeditable.css'
                  ]
              },
              {
                  name:'ui.calendar',
                  files: ['assets/bower_components/angular-ui-calendar/src/calendar.js']
              },
              {
                  name: 'ngImgCrop',
                  files: [
                      'assets/bower_components/ngImgCrop/compile/minified/ng-img-crop.js',
                      'assets/bower_components/ngImgCrop/compile/minified/ng-img-crop.css'
                  ]
              },
              {
                  name: 'colorpicker.module',
                  files: [
                      'assets/bower_components/angular-bootstrap-colorpicker/js/bootstrap-colorpicker-module.js',
                      'assets/bower_components/angular-bootstrap-colorpicker/css/colorpicker.css'
                  ]
              },
              {
                  name: 'smart-table',
                  files: [
                      'assets/bower_components/angular-smart-table/dist/smart-table.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular',
                  files: [
                      'assets/bower_components/videogular/videogular.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular.plugins.controls',
                  files: [
                      'assets/bower_components/videogular-controls/vg-controls.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular.plugins.buffering',
                  files: [
                      'assets/bower_components/videogular-buffering/vg-buffering.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular.plugins.overlayplay',
                  files: [
                      'assets/bower_components/videogular-overlay-play/vg-overlay-play.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular.plugins.poster',
                  files: [
                      'assets/bower_components/videogular-poster/vg-poster.min.js'
                  ]
              },
              {
                  name: 'com.2fdevs.videogular.plugins.imaads',
                  files: [
                      'assets/bower_components/videogular-ima-ads/vg-ima-ads.min.js'
                  ]
              }
          ]
      });
  }])
;

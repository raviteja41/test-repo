'use strict';

/**
 * Config for the router
 */
 angular.module('app')
 .config(
    ['$stateProvider', '$urlRouterProvider', 'JQ_CONFIG',
    function($stateProvider, $urlRouterProvider, JQ_CONFIG) {

        $urlRouterProvider

        .otherwise('/app/employeeDashboard');
        
        $stateProvider
        .state('app', {
            abstract: true,
            url: '/app',
            templateUrl: 'assets/app.html'
        })

.state('app.employeeDashboard', {
        
            url: '/employeeDashboard',
            templateUrl: 'assets/Employee/app_dashboard.html',
              resolve: {
                            deps: ['$ocLazyLoad',
                                function($ocLazyLoad) {
                                    return $ocLazyLoad.load('chart.js').then(
                                            function() {
                                                return $ocLazyLoad.load('assets/controllers/dashboard.js');
                                            }
                                        )
                                        .then(
                                          function(){
                                               return $ocLazyLoad.load('assets/bower_components/font-awesome/css/font-awesome.css');
                                            }
                                          )/*.then(
                                          function(){
                                                return $ocLazyLoad.load('js/directives/ui-todowidget.js');
                                         }
                                      )*/
                                    ;
                                }
                            ]
                        }
        })
.state('app.employee', {

    url: '/employee',
    templateUrl: 'assets/Employee/Erp-Employees.html'
})


 .state('app.doctor', {
    url: '/doctor',
    templateUrl: 'assets/Doctor/add_doctor.html',
               
                    })
.state('app.tabs', {
    url: '/masteremployee',
    templateUrl: 'assets/Employee/masteremployee.html',
    resolve: {
        deps: ['$ocLazyLoad',
            function($ocLazyLoad) {
                return $ocLazyLoad.load('chart.js').then(
                      function(){
                           return $ocLazyLoad.load('assets/bower_components/font-awesome/css/font-awesome.css');
                        }
                      );
            }
        ]
    }
})

.state('app.employeeinfo', {
    url: '/employeeinfo',
    templateUrl: 'assets/Employee/generalinfo.html',
    resolve: {
    deps: ['$ocLazyLoad',
        function($ocLazyLoad) {
            return $ocLazyLoad.load('chart.js').then(
                  function(){
                       return $ocLazyLoad.load('assets/schema/tabs.js');
                    }
                  ).then(
                  function(){
                       return $ocLazyLoad.load('assets/bower_components/font-awesome/css/font-awesome.css');
                    }
                  );
        }
    ]
    }
})


.state('app.employeeReg', {
            url: '/employeeReg',
            templateUrl: 'assets/Employee/employeeReg.html'
        })
.state('app.employeeSearch', {
            url: '/employeeSearch',
            templateUrl: 'assets/Employee/employeeSearch.html'
        })
.state('app.employeeTbd', {
            url: '/employeeTbd',
            templateUrl: 'assets/Employee/employeeTbd.html'
        })


        .state('app.bde', {
            url: '/bde',
            templateUrl: 'assets/Bde/app_bde.html'
        })

        .state('app.roleMapping', {
            url: '/roleMapping',
            templateUrl: 'assets/RoleMapping/add_roleMapping.html',

            controller : function($rootScope,$scope,$http){

                $http.get('/findAllRoles?cName=roleMapping').success(function(data){
                    $scope.roleMappingDetails = data;
                    $scope.currentPage = 1;
                    $scope.itemsPerPage = 4;
                    
                })
                
            }
        })

        .state('app.editBdes', {
            url: '/editBdes/:bdeId',
            templateUrl: 'assets/Bde/app_bde.html',
            controller : function($scope,$stateParams){
                $scope.id=$stateParams.bdeId;
            }
        })
        .state('app.appbde', {
            url: '/appbde',
            templateUrl: 'assets/Bde/app_bde.html',
            controller : function($rootScope,$scope){
               $scope.id=null;
               $rootScope.bdeEduDetail = false;
               $rootScope.bdeExpDetail = false;
           }
       })
        .state('app.viewBde', {
            url: '/viewBde',
            templateUrl: 'assets/Bde/app_viewBde.html'
        })
        .state('app.editDoctor', {
            url: '/editDoctor/:doctorId',
            templateUrl: 'assets/Doctor/add_doctor.html',
            controller : function($scope,$stateParams){
                $scope.id=$stateParams.doctorId;
            }
        })
        .state('app.addDoctor', {
            url: '/addDoctor',
            templateUrl: 'assets/Doctor/add_doctor.html',
            controller : function($rootScope,$scope){
               $scope.id=null;
               $rootScope.doctorEduDetail = false;
               $rootScope.doctorExpDetail = false;
               $rootScope.doctorUpload = false;
           }
       })


        .state('app.viewDoctor', {
            url: '/viewDoctor',
            templateUrl: 'assets/Doctor/app_viewDoctor.html'
        })
        .state('app.editUsers', {
            url: '/editUsers/:uId',
            templateUrl: 'assets/UserManagement/userManagement.html',
            controller : function($scope,$stateParams){
                $scope.id=$stateParams.uId;
            }
        })
        .state('app.appuser', {
            url: '/addUser',
            templateUrl: 'assets/UserManagement/userManagement.html',
            controller : function($rootScope,$scope){
               $scope.id=null;
               $rootScope.userUpload = false;
               $rootScope.userEduDetail = false;
               $rootScope.userExpDetail = false;
           }
       })
        .state('app.viewUser', {
            url: '/viewUser',
            templateUrl: 'assets/UserManagement/app_viewUsers.html'
        })
        .state('app.viewClient', {
            url: '/viewClient',
            templateUrl: 'assets/Client/add_client.html',

            controller : function($rootScope,$scope,$http){

                $http.get('/allClient?cName=client').success(function(data){
                    $scope.clientDetails = data;
                    

                })
                
            }
        })
        .state('app.profile', {
            url: '/myProfile/:uId',
            templateUrl:  'assets/UserManagement/userManagement.html',
            controller : function($rootScope,$scope,$http){
                $scope.profileId=2;

            }
        })
        .state('app.form', {
            url: '/form',
            template: '<div ui-view class=""></div>'
        })
        .state('app.form.elements', {
            url: '/elements',
            templateUrl: 'assets/form-elements.html',
            resolve: {
                deps: ['uiLoad',
                function(uiLoad) {
                    return uiLoad.load(['assets/bower_components/font-awesome/css/font-awesome.css']);
                }
                ]
            }
        })
        .state('app.form.premade', {
            url: '/premade',
            templateUrl: 'assets/form-premade.html',
            resolve: {
                deps: ['uiLoad',
                function(uiLoad) {
                    return uiLoad.load(['assets/bower_components/font-awesome/css/font-awesome.css']);
                }
                ]
            }
        })
        .state('app.form.components', {
            url: '/components',
            templateUrl: 'assets/form-components.html',
            resolve: {
                deps: ['$ocLazyLoad',
                function($ocLazyLoad) {
                    return $ocLazyLoad.load('colorpicker.module').then(
                        function() {
                            return $ocLazyLoad.load('assets/controllers/colorpicker.js');
                        }
                        ).then(
                        function() {
                            return $ocLazyLoad.load('assets/bower_components/font-awesome/css/font-awesome.css');
                        }
                        );
                    }
                    ]
                }
            })
                   
                    .state('app.form.validation', {
                        url: '/validation',
                        templateUrl: 'assets/form-validation.html',
                        resolve: {
                            deps: ['uiLoad',
                            function(uiLoad) {
                                return uiLoad.load('assets/controllers/form-validation.js');
                            }
                            ]
                        }
                    })
                   
                    .state('app.form.masks', {
                        url: '/masks',
                        templateUrl: 'assets/form-masks.html'
                    })
                  /*  .state('app.ui.calendar', {
                        url: '/calendar',
                        templateUrl: 'assets/partials/ui-calendar.html',
                        resolve: {
                            deps: ['$ocLazyLoad', 'uiLoad',
                                function($ocLazyLoad, uiLoad) {
                                    return uiLoad.load(
                                        JQ_CONFIG.fullcalendar.concat('assets/js/controllers/calendar.js')
                                    ).then(
                                        function() {
                                            return $ocLazyLoad.load('ui.calendar');
                                        }
                                    )
                                }
                            ]
                        }
                    })
                    */

                }
                ]
                );




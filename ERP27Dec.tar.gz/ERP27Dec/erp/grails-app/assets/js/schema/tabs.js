angular.module('app').controller('employeeincludeController', ['$scope',
  function($scope) {
     $scope.employeePageUrl="assets/Employee/generalinfo.html";
          
      $scope.generalinfo=function(){
         
          $scope.employeePageUrl="assets/Employee/generalinfo.html";
          
      }
      $scope.contactinfo=function(){
         
          $scope.employeePageUrl="assets/Employee/contactinfo.html";
          
      }
       $scope.bankdetails=function(){
         
          $scope.employeePageUrl="assets/Employee/bankinfo.html";
          
      }
        $scope.payrolldetails=function(){
         
          $scope.employeePageUrl="assets/Employee/payrolldetails.html";
          
      }
         $scope.skilldetails=function(){
         
          $scope.employeePageUrl="assets/Employee/skilldetails.html";
          
      }
          $scope.uploadphoto=function(){
         
          $scope.employeePageUrl="assets/Employee/empphoto.html";
          
      }
           $scope.jobdetails=function(){
         
          $scope.employeePageUrl="assets/Employee/jobstatus.html";
          
      }
            $scope.experience=function(){
         
          $scope.employeePageUrl="assets/Employee/experience.html";
          
      }
             $scope.education=function(){
         
          $scope.employeePageUrl="assets/Employee/educationMain.html";
          
      }
             $scope.address=function(){
         
          $scope.employeePageUrl="assets/Employee/employeeaddress.html";
          
      }
              $scope.familydetails=function(){
         
          $scope.employeePageUrl="assets/Employee/FamilyGrid.html";
          
      }
               $scope.vehicledetails=function(){
         
          $scope.employeePageUrl="assets/Employee/vehicle.html";
          
      }
                  $scope.insurancedetails=function(){
         
          $scope.employeePageUrl="assets/Employee/emp_lic_info.html";
          
      }
               
      
  }
  ]);


angular.module('app').controller('erpEmployees', 
['$scope','$http','$rootScope',
  function($scope,$http,$rootScope) {
    //  $http.get('assets/erp-employees.json').success(function(data) {

  var mdata = {cName:'employee'}
  
$http.post('/findAllData',mdata).success(
function(data) {
  
    $scope.employees = data;
    alert("...clientId.."+$scope.employees.clientId)

    });


  $scope.editEmpInfo= function(form){
     alert(form._id);
    $rootScope.modelEmpInfo=form
  
  }


    }
    ]);

angular.module('app').controller('VarticalTabsController', ['$scope',
    function($scope) {
        $scope.tabs = [{
title: 'General Information',
disabled:false,
url: 'partials/generalinfo.html'
},


{
title: 'Contact Information',
disabled:false,
url: 'partials/contactinfo.html'
},
  
                       {
title: 'Bank Details',
disabled:false,
url: 'partials/bankinfo.html'
},
                                              {
title: 'Payroll Details',
disabled:false,
url: 'partials/payrolldetails.html'
},
                       {
title: 'Skill Details',
disabled:false,
url: 'partials/skilldetails.html'
},
                       {
title: 'Upload Photo',
disabled:false,
url: 'partials/empphoto.html'
}
                      ];

$scope.currentTab = 'partials/generalinfo.html';

$scope.onClickTab = function (tab) {

$scope.currentTab = tab.url;
}

$scope.isActiveTab = function(tabUrl) {

if($rootScope.model.agencyid == null)
{
if (tab.disabled == false)
return true;
       }
return tabUrl == $scope.currentTab;
}

$scope.isActiveTab = function(tabUrl) {
return tabUrl == $scope.currentTab;
}

        
        
    }
    ]);
angular.module('app').controller('TabsController', ['$scope',
    function($scope) {
        $scope.tabs = [ {
title: 'Job Details',
disabled:false,
url: 'partials/jobstatus.html'
},
{
title: 'Experience',
disabled:false,
url: 'partials/experience.html'
},
                       {
title: 'Address',
disabled:false,
url: 'partials/employeeaddress.html'
},
                       {
title: 'Education Details',
disabled:true,
url: 'partials/education.html'
},
  
                       {
title: 'Family Details',
disabled:false,
url: 'partials/familydetails.html'
},
                       {
title: 'Vehicle Details',
disabled:false,
url: 'partials/vehicleinfo.html'
},
                       {
title: 'Insurance Details',
disabled:false,
url: 'partials/emp_lic_info.html'
}
                      
                      ];

$scope.currentTab = 'partials/jobstatus.html';

$scope.onClickTab = function (tab) {

$scope.currentTab = tab.url;
}

$scope.isActiveTab = function(tabUrl) {

if($rootScope.model.agencyid == null)
{
if (tab.disabled == false)
return true;
       }
return tabUrl == $scope.currentTab;
}

$scope.isActiveTab = function(tabUrl) {
return tabUrl == $scope.currentTab;
}

        
        
    }
    ]);
angular.module('app').controller('generalinfoController', ['$scope','$http','$rootScope','$location',
    function($scope,$http,$rootScope,$location) {
      

 //alert("rootScope.generalinfoController..."+$rootScope.modelEmpInfo._id)
  
  if($rootScope.modelEmpInfo){
  $scope.modelEmpInfo = $rootScope.modelEmpInfo;
}
else{
  $scope.modelEmpInfo={} 
}

   $scope.schema={
   "type": "object",
   "title": "Comment",
   "properties": {
       "Emp_Code": {
         "type": "integer",
         "title":"Employee Code",
          "required":true,
          "minLength":2,
          "validationMessage":"              "
        },
       "First_Name": {
          "type": "string",
           "title":"First Name",
          "required":true,
          "validationMessage":"              "
        },
       "Middle_Name": {
          "type": "string",
           "title":"Middle Name",
          "validationMessage":"              "
        },
    "Last_Name": {
       "title":"Last Name",
          "type": "string",
          "validationMessage":"              "
        },
     "Short_Name": {
       "title":"Short Name",
          "type": "string",
          "validationMessage":"              "
        },
    "dob": {
           "type": "date",
           "required":true,
          "validationMessage":"              "
        },
    "Father_Name": {
      "title":"Father Name",
          "type": "string",
          "validationMessage":"              "
        },
    "Spouse_Name": {
      "title":"Spouse Name",
          "type": "string",
          "validationMessage":"              "
        },
    "Mobile":{
        "title":"Mobile",
          "type": "number",
          "pattern":"[789][0-9]{9}",
          "maxLength":10,
          "minLength":10,
          "validationMessage":"              "
        },
       
    
         "Gender" :{
            "title" : "Gender",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Place_Of_Birth": {
         "title":"Place Of Birth",
          "type": "string",
          "validationMessage":"              "
        },
        "Religion" :{
            "title" : "religion",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Marital_status" :{
            "title" : "Marital status",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Nationality" :{
            "title" : "Nationality",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
//     "caste" :{
//            "title" : "caste",
//            "type" : "array",
//            "items": {"type":"string"},
//            "maxItems": 1,
//         },
        "caste" :{
                "title":"caste",
                "type" :"array",
                "items":{"type":"string"}
               
                         },
        "Language_Known" :{
                "title":"Language Known",
                "type" :"array",
                "items":{"type":"string"}
               
                         },
       "Mother_Tongue" :{
            "title" : "Mother Tongue",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
      
       "Identification_Mark": {
        "title":"Identification Mark",
          "type": "string",
          "validationMessage":"              "
        },
        "Blood_Group":{
            "title" : "Blood Group",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
    
       "Weight": {
          "type": "number",
          "validationMessage":"              "
        },
       
       "Height": {
          "type": "number",
          "validationMessage":"              "
        },
       
       "Remarks": {
          "type": "string",
          "validationMessage":"              "
        },

}
   };

$scope.form = [
{
     "key": "Emp_Code",
     "feedback":false,
     "htmlClass":" form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
{
     "key": "First_Name",
     "feedback":false,
     "htmlClass":" form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Middle_Name",
     "feedback":false,
     "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Last_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Short_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "dob",
     "title":"Date of birth",
     "feedback":false,
    "labelHtmlClass":"form-label",
    "htmlClass":"form-group controls ",
     "type": "date"
     
   },
    {
     "key": "Father_Name",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
  {
     "key": "Spouse_Name",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Mobile",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
        "key" : "Gender",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/gender.json"
                        }
                    }

        },
     {
     "key": "Place_Of_Birth",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     
    {
        "key" : "Religion",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/religion.json"
                        }
                    }

        },
     {
        "key" : "Marital_status",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/maritalStatus.json"
                        }
                    }

        },
     {
        "key" : "Nationality",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/nationality.json"
                        }
                    }

        },

    {
    "key" : "caste",
    "type": "strapselect",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                "placeholder": "None selected",
                "options": {
                     "multiple" : "true",
                    "httpGet": {
                        
                        "url": "assets/caste.json"
                    },

                }

    },
   
    {
    "key" : "Language_Known",
    "type": "strapselect",
    "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                "placeholder": "None selected",
                "options": {
                    "multiple" : "true",
                    "httpGet": {
                         
                        "url": "assets/language.json"
                    },

                }

    },
     {
        "key" : "Mother_Tongue",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/mothertongue.json"
                        }
                    }

        },
    {
     "key": "Identification_Mark",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     {
        "key" : "Blood_Group",
        "type": "strapselect",
         "feedback":false,
        "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/bloodgroup.json"
                        }
                    }

        },
    {
     "key": "Weight",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Height",
     "feedback":false,
    "htmlClass":"form-group controls ",
    "labelHtmlClass":"form-label",
     "type": "number"
     
   },
    {
     "key": "Remarks",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   }
     
    
   
 ];




  

  $scope.submitEmpInfo = function(form) {
    // First we broadcast an event so all fields 
    //validate themselves
alert("submitEmp")
   // $scope.$broadcast('schemaFormValidate');
 var mdata = {model: $scope.modelEmpInfo, cName:'employee', childColName:'', id:0}

    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/saveData',mdata)
         .success(function(data){
          // $scope.urls='';
           $location.path('assets/Employee/employeeinfo.html');
          
         
        });

    }
  }
        
    }
    ]);
angular.module('app').controller('educationtableController', ['$scope',
    function($scope) {
        
         $scope.schema = {
        "type": "object",
        "title": "Comment",
        "properties": {

            "CourseCode": {
                "title": "Course Code",
                "type": "string",
                "validationMessage": "              "
            },
         "Course": {
                "title": "Course",
                "type": "string",
                "validationMessage": "              "
            },
            "Duration": {
                "title": "Duration",
                "type": "string",
                "validationMessage": "              "
            },
            "StartYear": {
                "title": "Start Year",
                "type": "string",
                "validationMessage": "              "
            },
            "EndYear": {
                "title": "End Year",
                "type": "string",
                "validationMessage": "              "
            },
            "Class": {
                "title": "Class",
                "type": "string",
                "validationMessage": "              "
            },
            "Percentage": {
                "title": "Percentage (%)",
                "type": "string",
                "validationMessage": "              "
            },
            "SplAchievement": {
                "title": "Spl Achievement",
                "type": "string",
                "validationMessage": "              "
            },
            "UniversityName": {
                "title": "University Name",
                "type": "string",
                "validationMessage": "              "
            },
            "InstitutionName": {
                "title": "Institution Name",
                "type": "string",
                "validationMessage": "              "
            },
            "City": {
                "title": "Duration",
                "type": "string",
                "validationMessage": "              "
            },
            "State": {
                "title": "State",
                "type": "string",
                "validationMessage": "              "
            },
            "Country": {
                "title": "Country",
                "type": "string",
                "validationMessage": "              "
            },
            "PinCode": {
                "title": "Pin Code",
                "type": "string",
                "validationMessage": "              "
            },
            "Comments": {
                "title": "Comments",
                "type": "string",
                "validationMessage": "              "
            }
        }
    }

    $scope.form = [

        {
            "key": "CourseCode",
            "title": "Course Code",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "Course Code",
            "disableSuccessState": true

        },
        {
            "key": "Course",
            "title": "Course",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Course",
            "disableSuccessState": true
        },
        {
            "key": "Duration",
            "title": "Duration",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Duration",
            "disableSuccessState": true
        },
        {
            "key": "StartYear",
            "title": "Start Year",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Start Year",
            "disableSuccessState": true
        }, {
            "key": "EndYear",
            "title": "End Year",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "End Year",
            "disableSuccessState": true
        },
        {
            "key": "Class",
            "title": "Class",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "Class",
            "disableSuccessState": true

        },
        {
            "key": "Percentage",
            "title": "Percentage (%)",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Percentage (%)",
            "disableSuccessState": true
        },
        {
            "key": "SplAchievement",
            "title": "Spl Achievement",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Spl Achievement",
            "disableSuccessState": true
        },
        {
            "key": "UniversityName",
            "title": "University Name",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "University Name",
            "disableSuccessState": true
        }, {
            "key": "InstitutionName",
            "title": "Institution Name",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Institution Name",
            "disableSuccessState": true
        }, {
            "key": "City",
            "title": "City",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "City",
            "disableSuccessState": true
        },
        {
            "key": "State",
            "title": "State",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass":"",
            "placeholder": "State",
            "disableSuccessState": true

        },
        {
            "key": "Country",
            "title": "Country",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Country",
            "disableSuccessState": true
        },
        {
            "key": "PinCode",
            "title": "Pin Code",
            "feedback":false,
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Pin Code",
            "disableSuccessState": true
        },
        {
            "key": "Comments",
            "title": "Comments",
            "feedback":false,
            "type":"textbox",
            "htmlClass":"form-group  controls ",
            "labelHtmlClass":"form-label",
            "fieldHtmlClass": "",
            "placeholder": "Comments",
            "disableSuccessState": true
        }
    ]
    $scope.model={}

    $scope.save=function(){
        /*$scope.EduUrl = "";*/
    };
        
         $scope.addRow = function(){
            
        $scope.EduUrl = "assets/Employee/addeducation.html";
    };
         $scope.cancel=function(){
        $scope.EduUrl = "";
    };

    }
    ]);

angular.module('app').controller('EmployeeAddresstableController', ['$scope','$http',
    function($scope,$http) {
        $scope.schema={
   "type": "object",
   "title": "Comment",
   "properties": {
       
       
         "Address Type" :{
            "title" : "Address Type",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Address 1": {
          "type": "string",
           "required":true,
          "validationMessage":"              "
        },
       "Address 2": {
          "type": "string",
          "validationMessage":"              "
        },
        "City" :{
            "title" : "City",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
        "State" :{
            "title" : "State",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
       "Country" :{
            "title" : "Country",
            "type" : "array",
            "items": {"type":"string"},
            "maxItems": 1,
         },
        "pincode": {
              "title": "pincode",
              "type": "string",

              "pattern":"[0-9]{6}",

              "validationMessage":"              "
            },
}
   };

$scope.form = [

    {
        "key" : "Address Type",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/addresstype.json"
                        }
                    }

        },
     {
     "key": "Address 1",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
    {
     "key": "Address 2",
     "feedback":false,
    "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
     "type": "string"
     
   },
     {
        "key" : "City",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/city.json"
                        }
                    }

        },
 {
        "key" : "State",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/state.json"
                        }
                    }

        },
{
        "key" : "Country",
        "type": "strapselect",
        "feedback":false,
        "htmlClass":"form-group controls",
    "labelHtmlClass":"form-label",
                    "placeholder": "None selected",
                    "options": {
                        "multiple" : "true",
                        "httpGet": {
                            "url": "assets/country.json"
                        }
                    }

        },
        {
              "key": "pincode",
              "type":"string",
              "feedback":false,
               "htmlClass":"form-group controls",
              "labelHtmlClass":"form-label"

        },

    /*{
   "htmlClass":"col-xs-1",
     "type": "submit",
     "style": "btn-info",
     "title": "Save"
   },
       {
   "htmlClass":"col-xs-1",
     "type": "submit",
     "style": "btn-danger",
     "title": "Reset"
   }*/
 ];



    // $scope.form = [
    // {
    //   key: "name",
    //   feedback: "{ 'glyphicon': true, 'glyphicon-asterisk': form.required,'glyphicon-ok': hasSuccess(), 'glyphicon-remove': hasError() }"
    // }
    // ];

  $scope.model = {};
    
    $scope.addnew=function()
    {
       
        $scope.urls="assets/Employee/addemployeeaddress.html";
    }
    $scope.cancel=function()
    {
        
       
        $scope.urls="";
    }

  $scope.onSubmit = function(form) {
 var mdata = {model: $scope.modelEmpInfo, cName:'employee', childColName:'', id:0}

    // Then we check if the form is valid
    if (form.$valid) {
     
     $http.post('/saveData',mdata)
         .success(function(data){
         alert("submitTED")
           $location.path('assets/Employee/employeeinfo.html');
          
         
        });

    }
  }
    }                                                         
    ]);
angular.module('app').controller('experiencetableController', ['$scope','$http',
    function($scope,$http) {
        $scope.schema = {

        "type": "object",
        "title": "Comment",
        "properties": {
            "Company Name":
            {
                "title": "Company Name",
                "type": "string"
            },


            "From Date":
            {
                "title": "From Date",
                "type": "string",
                "format":"date",
               //"required": true,
            },


            "To Date":
            {
                "title": "To Date",
                "type": "string",
                "format": "date",
            },

            "Experience":
            {
                "title": "Experience",
                "type": "number",
            },

            "Designation":
            {
                "title": "Designation",
                "type": "string",
            },

            "Relieving Reason":
            {
                "title": "Relieving Reason",
                "type": "string",
            },

            "Last Salary Drawn":
            {
                "title": "Last Salary Drawn",
                "type": "string",
            },

            "Duties":
            {
                "title": "Duties",
                "type": "string",
            },

            "Achievements":
            {
                "title": "Achievements",
                "type" : "string",
            },

            "Reference Person":
            {
                "title": "Reference Person",
                "type": "string",
            },

            "Address":
            {
                "title": "Address",
                "type": "string",
            },

             "city" :
             {
               "title" : "city",
               "type" : "array",
               "items": {"type":"string"},
                "maxItems": 1,
             },


            "state" :
            {
                "title" : "state",
                "type" : "array",
                "items": {"type":"string"},
                "maxItems": 1,

            },

           "country" :
           {
               "title" : "country",
               "type" : "array",
               "items": {"type":"string"},
               "maxItems": 1,

           },


        }
    }

    $scope.form=[

        {
            "key": "Company Name",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Company Name"
        },

        {
            "key": "From Date",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Pick Your From Date",
            "type": "date",
            /*"format": "yyyy-mm-dd",
            "minDate": "1950-01-01",
            "maxDate": "2030-11-24",*/

        },

        {
            "key": "To Date",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Pick Your To Date",
            "type": "date",
            /*"format": "yyyy-mm-dd",
            "minDate": "1950-01-01",
            "maxDate": "2030-11-24",*/
        },

        {
            "key": "Experience",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "your experience is"

        },

        {
            "key": "Designation",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Designation "
        },


        {
            "key": "Relieving Reason",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Relieving Reason"
        },


        {
            "key": "Last Salary Drawn",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Last Salary Drawn "
        },


        {
            "key": "Duties",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter the Duties you Performed "
        },


        {
            "key": "Achievements",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Achievements "
        },


        {
            "key": "Reference Person",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter Your Reference Person's Name "
        },


        {
            "key": "Address",
            "feedback":false,
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "placeholder": "Enter your Address"
        },


        {
             "key" : "city",
             "type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/city.json"}
             }
        },


        {
             "key" : "state",
             "type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/state.json"}
             }
        },


        {
            "key" : "country",
            "type": "strapselect",
            "placeholder": "None selected",
            "htmlClass":"form-group  controls",
            "labelHtmlClass":"form-label",
            "options":
            {
             "multiple" : "true",
             "httpGet": {"url": "assets/country.json"}
            }
        }
    ]

    $scope.model={}

   $scope.save=function(){
        $scope.ExpUrl = "";
    };

    $scope.addRow = function(){
        $scope.ExpUrl = "assets/Employee/addexperience.html";
    };



    $scope.cancel=function(){
        $scope.ExpUrl = "";
    };


    $scope.onSubmit = function(form) {
        $scope.$broadcast('schemaFormValidate');
        if (form.$valid) {
        }}
    }
    ]);
angular.module('app').controller('jobstatustableController', ['$scope',
    function($scope) {






        $scope.schema={
 "type": "object",
        "title": "Comment",
        "properties": {

"Category":{
  "title":"Category",
   "type" : "array",
               "items": {"type":"string"},
               "maxItems": 1
  },
  "Department":{
   "title":"Department",
   "type":"string",
   "required":true,
   "validationMessage":" "
  },
  "Designation":{
  "title":"Designation",
  "type":"string",
  "required":true,
  "validationMessage":" "
    },
   "ReportingManager":{
  "title":"ReportingManager",
   "type":"string",
   "required":true,
   "validationMessage":" "
   },
   "FromDate":{
   "title":"From Date",
   "type":"string",
   "format":"date"
   },
   "ToDate":{
   "title":"To Date",
   "type":"string",
   "format":"date"
   },
   "RelievingReson":{
     "title":"RelievingReson",
      "type":"string",
      "required":true,
      "validationMessage":" "
      },
      "RefferedpersonName":{
      "title":"Reffered person Name",
      "type":"string",
      "required":true,
        "validationMessage":" "
      },
      "Remarks":{
      "title":"Remarks",
      "type":"string",
       "required":true,
         "validationMessage":" "
      }
}

}
$scope.form=[

{
"key":"Category",
"type": "strapselect",
             "placeholder": "None selected",
             "htmlClass":"form-group  controls",
             "labelHtmlClass":"form-label",
             "options":
             {
             "multiple" : "true",
             "httpGet": {"url": "assets/Category.json"}
             }
},
{
"key":"Department",
"placeholder":"Enter Department",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"Designation",
"placeholder":"Enter Designation",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"ReportingManager",
"placeholder":"Enter ReportingManager",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"FromDate",
    "type":"date",
"placeholder":"DD/MM/YYYY",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"ToDate",
    "type":"date",
"placeholder":"DD/MM/YYYY",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"RelievingReson",
"placeholder":"Enter Relieving Reson",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"RefferedpersonName",
"placeholder":"Enter Reffered PersonName",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
},
{
"key":"Remarks",
"type":"textarea",
"htmlClass":"form-group  controls ",
"labelHtmlClass":"form-label"
}

]
$scope.model={}
$scope.add=function()
{
    $scope.jobUrl="assets/Employee/jobdetails.html";
};
        $scope.cancel=function()
{

    $scope.jobUrl="";
};


$scope.saveCollection=function() {
alert('haiii')

    if($scope.id==null){
        $scope.id = 0;
    }
    var mdata = {model:$scope.model, cName:'jobdetails',id:$scope.id}
    $http.post('/saveJobDetailsData',mdata)
    .success(function(data){
        $scope.jobDetailsModel=data;
        $scope.jobUrl = '';
        $scope.id=null;
        $scope.message = "Job is added Successfully"  
        $scope.showMessage("SUCCESS",  $scope.message);    
     }) 
    .error(function(data){ console.log(data)
              $scope.message = "Error Occured please check the entry "
              $scope.showMessage("ERROR", $scope.message)
                  });
};


    }
    ]);

angular.module('app').controller('familydetailstableController', ['$scope','$http',
    function($scope,$http) {
          $scope.schema = {
  "type": "object",
  "title": "Comment",
  "properties": {

"First Name":{
"title" : "First Name",
"type" : "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},


"Middle Name": {
"title": "Middle Name",
"type": "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},
"Last Name":{
"title" : "Last Name",
"type" : "string",
"required":true,
"minLength": 4,
"maxLength": 20,
},

"Relation":  {
"title": "Relation",
"required":true,
"type": "string",
"format" : "uiselect",
"items": {"type": "string"}
},
"Gender":  {
"title": "Gender",
"required":true,
"type": "string",
"format" : "uiselect",
"items": {"type": "string"}
},
"DOB":{
"title" : "DOB",
"type" : "string",
"required":true,

},


"Is Dependent": {
"title": "Is Dependent?",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},



"PF Nominee": {
"title": "PF Nominee",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},

"Is Employee": {
"title": "Is Employee?",
"type": "array",
"items": {
"type": "string",
"enum": [
"a"

]
}
},


"Occupation": {
"title": "Occupation",
"type": "string",
"required":true,
"minLength": 10,
"validationMessage":"              "

},
"Remarks": {
"title": "Remarks",
"type": "string",
"required":true,
"minLength": 10,
"validationMessage":"              "

},




}





};



 $scope.form1 = [
{
"key": "First Name",
"type":"string",
"feedback":false,
"placeholder": "Enter First here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "Middle Name",
"type":"string",
"feedback":false,
"placeholder": "Enter Middle here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},


{
"key": "Last Name",
"type":"string",
"feedback":false,
"placeholder": "Enter Last here",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key" : "Relation",
"type": "strapselect",
"placeholder": "None selected",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",
"options":
{

"httpGet": {"url": "assets/relation.json"}
}
},
{
"key" : "Gender",
"type": "strapselect",
"placeholder": "None selected",
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",
"options":
{

"httpGet": {"url": "assets/gender.json"}
}
},
{
"key": "DOB",
"type":"Date",
"placeholder": "Enter DOB here",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "Is Dependant",
"title": "Is Dependent?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",
"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "Is Employee",
"title": "Is Employee?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",

"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "PF Nominee",
"title": "PF Nominee?",
"htmlClass":"form-group  controls form-inline",
"labelHtmlClass":"form-label col-md-3",
"type": "checkboxes",
"titleMap": [
{
"value": "YES",
"name": ""
}

]
},
{
"key": "Occupation",
"type":"string",
"placeholder": "Enter Occupation here",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},
{
"key": "Remarks",
"type":"string",
"placeholder": "Enter Remarks here",
"feedback":false,
"htmlClass":"form-group  controls",
"labelHtmlClass":"form-label",



},



];



  $scope.model = {};

  $scope.save = function(form) {
    // First we broadcast an event so all fields validate themselves
    $scope.$broadcast('schemaFormValidate');

    // Then we check if the form is valid
    if (form.$valid) {
      // ... do whatever you need to do with your data.
    }
  }
  $scope.add=function()
  {
    $scope.url1="assets/Employee/addfamilydetails.html";


  }
  $scope.cancel=function()
  {
  $scope.url1="";
  }

    }
    ]);

angular.module('app').controller('vehicleController', ['$scope','$http',
    function($scope,$http) {
          $scope.schema = {
            "type": "object",
            "title": "Comment",
            "properties": {
            "VehicleType": {
                                "title": "Vehicle Type",
                                "type": "string",
                                "required":true,
                                 "enum": [
                                              "Two Wheeler",
                                              "Three Wheeler",
                                              "Four Wheeler",
                                              "Six Wheeler"
                                           ]
             },

             "VehicleColorType":{
                                 "title":"Vehicle Color Type",
                                 "type":"string",
                                 "required":true,
                                 "enum": [
                                              "RED",
                                              "BLUE",
                                              "GREEN",
                                              "BLACK"
                                           ]
              },

              "VehicleMake": {

                                 "title": "Vehicle Make",
                                 "type": "string",
                                   //  "required": true,
                                 "validationMessage": "              "
               },

               "vehicleReg No":{

                                 "title":"vehicle Reg No",
                                 //  "pattern":"[789][0-9]{9}",
                                 "type":"integer",
                                 "validationMessage":"          ",
                                 "maxLength":10
                                   //"minLength":10,
                },

                "vehicleModel": {

                                 "title": "vehicle Model",
                                 "type": "string",
                                      //"pattern": "[0-9A-Za-z]{1,64}[\@][0-9a-zA-Z\-]{1,63}[\.][a-zA-Z\-]{2,24}",
                                      //"required":true,
                                     // "maxLength": 20
                                 "validationMessage":"     "
                 },


                "VehicleRegistration":{
                                            "title":"Vehicle Registration",
                                            "type":"integer",
                                            //"required":true,
                                            "validationMessage":"              "
                                        //    "minLength":4,
                                          //   "min":1
                  },

                  "VehicleOwner":{
                                              "title":"Vehicle Owner",
                                              "type":"string",
                                                              //"required":true,
                                              "validationMessage":"              "
                                             // "minLength":4,
                                             // "min":1
                    },

                    "VehicleDescription":{
                                         "title":"Vehicle Description",
                                         "type":"string",
                                         //"required":true,
                                         "validationMessage":"              "
                                        // "minLength":4,
                                        // "min":1
                     },

                     "ParkingSticker Issue Date ":{
                                           "title":" Parking Sticker Issue Date ",
                                           "type":"date",
                                       //"required":true,
                                           "validationMessage":"              "
                                          // "minLength":4,
                                           //"min":1
                      },

                      "ParkingSticker Expiry Date":{
                                            "title":"Parking Sticker Expiry Date",
                                            "type":"date",
                                            //"required":true,
                                            "validationMessage":"              "
                                           // "minLength":4,
                                           // "min":1
                       },

                       "Parking Slot":{
                                            "title":"Parking Slot",
                                            "type":"date",
                                             //"required":true,
                                            "validationMessage":"              "
                                            //"minLength":4,
                                            //"min":1
                       }
             }
        }

        $scope.form=[
            {
                            "key": "VehicleType",
                            "feedback": false,
                            "htmlClass":"form-group control",
                            "labelHtmlClass":"form-label",
                            "placeholder": "SELECT TYPE"
            },

            {
                            "key": "VehicleColorType",
                            //"type":"string",
                            "feedback":false,
                            "htmlClass":"form-group control",
                            "labelHtmlClass":"form-label",
                            "placeholder": "SELECT VEHICLE COLOR"

            },

            {
                             "key": "VehicleMake",
                             "feedback":false,
                             "htmlClass":"form-group control",
                             "labelHtmlClass":"form-label",
                             "placeholder": " Makers Name "


            },

            {
                             "title":"vehicle Reg No",
                             "key": "vehicleRegNo",
                             "type":"string",
                             "feedback":false,
                             "htmlClass":"form-group control",
                             "labelHtmlClass":"form-label",
                             "placeholder": "ENTER REG NO"

            },

            {
                              "title":"vehicle Model",
                              "key": "comments",
                              "type": "string",
                              "placeholder": "ENTER VEHILCE MODEL",
                              "htmlClass":"form-group control",
                              "labelHtmlClass":"form-label",
            },


            {
                              "title":"Vehicle Registration",
                               "key": "VehicleRegistration",
                               "type":"number",
                               "feedback":false,
                               "placeholder":"ENTER VEHICLE REGISTRATION ",
                               "htmlClass":"form-group control",
                               "labelHtmlClass":"form-label"
            },

            {
                                "title":"Vehicle Owner",
                                "key": "VehicleOwner",
                                "type":"string",
                                "feedback":false,
                                "placeholder":"ENTER VEHICLE OWNER",
                                "htmlClass":"form-group control",
                                "labelHtmlClass":"form-label"
             },

             {
                                  "title":"Vehicle Description",
                                  "key": "VehicleDescription",
                                  "type":"string",
                                  "feedback":false,
                                  "placeholder":"DESCRIPTION",
                                  "htmlClass":"form-group control",
                                  "labelHtmlClass":"form-label"
              },

             {
                                   "title":"Parking Sticker Issue Date",
                                   "key": "ParkingStickerIssueDate",
                                   "type":"date",
                                   "feedback":false,
                                   "placeholder":"dd/mm/yyyy",
                                   "htmlClass":"form-group control",
                                   "labelHtmlClass":"form-label"
              },

              {
                                    "title":"Parking Sticker Expiry Date",
                                    "key": "ParkingStickerExpiryDate",
                                    "type":"date",
                                    "feedback":false,
                                    "placeholder":"dd/mm/yyyy",
                                    "htmlClass":"form-group control",
                                    "labelHtmlClass":"form-label"
              },

              {
                                     "title":"Parking Slot",
                                     "key": "Parkingslot",
                                      "type":"string",
                                      "feedback":false,
                                      "placeholder":"ENTER PARKING SLOT LOCATION",
                                      "htmlClass":"form-group control",
                                      "labelHtmlClass":"form-label"
               }

        ]

        $scope.model={}

        $scope.onSubmit = function(form) {
            $scope.$broadcast('schemaFormValidate');
            if (form.$valid) {
             $scope.erp = "";
            }
            }

        $scope.addRow = function(){
          $scope.erp="assets/Employee/addvehicle.html"}



            $scope.cancel=function(){
                $scope.erp = "";
            }
    }
    ]);


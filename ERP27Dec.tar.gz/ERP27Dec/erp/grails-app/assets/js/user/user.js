angular.module('app').controller('userController', ['$scope','$http','$rootScope','$location','schemaForm','$stateParams',
  function($scope,$http,$rootScope,$location,$stateParams) {



   $scope.userpersonalDetailsmodel = {}; 
   $rootScope.id=$scope.id;
   $scope.box_class="box"
   $scope.init=function(){
    if($scope.id!=null){

      var mdata = {cName:'person',childColName:'', edit_id:$scope.id}
      $http.post('/editUsers',mdata).success(function(data){
$scope.dob = new Date(data.dob);

       $scope.userpersonalDetailsmodel = {"userType":data.userType,"userGrading":data.userGrading,"summary":data.summary,"userName":data.userName,"firstName":data.firstName,"lastName":data.lastName,"phoneNumber":data.phoneNumber,"gender":data.gender,
       "dob":$scope.dob,"email":data.email,"designation":data.designation,"department":data.department,"password":data.password};
       
                        
                        $rootScope.userUpload = true;
                        $rootScope.userEduDetail = true;
                        $rootScope.userExpDetail = true;
                        
                        
                      }); 

    }else if($scope.profileId==2){
      alert("Hello Happy coming")
      $http.get('/profileEdit').success(function(data){
         
          $scope.userpersonalDetailsmodel =data;

                        $scope.profileId=null;
                        $rootScope.userUpload = true;
                        $rootScope.userEduDetail = true;
                        $rootScope.userExpDetail = true;
         })
    }
  } 

  $scope.init(); 

  $scope.schema1 = {

   "type": "object",
   "title": "Comment",

   "properties": {

    "userType":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },
    "firstName": {
      "placeholder": "Enter user Name",
      "type": "string",
      "required":true,
      

    },
    "lastName": {
      "placeholder": "Enter user Name",
      "type": "string",
      "required":true,
      

    },
    "userName": {
      "placeholder": "Enter user Name",
      "type": "string",
      "required":true,
      

    },
    
    "password": {
      "placeholder": "Enter user Name",
      "type": "string",
      "required":true,
      

    },

    /*"department":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },
    "designation":
    {

      "type": "string",
      "format" : "uiselect",

      "items": {"type": "string"}
    },*/
    "dob": {

      "type": "date",
      "required":true,
    },
    

    "gender":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },

    "phoneNumber":{

     "pattern":"[789][0-9]{9}",
     "type":"string",
     "required":true,
     "maxLength":10,
     "minLength":10,
     "validationMessage":""

   },

   "summary":{

    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""


  },

  "email": {
    "type": "string",
    "pattern":  "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",
    "required":true,
    "pattern": "^\\S+@\\S+$",
    "validationMessage":""

  },

  "userGrading":
  {

    "type": "string",
    "format" : "uiselect",

    "items": {"type": "string"}
  }
}

};


$scope.form = [

{
  "key" : "userType",
  "title" : "User Type",
  "placeholder": "Select User Type",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options": {
    
    "httpGet": {
      
      "url": "/lookUpData?cName=roleMapping"
    },
    "map" : {valueProperty: "systemRole", nameProperty: "userDefinedRole"}
  }
  

},
{
  "key": "firstName",
  "title" : "First Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "placeholder": "Enter first Name"

},
{
  "key": "lastName",
  "title" : "Last Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "placeholder": "Enter last Name"

},
{
  "key": "userName",
  "title" : "User Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "placeholder": "Enter user Name"

},
{
 "key": "password",
 "title": "Password",
 "type": "string",
 "labelHtmlClass":"form-label",
 "placeholder": ""

},


/*{
  "key" : "department",
  "title" : "Department",
  "placeholder": "Select Department",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}
  
  

},
{
  "key" : "designation",
  "title" : "Designation",
  "placeholder": "Select Designation",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

},*/

{
  "key": "dob",
  "title": "Dob",
  "placeholder": "Select DOB",
  "type":"date",
  "feedback": false,
  "labelHtmlClass":"form-label"

},

{
  "key" : "gender",
  "title" : "Gender",
  "placeholder": "Selecte Gender",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "assets/gender.json"}}
  

},
{
  "key": "phoneNumber",
  "title": "Phone Number",
  "feedback":false,
  "placeholder": "Enter phoneNumber",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "summary",
  "title": "Summary",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "email",
  "title": "Email",
  "type":"email",
  "placeholder": "Enter email-id",
  "labelHtmlClass":"form-label",
  "feedback": false

},
{
  "key" : "userGrading",
  "title" : "User Grading",
  "placeholder": "Select userGrading",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=GRADING&cName=lookUp"}}

}
/*,

{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Reset"
}*/




];

$scope.userPersonalDetail = true;
$scope.userpersonalDetailsmodel={};


$scope.saveCollection = function(form) {
  
  if($scope.id ==null  ){
    
    $scope.id = 0;
  }


  var mdata = {model:$scope.userpersonalDetailsmodel, cName:'person',childColName:'', id:$scope.id}
  $scope.$broadcast('schemaFormValidate');
  
  if (form.$valid) {

    $http.post('/insertUser',mdata)
    .success(function(data){
      $scope.id=data;
      $rootScope.id=$scope.id;
      $rootScope.showAccordian();
      $scope.box_class="box collapsed"
      
    }) 
  }

}
$scope.cancel = function() {

  $scope.userpersonalDetailsmodel = {};
}

}]);

/*
Created By:
Purpose:user2Controller For Creating New users Education Details 
*/

angular.module('app').controller('user2Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {

    $scope.id=$rootScope.id;
    

    $scope.init=function(){
     
      if($scope.id!=null){
        
        var mdata = {cName:'person',childColName:'', edit_id:$scope.id}
        $http.post('/editUsers',mdata).success(function(data){
          
         $scope.educationDetails=data.education;
         
         
       });

      }
    }
    $scope.init(); 


    $rootScope.showAccordian = function(){
      if($rootScope.id != null){

        $rootScope.userEduDetail = true;
      }
      else{
        $rootScope.userEduDetail = false;

      }

    }

    $scope.educationDetailsmodel = {};
    $scope.account= [];
    $scope.educationUrl = '';

    $scope.addEducation = function(){
     
      $scope.educationDetailsmodel = {};
      $scope.educationUrl = "assets/UserManagement/userEducation.html";
    };



    $scope.educationDetailsSubmit = function(form) {
     
     if($scope.Ed_id ==null) {

      $scope.id=$rootScope.id;
      if( $scope.id !=null){

        var mdata = {model: $scope.educationDetailsmodel, cName:'person', childColName:'education', id:$scope.id}

        $scope.$broadcast('schemaFormValidate');
        if (form.$valid) {
         $http.post('/insertUser',mdata)
         .success(function(data){

          $scope.educationDetails=data;
          $scope.educationUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();


        });

         
       }

     }

   }
   else{

    $scope.id=$rootScope.id;
    if( $scope.id != null){
      var mdata = {model:$scope.educationDetailsmodel, cName:'person', childColName:'education', id:$scope.id,Ed_id:$scope.Ed_id}
      $scope.$broadcast('schemaFormValidate');
      if (form.$valid) {
        $http.post('/updateUsersChildCollection',mdata)
        .success(function(data){
          $scope.educationDetails=data;
          $scope.educationUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();
          $scope.Ed_id=null;

        });

        
      }

    }

  }
};



$scope.editEducation=function(edit_id){

  $scope.educationUrl = "assets/UserManagement/userEducation.html";
  var mdata = {cName:'person',childColName:'education',Id:$rootScope.id,editEdu_id:edit_id}
  $http.post('/editUsersChildCollection',mdata).success(function(data){

    $scope.educationDetailsmodel=data[0];
    $scope.Ed_id=$scope.educationDetailsmodel.Ed_id;
    
  })

}
$scope.deleteConfirm=function(Ed_id){
  $scope.Ed_id=Ed_id;
  var new_dialog1 = ngDialog.open({
    id: 'fromAService4',
    template: "assets/UserManagement/ui-model-userDelete.html",
    className: 'ngdialog-theme-default role-width',
    scope:$scope,
    closeByDocument: false,

  });
}

$scope.deleteUser=function(Ed_id){
  var mdata = {cName:'person',childColName:'education',Id:$rootScope.id,editEdu_id:Ed_id}
  $http.post('/deleteUsers',mdata).success(function(data){

   $scope.educationDetails=data;
   $scope.Ed_id=null;
   $scope.closeDialog();
   
 });

}

$rootScope.closeDialog=function(){
  ngDialog.close('fromAService1');
}
$scope.cancel = function() {


  $scope.educationUrl = '';
}

$scope.schema2={

 "type": "object",
 "title": "Comment",

 "properties": {

   "qualification":
   {
    "title": "Qualification",
    "type": "string",
    "format" : "uiselect",
    "items": {"type": "string"}
  },
  
  "university": {
    "title": "University",
    "type": "string",
    "required":true,
  },
  "location": {
    "title": "Location",
    "type": "string",
    "required":true,
  },
  "comments": {
    "title":"Comments",
    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""
  },

}

};

$scope.form1=[

{
  "key" : "qualification",
  "title" : "Qualifaction",
  "placeholder": "none selected",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=EDUCATION&cName=lookUp"}}
},

{
  "key": "university",
  "title": "University",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "location",
  "title": "Location",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "comments",
  "title": "Comments",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

}/*,
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Cancel"
}*/

];



}
]);


/*
Created By:
Purpose:user3Controller For Creating New users Experince Details 
*/

angular.module('app').controller('user3Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {


    $scope.id=$rootScope.id;

    $scope.init=function(){
      if($scope.id!=null){
        var mdata = {cName:'person',childColName:'', edit_id:$scope.id}
        $http.post('/editUsers',mdata).success(function(data){
          
         $scope.experienceDetails=data.experience;
         
         
       });

      }
    }

    $scope.init(); 


    $scope.experiencemodel = {};

    $rootScope.showExpAccordian = function(){
      if($rootScope.id != null){
        $rootScope.userExpDetail = true;
      }
      else{
        $rootScope.userExpDetail = false;
      }

    }

    $scope.experienceUrl = '';
    var userExpSet = [];

    $scope.includeExperience = function(){
      $scope.experiencemodel = {};
      $scope.experienceUrl = "assets/UserManagement/userExperience.html";
    }

    $scope.editExperience=function(edit_id){

      $scope.experienceUrl = "assets/UserManagement/userExperience.html";
      var mdata = {cName:'person',childColName:'experience',Id:$rootScope.id,editEdu_id:edit_id}
      $http.post('/editUsersChildCollection',mdata).success(function(data){

        $scope.experiencemodel =data[0];
        $scope.Ed_id=$scope.experiencemodel.Ed_id;
        
      })

    }

    $scope.deleteConfirm=function(Ed_id){
      $scope.Ed_id=Ed_id;
      var new_dialog1 = ngDialog.open({
        id: 'fromAService4',
        template: "assets/UserManagement/ui-model-userDelete.html",
        className: 'ngdialog-theme-default role-width',
        scope:$scope,
        closeByDocument: false,

      });
    }

    $scope.deleteUser=function(Ed_id){
     
      
      var mdata = {cName:'person',childColName:'experience',Id:$rootScope.id,editEdu_id:Ed_id}
      $http.post('/deleteUsers',mdata).success(function(data){

       $scope.experienceDetails=data;
       $scope.closeDialog();
       $scope.Ed_id = null;
     });

    }
    
    $scope.closeDialog=function(){
      ngDialog.close('fromAService1');
    }
$scope.cancel = function() {

  $scope.experienceUrl = '';
}

    $scope.schema3={

      "type": "object",
      "title": "Comment",
      "properties": {

        "hospitalName": {
          "title": "Company Name",
          "type": "string",
          "required":true,
        },


        /*"department":
        {
          "title": "Department",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },

        "designation":
        {
          "title": "Designation",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },*/

        "noOfYears":
        {
          "title": "No Of Years",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"},
          "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}
        },

        "summary":{

          "type":"string",
          "required":true,
          "minLength":5,
          "validationMessage":""


        },



      }

    };


    $scope.form2=[
    {
      "key": "companyName",
      "title": "Company Name",
      "type":"string",
      "labelHtmlClass":"form-label",
      "feedback": false

    },
    /*{
      "key" : "department",
      "title" : "Department",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}

    },
    {
      "key" : "designation",
      "title" : "Designation",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

    },*/
    {
      "key" : "noOfYears",
      "title" : "No Of Years",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}

    },
    {
   "key": "summary",
   "title": "Summary",
   "type": "textarea",
   "labelHtmlClass":"form-label",
   "placeholder": ""

   }/*,
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-info",
      "title": "Save"
    },
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-warning",
      "title": "Reset"
    }*/



    ];

    

    

    $scope.experienceSubmit = function(form) {

      if($scope.Ed_id==null){
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model: $scope.experiencemodel, cName:'person', childColName:'experience', id:$scope.id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/insertUser',mdata)
            .success(function(data){
              
              $scope.experienceDetails=data;
              $scope.experienceUrl = '';
              $scope.experiencemodel = {};
              
            })

            
          }

        }
      }
      else{
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model:$scope.experiencemodel, cName:'person', childColName:'experience', id:$scope.id,Ed_id:$scope.Ed_id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/updateUsersChildCollection',mdata)
            .success(function(data){
              $scope.experienceDetails=data;
              $scope.experienceUrl = '';
              $scope.experiencemodel = {};
              $scope.Ed_id=null;

            });

            
          }

        }

      }
      
    }
    
  }
  ]);


/*
Created By:
Purpose:user4Controller For Creating New users SKILL Details 
*/

angular.module('app').controller('user4Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {

    $scope.id=$rootScope.id;
    

    $scope.init=function(){
     
      if($scope.id!=null){
        
        var mdata = {cName:'person',childColName:'', edit_id:$scope.id}
        $http.post('/editUsers',mdata).success(function(data){
          
         $scope.skillDetails=data.skill;
         
         
       });

      }
    }
    $scope.init(); 


    $rootScope.showAccordian = function(){
      if($rootScope.id != null){

        $rootScope.userEduDetail = true;
      }
      else{
        $rootScope.userEduDetail = false;

      }

    }

    $scope.skillDetailsmodel = {};
    $scope.account= [];
    $scope.skillUrl = '';

    $scope.includeSkill = function(){
     
      $scope.skillDetailsmodel = {};
      $scope.skillUrl = "assets/UserManagement/userSkill.html";
    };



    $scope.skillDetailsSubmit = function(form) {
     
     if($scope.Ed_id ==null) {

      $scope.id=$rootScope.id;
      if( $scope.id !=null){

        var mdata = {model: $scope.skillDetailsmodel, cName:'person', childColName:'skill', id:$scope.id}

        $scope.$broadcast('schemaFormValidate');
        if (form.$valid) {
         $http.post('/insertUser',mdata)
         .success(function(data){

          $scope.skillDetails=data;
          $scope.skillUrl = '';
          $scope.skillDetailsmodel = {};
          $rootScope.showExpAccordian();


        });

         
       }

     }

   }
   else{

    $scope.id=$rootScope.id;
    if( $scope.id != null){
      var mdata = {model:$scope.skillDetailsmodel, cName:'person', childColName:'skill', id:$scope.id,Ed_id:$scope.Ed_id}
      $scope.$broadcast('schemaFormValidate');
      if (form.$valid) {
        $http.post('/updateUsersChildCollection',mdata)
        .success(function(data){
          $scope.skillDetails=data;
          $scope.skillUrl = '';
          $scope.skillDetailsmodel = {};
          $rootScope.showExpAccordian();
          $scope.Ed_id=null;

        });

        
      }

    }

  }
};



$scope.editSkill=function(edit_id){

  $scope.skillUrl = "assets/UserManagement/userSkill.html";
  var mdata = {cName:'person',childColName:'skill',Id:$rootScope.id,editEdu_id:edit_id}
  $http.post('/editUsersChildCollection',mdata).success(function(data){

    $scope.skillDetailsmodel=data[0];
    $scope.Ed_id=$scope.skillDetailsmodel.Ed_id;
    
  })

}
$scope.deleteConfirm=function(Ed_id){
  $scope.Ed_id=Ed_id;
  var new_dialog1 = ngDialog.open({
    id: 'fromAService4',
    template: "assets/UserManagement/ui-model-userDelete.html",
    className: 'ngdialog-theme-default role-width',
    scope:$scope,
    closeByDocument: false,

  });
}

$scope.deleteUser=function(Ed_id){
  var mdata = {cName:'person',childColName:'skill',Id:$rootScope.id,editEdu_id:Ed_id}
  $http.post('/deleteUsers',mdata).success(function(data){

   $scope.skillDetails=data;
   $scope.Ed_id=null;
   $scope.closeDialog();
   
 });

}

$rootScope.closeDialog=function(){
  ngDialog.close('fromAService1');
}

$scope.cancel = function() {

  $scope.skillUrl = '';
}

$scope.schema2={

 "type": "object",
 "title": "Comment",

 "properties": {

   "skillName":
   {
    "title": "Skill Name",
    "type": "string",
    "format" : "uiselect",
    "items": {"type": "string"}
  },
  
  "proefficiency": {
    "title": "Proefficiency",
    "type": "string",
    "required":true,
  },
  "description": {
    "title": "Description",
    "type": "string",
    "required":true,
  }

}

};

$scope.form1=[

{
  "key" : "skillName",
  "title" : "Skill Name",
  "placeholder": "Enter Skill Name",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"
},

{
  "key": "proefficiency",
  "title": "Proefficiency",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "description",
  "title": "Description",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

}/*,

{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Cancel"
}
*/
];



}
]);


angular.module('app').controller('viewUsersController', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {



  /*
  Created By:CRM Team
  Purpose:AJAX call to get all registered bdes from db
  */      

  $http.get('/allUsers?cName=person').success(function(data){
    $scope.users = data;
    $scope.currentPage = 1;
    $scope.itemsPerPage = 6;
    $scope.totalItems = $scope.users.length;


  })
  
  $scope.setPage = function (pageNo) {
    $scope.currentPage = pageNo;
  };


/*
  Created By:CRM Team
  Purpose:Function To show creat new bde Form
  */ 

  $scope.displaybdeTpl = function(page){
   $rootScope.userUpload = false;
   $rootScope.userEduDetail = false;
   $rootScope.userExpDetail = false;
   $location.path('/viewUser' + page);
   $scope.editPage = (page === 'assets/UserManagement/userManagement.html') ? 'assets/UserManagement/app_viewUsers.html' : 'assets/UserManagement/userManagement.html';
 }
}]);

angular.module('app').controller('userUploadController', ['$scope','$http','$rootScope', 'Upload', '$timeout',
  function($scope,$http,$rootScope, Upload, $timeout) {

   $scope.uploadPic = function(file) {
    $scope.id=$rootScope.id;
    if( $scope.id !=null){
     
      file.upload = Upload.upload({
        url: 'userfileUpload',
        data: { file: file},
      });

      file.upload.then(function (response) {
        $timeout(function () {
          file.result = response.data;
          var mdata = {model: file.result, cName:'person', id:$scope.id}

          $http.post('/saveImage',mdata)
          .success(function(data){
            
          })
          
        });
      }, function (response) {
        if (response.status > 0)
          $scope.errorMsg = response.status + ': ' + response.data;
      }, function (evt) {
       
        file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
      });


    }

  }

}]);
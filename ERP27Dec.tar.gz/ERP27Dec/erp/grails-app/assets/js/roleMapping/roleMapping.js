angular.module('app').controller('roleMappingController', ['$scope','$http','$rootScope','ngDialog','$timeout','$location','schemaForm','$stateParams',
    function($scope,$http,$rootScope,ngDialog,$timeout,$location,$stateParams) {

$scope.alertUrl="assets/alert.tpl.html";

$scope.addRoleMappings = function(){
    $scope.rolemodel= {};
    $scope.roletplUrl = "assets/RoleMapping/add_roles.html";
}

$scope.showMessage=function(type, messsage){
    $scope.successalert=false;
    $scope.dangeralert=false;
    $scope.isVisible = true;

    if(type=="SUCCESS"){
     
        $scope.successalert=true;
        $timeout(function (){
            $scope.isVisible = false;
            $scope.message = messsage
        }, 3000);

    }else{
        $scope.dangeralert=true;
        $timeout(function (){
            $scope.isVisible = false;
        }, 3000);
    }
};

$scope.roleSchema = {

   "type": "object",
   "title": "Comment",

   "properties": {

     "userDefinedRole": {
      "placeholder": "Enter Defined Role",
      "type": "string",
      "required":true
      

      },
  "systemRole":
                    {

                        "type": "string",
                        "format" : "uiselect",
                        "items": {"type": "string"}
                    }

 }
};

$scope.form = [

   {
    "key": "userDefinedRole",
    "title" : "User Defined Role",
    "type":"string",
   "labelHtmlClass":"form-label",
   "feedback": false,
   "placeholder": "Enter User Defined Role"
  },
  {
    "key" : "systemRole",
    "title" : "System Role",
    "placeholder": "Select System Role",
    "type" : "strapselect",
    "labelHtmlClass":"form-label",
    "feedback": false,
    "options":{"httpGet": {"url": "assets/roles.json"}}
  }
  /*,
  {
          "htmlClass": "col-xs-1",
          "type": "submit",
          "style": "btn-info",
          "title": "Save"
        },
        {
          "htmlClass": "col-xs-1",
          "type": "button",
          "style": "btn-warning",
          "title": "Reset"
        }*/
  ];


/*$http.get('/allData?cName=roleMapping').success(function(data){
              $scope.roleMappingDetails=data;
                            })
*/

$scope.rolemodel= {};

$scope.roleSubmit=function(form) {
  
  if($scope.roleId==null  ){
      $scope.roleId= 0;
     }
  
  var mdata = {model:$scope.rolemodel, cName:'roleMapping',roleId:$scope.roleId}
  $scope.$broadcast('schemaFormValidate');
    
  if (form.$valid) {

          $http.post('/saveRoleMapping',mdata)
                .success(function(data){
                  $scope.roleMappingDetails=data;
                  $scope.rolemodel= {};
                  $scope.roletplUrl = '';
                  $scope.roleId==null;
                  $scope.message = "Role Mapping is added Successfully"  
                  $scope.showMessage("SUCCESS",  $scope.message);

                }) 

          .error(function(data){ console.log(data)
              $scope.message = "SystemRole is Unique for Person select different "
              $scope.showMessage("ERROR", $scope.message)
                  });
            }
	
}

$scope.editroles=function(roleId){
  
    $scope.roleId=roleId;
    $scope.roletplUrl = "assets/RoleMapping/add_roles.html";
    var mdata = {cName:'roleMapping',Id:$scope.roleId}
    $http.post('/findData',mdata).success(function(data){

                 $scope.rolemodel=data;
          })

}

$scope.deleteroles=function(roleId){
  
  $scope.roleId=roleId;
  var new_dialog1 = ngDialog.open({
                id: 'fromAService4',
                template: "assets/ui-modal-delete-rolemap.html",
                className: 'ngdialog-theme-default role-width',
                scope:$scope,
                closeByDocument: false,

              });
}

$scope.deleteData=function(roleId){

 var mdata = {cName:'roleMapping',Id:roleId}
 $http.post('/deleteData',mdata).success(function(data){

              $scope.roleMappingDetails=data;
              $scope.roleId=null;
              $scope.closeDialog();
              $scope.message = "RoleMapping deleted Successfully"  
              $scope.showMessage("SUCCESS",  $scope.message); 
            
        })

}

$scope.closeDialog=function(){
ngDialog.close('fromAService1');
}

$scope.cancel=function(form) {
   $scope.roletplUrl = '';
   $scope.rolemodel= {};
    $scope.roleId=null;
	
}

 }]);
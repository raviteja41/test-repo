/*
Created By:
Purpose:bde Controller For Creating New bdes Personal Details 
*/

angular.module('app').controller('bdeController', ['$scope','$http','$rootScope','$location','schemaForm','$stateParams',
  function($scope,$http,$rootScope,$location,$stateParams) {


   $scope.personalDetailsmodel = {}; 
   $rootScope.id=$scope.id;
   $scope.box_class="box"
   $scope.init=function(){
    if($scope.id!=null){
      
      var mdata = {cName:'bde',childColName:'', edit_id:$scope.id}
      $http.post('/editBdes',mdata).success(function(data){

       $scope.personalDetailsmodel = {"summary":data.summary,"bdeName":data.bdeName,"phoneNumber":data.phoneNumber,"gender":data.gender,
       "dob":data.dob,"email":data.email,"anniversary":data.anniversary,"designation":data.designation,"department":data.department};
       
       $rootScope.bdeEduDetail = true;
       $rootScope.bdeExpDetail = true;
       
       
     }); 

    }
  } 

  $scope.init();   


  $scope.schema1 = {

   "type": "object",
   "title": "Comment",

   "properties": {

     "bdeName": {
      "placeholder": "Enter bde Name",
      "type": "string",
      "required":true,
      

    },

    "department":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },
    "designation":
    {

      "type": "string",
      "format" : "uiselect",

      "items": {"type": "string"}
    },
    "dob": {

      "type": "date",
      "required":true,
    },
    

    "anniversary":{

      "type":"date",
      "validationMessage":" ",
      "required":true

    },

    "gender":
    {

      "type": "string",
      "format" : "uiselect",
      "items": {"type": "string"}
    },

    "phoneNumber":{

     "pattern":"[789][0-9]{9}",
     "type":"string",
     "required":true,
     "maxLength":10,
     "minLength":10,
     "validationMessage":""

   },

   "summary":{

    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""


  },

  "email": {
    "type": "string",
    "pattern":  "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",
    "required":true,
    "pattern": "^\\S+@\\S+$",
    "validationMessage":""

  },

  "bdeGrading":
  {

    "type": "string",
    "format" : "uiselect",

    "items": {"type": "string"}
  }
}

};


$scope.form = [

{
  "key": "bdeName",
  "title" : "bde Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "placeholder": "Enter bde Name"

},


{
  "key" : "department",
  "title" : "Department",
  "placeholder": "Select Department",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}
  

},
{
  "key" : "designation",
  "title" : "Designation",
  "placeholder": "Select Designation",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

},

{
  "key": "dob",
  "title": "Dob",
  "placeholder": "Select DOB",
  "type":"date",
  "feedback": false,
  "labelHtmlClass":"form-label"

},

{
  "key":"anniversary",
  "title":"Anniversary",
  "placeholder": "Select Anniversary",
  "type":"date",
  "feedback": false,
  "labelHtmlClass":"form-label"
},
{
  "key" : "gender",
  "title" : "Gender",
  "placeholder": "Selecte Gender",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "assets/gender.json"}}
  

},
{
  "key": "phoneNumber",
  "title": "Phone Number",
  "feedback":false,
  "placeholder": "Enter phoneNumber",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "summary",
  "title": "Summary",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "key": "email",
  "title": "Email",
  "type":"email",
  "placeholder": "Enter email-id",
  "labelHtmlClass":"form-label",
  "feedback": false

},
{
  "key" : "bdeGrading",
  "title" : "bde Grading",
  "placeholder": "Select bdeGrading",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=GRADING&cName=lookUp"}}

},

{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Reset"
}




];
$scope.bdePersonalDetail = true;
$scope.personalDetailsmodel={};

$scope.saveCollection = function(form) {
  
  if($scope.id ==null  ){
    
    $scope.id = 0;
  }


  var mdata = {model:$scope.personalDetailsmodel, cName:'bde',childColName:'', id:$scope.id}
  $scope.$broadcast('schemaFormValidate');
  
  if (form.$valid) {

    $http.post('/saveBdeData',mdata)
    .success(function(data){
      $scope.id=data;
      $rootScope.id=$scope.id;
      $rootScope.showAccordian();
      $scope.box_class="box collapsed"
      
    }) 
  }

}



}
]);



/*
Created By:
Purpose:bde2Controller For Creating New bdes Education Details 
*/

angular.module('app').controller('bde2Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {

    $scope.id=$rootScope.id;
    

    $scope.init=function(){
     
      if($scope.id!=null){
        
        var mdata = {cName:'bde',childColName:'', edit_id:$scope.id}
        $http.post('/editBdes',mdata).success(function(data){
          
         $scope.educationDetails=data.education;
         
         
       });

      }
    }
    $scope.init(); 



    $rootScope.showAccordian = function(){
      if($rootScope.id != null){

        $rootScope.bdeEduDetail = true;
      }
      else{
        $rootScope.bdeEduDetail = false;

      }

    }

    $scope.educationDetailsmodel = {};
    $scope.account= [];
    $scope.templateUrl = '';

    $scope.addRow = function(){
     
      $scope.educationDetailsmodel = {};
      $scope.templateUrl = "assets/Bde/bdeEducationForm.html";
    };

    


    $scope.educationDetailsSubmit = function(form) {
     
     if($scope.Ed_id ==null) {

      $scope.id=$rootScope.id;
      if( $scope.id !=null){

        var mdata = {model: $scope.educationDetailsmodel, cName:'bde', childColName:'education', id:$scope.id}

        $scope.$broadcast('schemaFormValidate');
        if (form.$valid) {
         $http.post('/saveBdeData',mdata)
         .success(function(data){
          $scope.educationDetails=data;
          $scope.templateUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();


        });

         
       }

     }

   }
   else{

    $scope.id=$rootScope.id;
    if( $scope.id !=null){
      var mdata = {model:$scope.educationDetailsmodel, cName:'bde', childColName:'education', id:$scope.id,Ed_id:$scope.Ed_id}
      $scope.$broadcast('schemaFormValidate');
      if (form.$valid) {
        $http.post('/saveEditbdeData',mdata)
        .success(function(data){
          $scope.educationDetails=data;
          $scope.templateUrl = '';
          $scope.educationDetailsmodel = {};
          $rootScope.showExpAccordian();
          $scope.Ed_id=null;

        });

        
      }

    }

  }
};


$scope.editEducation=function(edit_id){

  $scope.templateUrl = "assets/Bde/bdeEducationForm.html";
  var mdata = {cName:'bde',childColName:'education',Id:$rootScope.id,editEdu_id:edit_id}
  $http.post('/editBdesEducation',mdata).success(function(data){

    $scope.educationDetailsmodel=data[0];
    $scope.Ed_id=$scope.educationDetailsmodel.Ed_id;
    
  })

}

$scope.deleteEducationConfirm=function(Ed_id){
 
  $scope.Ed_id=Ed_id;
  var new_dialog1 = ngDialog.open({
    id: 'fromAService4',
    template: "assets/bdeEducationDelete.html",
    className: 'ngdialog-theme-default role-width',
    scope:$scope,
    closeByDocument: false,

  });
}

$scope.deleteEducation=function(Ed_id){
  
  var mdata = {cName:'bde',childColName:'education',Id:$rootScope.id,editEdu_id:Ed_id}
  $http.post('/deleteBde',mdata).success(function(data){

    $scope.educationDetails=data;
    $scope.closeDialog();
    
  });

}

$scope.closeDialog=function(){
  ngDialog.close('fromAService1');
}


$scope.schema2={

 "type": "object",
 "title": "Comment",

 "properties": {

   "qualification":
   {
    "title": "Qualification",
    "type": "string",
    "format" : "uiselect",
    "items": {"type": "string"}
  },
  
  "university": {
    "title": "University",
    "type": "string",
    "required":true,
  },
  "location": {
    "title": "Location",
    "type": "string",
    "required":true,
  },
  "comments": {
    "title":"Comments",
    "type":"string",
    "required":true,
    "minLength":5,
    "validationMessage":""
  },

}

};

$scope.form1=[

{
  "key" : "qualification",
  "title" : "Qualifaction",
  "placeholder": "none selected",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=QUALIFICATION&cName=lookUp"}}
},

{
  "key": "university",
  "title": "University",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "location",
  "title": "Location",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label"

},
{
  "key": "comments",
  "title": "Comments",
  "type": "textarea",
  "labelHtmlClass":"form-label",
  "placeholder": ""

},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-info",
  "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Cancel"
}

];



}
]);


/*
Created By:
Purpose:bde3Controller For Creating New bdes Experince Details 
*/

angular.module('app').controller('bde3Controller', ['$scope','$http','$rootScope','ngDialog',
  function($scope,$http,$rootScope,ngDialog) {


    $scope.id=$rootScope.id;

    $scope.init=function(){
      if($scope.id!=null){
        var mdata = {cName:'bde',childColName:'', edit_id:$scope.id}
        $http.post('/editBdes',mdata).success(function(data){
          
         $scope.experienceDetails=data.experience;
         
         
       });

      }
    }

    $scope.init(); 


    $scope.experiencemodel = {};

    $rootScope.showExpAccordian = function(){
      if($rootScope.id != null){
        $rootScope.bdeExpDetail = true;
      }
      else{
        $rootScope.bdeExpDetail = false;
      }

    }

    $scope.experienceUrl = '';
    var bdeExpSet = [];

    $scope.includeExperience = function(){
      $scope.experiencemodel = {};
      $scope.experienceUrl = "assets/Bde/bdeExperienceForm.html";
    }

    $scope.editExperience=function(edit_id){

      $scope.experienceUrl = "assets/Bde/bdeExperienceForm.html";
      var mdata = {cName:'bde',childColName:'experience',Id:$rootScope.id,editEdu_id:edit_id}
      $http.post('/editBdesEducation',mdata).success(function(data){

        $scope.experiencemodel =data[0];
        $scope.Ed_id=$scope.experiencemodel.Ed_id;
        
      })

    }

    $scope.deleteExperienceConfirm=function(Ed_id){
      $scope.Ed_id=Ed_id;
      var new_dialog1 = ngDialog.open({
        id: 'fromAService4',
        template: "assets/bdeExperienceDelete.html",
        className: 'ngdialog-theme-default role-width',
        scope:$scope,
        closeByDocument: false,

      });
    }

    $scope.deleteExperience=function(Ed_id){
      
      var mdata = {cName:'bde',childColName:'experience',Id:$rootScope.id,editEdu_id:Ed_id}
      $http.post('/deleteBde',mdata).success(function(data){

       $scope.experienceDetails=data;
       $scope.closeDialog();
       
     });

    }
    
    $scope.closeDialog=function(){
      ngDialog.close('fromAService1');
    }


    $scope.schema3={

      "type": "object",
      "title": "Comment",
      "properties": {

        "hospitalName": {
          "title": "Hospital Name",
          "type": "string",
          "required":true,
        },


        "department":
        {
          "title": "Department",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },

        "designation":
        {
          "title": "Designation",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"}
        },

        "noOfYears":
        {
          "title": "No Of Years",
          "type": "string",
          "format" : "uiselect",
          "items": {"type": "string"},
          "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}
        },



      }

    };


    $scope.form2=[
    {
      "key": "hospitalName",
      "title": "Hospital Name",
      "type":"string",
      "labelHtmlClass":"form-label",
      "feedback": false

    },
    {
      "key" : "department",
      "title" : "Department",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DEPARTMENT&cName=lookUp"}}

    },
    {
      "key" : "designation",
      "title" : "Designation",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=DESIGNATION&cName=lookUp"}}

    },
    {
      "key" : "noOfYears",
      "title" : "No Of Years",
      "placeholder": "none selected",
      "type" : "strapselect",
      "labelHtmlClass":"form-label",
      "feedback": false,
      "options":{"httpGet": {"url": "/lookUpData?type=NUMBER OF YEARS&cName=lookUp"}}

    },
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-info",
      "title": "Save"
    },
    {
      "htmlClass": "col-xs-1",
      "type": "submit",
      "style": "btn-warning",
      "title": "Reset"
    }



    ];

    

    

    $scope.experienceSubmit = function(form) {

      if($scope.Ed_id==null){
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model: $scope.experiencemodel, cName:'bde', childColName:'experience', id:$scope.id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/saveBdeData',mdata)
            .success(function(data){
              
              $scope.experienceDetails=data;
              $scope.experienceUrl = '';
              $scope.experiencemodel = {};
              
            })

            
          }

        }
      }
      else{
        $scope.id=$rootScope.id;
        if( $scope.id !=null){
          var mdata = {model:$scope.experiencemodel, cName:'bde', childColName:'experience', id:$scope.id,Ed_id:$scope.Ed_id}
          $scope.$broadcast('schemaFormValidate');
          if (form.$valid) {
            $http.post('/saveEditbdeData',mdata)
            .success(function(data){
              $scope.experienceDetails=data;
              $scope.experienceUrl = '';
              $scope.experiencemodel = {};
              $scope.Ed_id=null;

            });

            
          }

        }

      }
      
    }
    
  }
  ]);
angular.module('app').controller('viewbdes', ['$scope','$http','$location','schemaForm','$rootScope',
  function($scope,$http,$location,$rootScope) {

/*
  Created By:CRM Team
  Purpose:AJAX call to get all registered bdes from db
  */      

  $http.get('/allBdes?cName=bde').success(function(data){
    $scope.bdes = data;
  })

/*
  Created By:CRM Team
  Purpose:Function To show creat new bde Form
  */ 

  $scope.displaybdeTpl = function(page){
    $rootScope.bdeEduDetail = false;
    $rootScope.bdeExpDetail = false;
    $location.path('/viewBde' + page);
    $scope.editPage = (page === 'assets/app_bde.html') ? 'assets/app_viewbde.html' : 'assets/app_bde.html';
  }

/*
  Created By:CRM Team
  Purpose:Function To show Edit bde Screen
  */  

  $scope.editBdeTpl = function(id){

    var mdata = {model:$scope.personalDetailsmodel, cName:'bde',childColName:'', edit_id:id}
    $http.post('/editBdes',mdata).success(function(data){
      
      $scope.personalDetailsmodel=data;
    })

  }


}]);
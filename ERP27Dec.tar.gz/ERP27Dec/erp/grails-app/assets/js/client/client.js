/*
 CreatedBy:CRM Team.
 Purpose:Client Controller For Creating New Client.
 */


 angular.module('app').controller('clientController', ['$scope','$http','ngDialog','$timeout','$rootScope','$window',
  function($scope,$http,ngDialog,$timeout,$rootScope,$window) {

    $scope.alertUrl="assets/alert.tpl.html";

    $scope.showMessage=function(type, messsage){
    $scope.successalert=false;
    $scope.dangeralert=false;
    $scope.isVisible = true;

    if(type=="SUCCESS"){
     
        $scope.successalert=true;
        $timeout(function (){
            $scope.isVisible = false;
            $scope.message = messsage
        }, 3000);

    }else{
        $scope.dangeralert=true;
        $timeout(function (){
            $scope.isVisible = false;
        }, 3000);
    }
};

    $scope.addRow = function(){
      
      $scope.clientDetailsmodel = {};
      $scope.clientUrl = "assets/Client/clientForm.html";
      $scope.readonly = { formDefaults: { readonly: false } };
      
    };
    
    $scope.schema = {
     
     "type": "object",
     "title": "Comment",
     
     "properties": {

       "clientName": {
         "type": "string",
         "required":true,
         "placeholder": "Enter client Name",

       },

       
       "address": {
        
        "type": "string",
        "placeholder": "Enter client Address",
        
      },

      "industry":
      {

        "type": "string",
        "required":true,
        "format" : "uiselect",
        "items": {"type": "string"}
      },
      "phoneNumber":{
        
        "pattern":"[789][0-9]{9}",
        "type":"string",
        "required":true,
        "maxLength":10,
        "minLength":10,
        "validationMessage":""

      },

      "email": {
        "type": "string",
        "pattern": "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",
        "required":true,
        "pattern": "^\\S+@\\S+$",
        "validationMessage":""
        
      },

      "website": {
        
       "type": "string",
       "placeholder": "Enter website",
       
     },
     
     "userId": {
      
      "type": "string",
      "placeholder": "Enter User Id",
      "required":true,
    },

    "password": {
      
      "type": "string",
      "placeholder": "Enter Password",
      "required":true,
    },

  }

};


$scope.form = [

{
  "key": "clientName",
  "title" : "Client Name",
  "type":"string",
  "labelHtmlClass":"form-label",
  "feedback": false

},


{
  "key": "address",
  "title": "Address",
  "type":"string",
  "feedback": false,
  "labelHtmlClass":"form-label",
  "readonly": false

},
{
  "key" : "industry",
  "title" : "Industry",
  "placeholder": "Select Industry Type",
  "type" : "strapselect",
  "labelHtmlClass":"form-label",
  "feedback": false,
  "options":{"httpGet": {"url": "/lookUpData?type=INDUSTRY&cName=industry"}}
  

},

{
  "key": "phoneNumber",
  "title": "Phone Number",
  "feedback":false,
  "labelHtmlClass":"form-label",
  "placeholder": "",
  "readonly": false

},
{
 "key": "email",
 "title": "Email",
 "type":"email",
 "labelHtmlClass":"form-label",
 "feedback": false,
 "readonly": false

},


{
 "key": "website",
 "title": "Website",
 "type": "string",
 "labelHtmlClass":"form-label",
 "placeholder": "",
 "readonly": false

},
{
 "key": "userId",
 "title": "User Id",
 "type": "string",
 "labelHtmlClass":"form-label",
 "placeholder": ""
},

{
 "key": "password",
 "title": "Password",
 "type": "string",
 "labelHtmlClass":"form-label",
 "placeholder": ""

}/*,


{
 "htmlClass": "col-xs-1",
 "type": "submit",
 "style": "btn-info",
 "title": "Save"
},
{
  "htmlClass": "col-xs-1",
  "type": "submit",
  "style": "btn-warning",
  "title": "Reset"
}

*/


];

/*
 CreatedBy:CRM Team.
 Purpose:To Perform Insert Operation.
 */
 $scope.clientDetailsmodel={};
 
 $scope.saveCollection = function(form) {
  if($scope.id ==null  ){
    
    $scope.id = 0;
  }
  var mdata = {model:$scope.clientDetailsmodel, cName:'client',childColName:'', id:$scope.id}
  $scope.$broadcast('schemaFormValidate');
  
  if (form.$valid) {

    $http.post('/saveClientData',mdata)
    .success(function(data){
        $scope.clientDetails=data;
        $scope.clientUrl = '';  
        $scope.message = "Client is added Successfully"  
        $scope.showMessage("SUCCESS",  $scope.message);    
     }) 
    .error(function(data){ console.log(data)
              $scope.message = "Error Occured pleas check the entry "
              $scope.showMessage("ERROR", $scope.message)
                  });
  }

}
  /*
   CreatedBy:CRM Team.
   Purpose:To Perform Update Operation.
   */
   $scope.editClient=function(edit_id){
    
    
    $scope.clientUrl = "assets/Client/clientForm.html";
    $scope.readonly = { formDefaults: { readonly : true } };
    var mdata = {cName:'client',Id:$rootScope.id,edit_id:edit_id}
    $http.post('/findClient',mdata).success(function(data){
        $scope.clientDetailsmodel=data;
        $scope.id=$scope.clientDetailsmodel._id;
    })
  }

  /*
   CreatedBy:CRM Team.
   Purpose:To Perform Delete Operation.
   */

   $scope.deleteClientConfirm=function(Id){
    
    $scope.Id=Id;
    
    var new_dialog = ngDialog.open({
      id: 'fromAService4',
      template: "assets/Client/ui-model-client_Delete.html",
      className: 'ngdialog-theme-default role-width',
      scope:$scope,
      closeByDocument: false,

    });

  }

  $scope.deleteClient=function(Id){
    
    var mdata = {cName:'client',id:$scope.Id}
    $http.post('/deleteClient',mdata).success(function(data){
      $scope.clientDetails=data;
      $scope.Id = '';
      $scope.closeDialog();
      $scope.message = "Client deleted Successfully"  
      $scope.showMessage("SUCCESS",  $scope.message); 
      
    });

  }


  $scope.closeDialog=function(){
    ngDialog.close('fromAService1');
  }

  $scope.cancel=function(){

      $scope.clientUrl = '';

  }

}
]);



import erp.User
import erp.Role
import erp.UserRole

class BootStrap {

     def init = { servletContext ->
		
		def superAdminRole  = Role.findByAuthority('ROLE_SADMIN') ?: new Role(authority: 'ROLE_SADMIN', description: 'Super Administrator').save(failOnError: true)
		def clientAdminRole = Role.findByAuthority('ROLE_CLIENTADMIN') ?: new Role(authority: 'ROLE_CLIENTADMIN', description: 'Client Admin').save(failOnError: true)
		def roleLevel1      = Role.findByAuthority('ROLE_LEVEL1') ?: new Role(authority: 'ROLE_LEVEL1', description: 'Role Level 1').save(failOnError: true)
		def roleLevel2  = Role.findByAuthority('ROLE_LEVEL2') ?: new Role(authority: 'ROLE_LEVEL2', description: 'Role Level 2').save(failOnError: true)
		def roleLevel3  = Role.findByAuthority('ROLE_LEVEL3') ?: new Role(authority: 'ROLE_LEVEL3', description: 'Role Level 3').save(failOnError: true)
		def roleLevel4  = Role.findByAuthority('ROLE_LEVEL4') ?: new Role(authority: 'ROLE_LEVEL4', description: 'Role Level 4').save(failOnError: true)
		def roleLevel5  = Role.findByAuthority('ROLE_LEVEL5') ?: new Role(authority: 'ROLE_LEVEL5', description: 'Role Level 5').save(failOnError: true)
		def roleLevel6  = Role.findByAuthority('ROLE_LEVEL6') ?: new Role(authority: 'ROLE_LEVEL6', description: 'Role Level 6').save(failOnError: true)
		def roleLevel7  = Role.findByAuthority('ROLE_LEVEL7') ?: new Role(authority: 'ROLE_LEVEL7', description: 'Role Level 7').save(failOnError: true)
		def roleLevel8  = Role.findByAuthority('ROLE_LEVEL8') ?: new Role(authority: 'ROLE_LEVEL8', description: 'Role Level 8').save(failOnError: true)
		def roleLevel9  = Role.findByAuthority('ROLE_LEVEL9') ?: new Role(authority: 'ROLE_LEVEL9', description: 'Role Level 9').save(failOnError: true)
		def roleLevel10 = Role.findByAuthority('ROLE_LEVEL10') ?: new Role(authority: 'ROLE_LEVEL10', description: 'Role Level 10').save(failOnError: true)
		def roleLevel11 = Role.findByAuthority('ROLE_LEVEL11') ?: new Role(authority: 'ROLE_LEVEL11', description: 'Role Level 11').save(failOnError: true)
		def roleLevel12 = Role.findByAuthority('ROLE_LEVEL12') ?: new Role(authority: 'ROLE_LEVEL12', description: 'Role Level 12').save(failOnError: true)
		
		def superAdminUser = User.findByUsername('vtpladmin') ?: new User(
		           username: 'vtpladmin',
		           email:'vtpladmin@vegantar.com',
		           clientId: 0,
		           industryId :0,
		           password: 'admin',
		           phone: '9282929827',
		           address: 'Bangalore',
		           enabled: true,
		           authorities: [superAdminRole]).save(failOnError: true)

        def clientAdminUser = User.findByUsername('vtpluser') ?: new User(
		           username: 'vtpluser',
		           email:'vtpluser@vegantar.com',
		           clientId: 0,
		           industryId :0,
		           password: 'user',
		           phone: '9282929817',
		           address: 'Bangalore',
		            enabled: true,
            	  authorities: [clientAdminRole]).save(failOnError: true)		
    }
    def destroy = {
    }
}

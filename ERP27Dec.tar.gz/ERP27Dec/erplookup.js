db.lookUp.insert([
  {
    "code": "1",
    "type": "ADDRESS TYPE",
    "name": "Home",
    "value": "Home",
    "relation": "0"
  },
    {
    "code": "2",
    "type": "ADDRESS TYPE",
    "name": "Mailing",
    "value": "Mailing",
    "relation": "0"
  },
    {
    "code": "3",
    "type": "ADDRESS TYPE",
    "name": "Office",
    "value": "Office",
    "relation": "0"
  },
     {
    "code": "4",
    "type": "CASTE",
    "name": "LINGAYAT",
    "value": "LINGAYAT",
    "relation": "0"
  },
    {
    "code": "5",
    "type": "CASTE",
    "name": "BRAHMIN",
    "value": "BRAHMIN",
    "relation": "0"
  },
    {
    "code": "6",
    "type": "CASTE",
    "name": "MARATAS",
    "value": "MARATAS",
    "relation": "0"
  },
    {
    "code": "7",
    "type": "CASTE",
    "name": "BAHUSARA KSHATRIYA",
    "value": "BAHUSARA KSHATRIYA",
    "relation": "0"
  },
    {
    "code": "8",
    "type": "CASTE",
    "name": "KURUBA",
    "value": "KURUBA",
    "relation": "0"
  },
    {
    "code": "9",
    "type": "CASTE",
    "name": "SC",
    "value": "SC",
    "relation": "0"
  },
    {
    "code": "10",
    "type": "CASTE",
    "name": "ST",
    "value": "ST",
    "relation": "0"
  },
    {
    "code": "11",
    "type": "CASTE",
    "name": "GOWDS",
    "value": "GOWDS",
    "relation": "0"
  },
    {
    "code": "12",
    "type": "CASTE",
    "name": "MUSLIM",
    "value": "MUSLIM",
    "relation": "0"
  },
    {
    "code": "13",
    "type": "CASTE",
    "name": "CHRISTIAN",
    "value": "CHRISTIAN",
    "relation": "0"
  },
      {
    "code": "14",
    "type": "DOCUMENT TYPE",
    "name": "Driving License",
    "value": "Driving License",
    "relation": "0"
  },
    {
    "code": "15",
    "type": "DOCUMENT TYPE",
    "name": "Aadhaar Card",
    "value": "Aadhaar Card",
    "relation": "0"
  },
    {
    "code": "16",
    "type": "DOCUMENT TYPE",
    "name": "Passport",
    "value": "Passport",
    "relation": "0"
  },
    {
    "code": "17",
    "type": "DOCUMENT TYPE",
    "name": "Voter ID",
    "value": "Voter ID",
    "relation": "0"
  },
    {
    "code": "18",
    "type": "DOCUMENT TYPE",
    "name": "Pan Card",
    "value": "Pan Card",
    "relation": "0"
  },
    {
    "code": "19",
    "type": "DOCUMENT TYPE",
    "name": "Birth Certificate",
    "value": "Birth Certificate",
    "relation": "0"
  },
    {
    "code": "20",
    "type": "DOCUMENT TYPE",
    "name": "Offer Letter",
    "value": "Offer Letter",
    "relation": "0"
  },
    {
    "code": "21",
    "type": "DOCUMENT TYPE",
    "name": "Others",
    "value": "Others",
    "relation": "0"
  },{
    "code": "22",
    "type": "GENDER",
    "name": "MALE",
    "value": "MALE",
    "relation": "0"
  },
    {
    "code": "23",
    "type": "GENDER",
    "name": "FEMALE",
    "value": "FEMALE",
    "relation": "0"
  },
    {
    "code": "24",
    "type": "GENDER",
    "name": "OTHER",
    "value": "OTHER",
    "relation": "0"
  },
      {
    "code": "25",
    "type": "IDENTIFICATION PROOF",
    "name": "Driving License",
    "value": "Driving License",
    "relation": "0"
  },
    {
    "code": "26",
    "type": "IDENTIFICATION PROOF",
    "name": "Aadhaar Card",
    "value": "Aadhaar Card",
    "relation": "0"
  },
    {
    "code": "27",
    "type": "IDENTIFICATION PROOF",
    "name": "Passport",
    "value": "Passport",
    "relation": "0"
  },
    {
    "code": "28",
    "type": "IDENTIFICATION PROOF",
    "name": "Voter ID",
    "value": "Voter ID",
    "relation": "0"
  },
    {
    "code": "29",
    "type": "IDENTIFICATION PROOF",
    "name": "Pan Card",
    "value": "Pan Card",
    "relation": "0"
  },
    {
    "code": "30",
    "type": "IDENTIFICATION PROOF",
    "name": "Others",
    "value": "Others",
    "relation": "0"
  },
    {
    "code": "31",
    "type": "INSURENCE DETAILS",
    "name": "Life Insurance",
    "value": "Life Insurance",
    "relation": "0"
  },
    {
    "code": "32",
    "type": "INSURENCE DETAILS",
    "name": "Health Insurance",
    "value": "Health Insurance",
    "relation": "0"
  },
    {
    "code": "33",
    "type": "INSURENCE DETAILS",
    "name": "Accidental Policy",
    "value": "Accidental Policy",
    "relation": "0"
  },
    {
    "code": "34",
    "type": "INSURENCE DETAILS",
    "name": "ESI",
    "value": "ESI",
    "relation": "0"
  },
    {
    "code": "35",
    "type": "INSURENCE DETAILS",
    "name": "Others",
    "value": "Others",
    "relation": "0"
  },
    {
    "code": "36",
    "type": "JOB DETAILS",
    "name": "PROBATIONARY",
    "value": "PROBATIONARY",
    "relation": "0"
  },
    {
    "code": "37",
    "type": "JOB DETAILS",
    "name": "PERMANENT",
    "value": "PERMANENT",
    "relation": "0"
  },
    {
    "code": "38",
    "type": "JOB DETAILS",
    "name": "TRAINEE",
    "value": "TRAINEE",
    "relation": "0"
  },
    {
    "code": "39",
    "type": "JOB DETAILS",
    "name": "CONTRACT",
    "value": "CONTRACT",
    "relation": "0"
  }
]);
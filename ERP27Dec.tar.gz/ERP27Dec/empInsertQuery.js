db.employeeInfo.insert([

{              "id": "",
		"empCode": "14",
		"firstName": "chetan",
		"middleName": "kumar",
		"lastName": "pandey",
		"shortName": "chetan",
		"dob": "02-12-1992",
		"fatherName": "Arvind",
		"spouseName": "vtplhr",
		"mobile": "99809908",
		"gender": "Male",
		"Place of Birth": "",
		"Religion": "",
		"marritalStatus": "",
		"nationality": "",
		"caste": "",
		"languages": "hr",
		"motherTongue": "",
		"identificationMark": "",
		"bloodGroup": "",
		"weight": "",
		"height": "",
		"remarks": ""
	}
])

db.contactInfo.insert([
         {      "empCode": "",
		"landLine": "",
		"mobile1": "",
		"mobile2": "",
		"email": ""
	}
])


db.bankDetails.insert([

        {       "empCode": "14",
		"bankIfsc": "",
		"bankAcc": "",
		"branchAddress": "",
		"salaryAcc": "Yes/No",
		"email": ""
	}
])


db.jobDetails.insert([
      {
               "empCode": "14",
		"category": "",
		"department": "",
		"designation": "",
		"reportingManager": "Yes",
		"fromDate": "",
                "toDate": "",
		"relievingReason": "",
		"referredPersonName": "",
                "remarks": ""
	}
])

db.skillsDetails.insert([
{
"empCode":" ",
"skills": ["","",""]
}
])



db.experienceDetails.insert([
 {             "empCode": "14",
		"companyName": "",
		"fromDate": "",
		"toDate": "",
		"experience": "",
		"designation": "",
                "relievingReason": "",
		"lastSalary": "",
		"duties": "",
                "achievement": "",
                "referencePerson": "",
		"address": "",
                "city": "",
		"state": "",
		"country":""
	}
])


db.addressDetails.insert([

      {        "empCode": "14",  
		"addressType": "",
		"address1": "",
		"address2": "",
		"city": "",
		"state": "",
                "country": "",
		"pincode": ""
		
	}
])



db.educationDetails.insert([

     {         "empCode": "14",
		"courseCode": "",
		"course": "",
		"duration": "",
		"startDate": "",
		"endDate": "",
                "class": "",
		"percentage": "",
		"achievement": "",
                "universityName": "",
                "institutionName": "",
		"institutionAddress": "",
                "city": "",
		"state": "",
		"country":"",
               "pincode": "",
               "comments":""
	}
])




db.familyDetails.insert([

 {             "empCode": "14",
		"firstName": "",
		"middleName": "",
		"lastName": "",
		"relation": "",
		"dob": "",
                "gender": "",
		"isDependent": "",
		"isEmployee": "",
                "pfNominee": "yes/no",
                "occupation": "",
		"remark": ""
                
	}
])



db.vehicleDetails.insert([

{             
               "empCode": "14",
		"vehicleType": "",
		"vehicleColor": "",
		"vehicleRegNo": "",
		"vehicleMake": "",
		"vehicleModel": "",
                "vehicleOwner": "",
		"vehicleDesc": "",
		"parkingStickerIssuedDate": "",
                "parkingStickerExpiryDate": "",
                "parkingSlot": ""
		
                
	}
])



db.identificationProofs.insert([

        {       
		"type": "",
		"uniqueNumber": "",
		"issuedDate": "",
		"expiryDate": "",
		"issuedPlace": ""
                
	}
])



db.insuranceDetails.insert([
 {
		"policyNo": "",
		"policyName": "",
		"issuedDate": "",
		"expiryDate": "",
		"insuredAmount": "",
                "premiumAmount": "",
		"nomineeName": "",
		"salaryDeductible": "yes/no",
                "deductibleAmount": ""
                
	}
])



db.documentsDetails.insert([
       {	"documentType": "",
		"documentDescription": ""
                
	}

])


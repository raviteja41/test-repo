db.lookUp.insert([
  {
    "code": "1",
    "type": "DEPARTMENT",
    "name": "Audiologist",
    "value": "Audiologist",
    "relation": "0"
  },
  {
    "code": "2",
    "type": "DEPARTMENT",
    "name": "Cardiologist",
    "value": "Cardiologist",
    "relation": "0"
  },
  {
    "code": "3",
    "type": "DEPARTMENT",
    "name": "Dermatologist",
    "value": "Dermatologist",
    "relation": "0"
  },
  {
    "code": "4",
    "type": "DEPARTMENT",
    "name": "Endocrinologist",
    "value": "Endocrinologist",
    "relation": "0"
  },
  {
    "code": "5",
    "type": "DEPARTMENT",
    "name": "Gynecologist",
    "value": "Gynecologist",
    "relation": "0"
  },
  {
    "code": "6",
    "type": "DEPARTMENT",
    "name": "Epidemiologist",
    "value": "Epidemiologist",
    "relation": "0"
  },
  {
    "code": "7",
    "type": "DEPARTMENT",
    "name": "Allergist",
    "value": "Allergist",
    "relation": "0"
  },
  {
    "code": "8",
    "type": "DEPARTMENT",
    "name": "Oncologist",
    "value": "Oncologist",
    "relation": "0"
  },
  {
    "code": "9",
    "type": "DEPARTMENT",
    "name": "Pediatrician",
    "value": "Pediatrician",
    "relation": "0"
  },
  {
    "code": "10",
    "type": "DEPARTMENT",
    "name": "Physiologist",
    "value": "Physiologist",
    "relation": "0"
  },
  {
    "code": "11",
    "type": "DESIGNATION",
    "name": "Surgeon",
    "value": "Surgeon",
    "relation": "0"
  },
  {
    "code": "12",
    "type": "DESIGNATION",
    "name": "Junior Doctor",
    "value": "JuniorDoctor",
    "relation": "0"
  },
  {
    "code": "13",
    "type": "DESIGNATION",
    "name": "Senior Doctor",
    "value": "SeniorDoctor",
    "relation": "0"
  },
  {
    "code": "14",
    "type": "DESIGNATION",
    "name": "OperationTheatre Nurse",
    "value": "OperationTheatreNurse",
    "relation": "0"
  },
  {
    "code": "15",
    "type": "DESIGNATION",
    "name": "General Doctor",
    "value": "GeneralDoctor",
    "relation": "0"
  },
  {
    "code": "16",
    "type": "DESIGNATION",
    "name": "House Surgeon",
    "value": "HouseSurgeon",
    "relation": "0"
  },
  {
    "code": "17",
    "type": "DESIGNATION",
    "name": "Physician",
    "value": "Physician",
    "relation": "0"
  },
  {
    "code": "18",
    "type": "GRADING",
    "name": "GradeA",
    "value": "GradeA",
    "relation": "0"
  },
  {
    "code": "19",
    "type": "GRADING",
    "name": "GradeB",
    "value": "GradeB",
    "relation": "0"
  },
  {
    "code": "20",
    "type": "GRADING",
    "name": "GradeC",
    "value": "GradeC",
    "relation": "0"
  },
  {
    "code": "21",
    "type": "GRADING",
    "name": "GradeD",
    "value": "GradeD",
    "relation": "0"
  },
  {
    "code": "22",
    "type": "GRADING",
    "name": "GradeE",
    "value": "GradeE",
    "relation": "0"
  },
  {
    "code": "23",
    "type": "GRADING",
    "name": "GradeF",
    "value": "GradeF",
    "relation": "0"
  },
  {
    "code": "24",
    "type": "GRADING",
    "name": "GradeG",
    "value": "GradeG",
    "relation": "0"
  },
  {
    "code": "25",
    "type": "QUALIFICATION",
    "name": "M.B.B.S",
    "value": "M.B.B.S",
    "relation": "0"
  },
  {
    "code": "26",
    "type": "QUALIFICATION",
    "name": "B.D.S",
    "value": "B.D.S",
    "relation": "0"
  },
  {
    "code": "27",
    "type": "QUALIFICATION",
    "name": "B.H.M.S",
    "value": "B.H.M.S",
    "relation": "0"
  },
  {
    "code": "28",
    "type": "QUALIFICATION",
    "name": "B.P.T",
    "value": "B.P.T",
    "relation": "0"
  },
  {
    "code": "29",
    "type": "QUALIFICATION",
    "name": "B.U.M.S",
    "value": "B.U.M.S",
    "relation": "0"
  },
  {
    "code": "30",
    "type": "QUALIFICATION",
    "name": "B.A.M.S",
    "value": "B.A.M.S",
    "relation": "0"
  },
  {
    "code": "31",
    "type": "QUALIFICATION",
    "name": "Optometry",
    "value": "Optometry",
    "relation": "0"
  },
  {
    "code": "32",
    "type": "QUALIFICATION",
    "name": "Radiography",
    "value": "Radiography",
    "relation": "0"
  },
  {
    "code": "33",
    "type": "QUALIFICATION",
    "name": "D.Pharma",
    "value": "D.Pharma",
    "relation": "0"
  },
  {
    "code": "34",
    "type": "QUALIFICATION",
    "name": "B.Pharma",
    "value": "B.Pharma",
    "relation": "0"
  },
  {
    "code": "35",
    "type": "QUALIFICATION",
    "name": "FRCS",
    "value": "FRCS",
    "relation": "0"
  },
  {
    "code": "36",
    "type": "NUMBER OF YEARS",
    "name": "1",
    "value": "1",
    "relation": "0"
  },
  {
    "code": "37",
    "type": "NUMBER OF YEARS",
    "name": "2",
    "value": "2",
    "relation": "0"
  },
  {
    "code": "38",
    "type": "NUMBER OF YEARS",
    "name": "3",
    "value": "3",
    "relation": "0"
  },
  {
    "code": "39",
    "type": "NUMBER OF YEARS",
    "name": "4",
    "value": "4",
    "relation": "0"
  },
  {
    "code": "40",
    "type": "NUMBER OF YEARS",
    "name": "5",
    "value": "5",
    "relation": "0"
  },
  {
    "code": "41",
    "type": "NUMBER OF YEARS",
    "name": "6",
    "value": "6",
    "relation": "0"
  },
  {
    "code": "42",
    "type": "NUMBER OF YEARS",
    "name": "7",
    "value": "7",
    "relation": "0"
  },
  {
    "code": "43",
    "type": "NUMBER OF YEARS",
    "name": "8",
    "value": "8",
    "relation": "0"
  },
  {
    "code": "44",
    "type": "NUMBER OF YEARS",
    "name": "9",
    "value": "9",
    "relation": "0"
  },
  {
    "code": "45",
    "type": "NUMBER OF YEARS",
    "name": "10",
    "value": "10",
    "relation": "0"
  },
  {
    "code": "46",
    "type": "EDUCATION",
    "name": "BE",
    "value": "BE",
    "relation": "0"
  },
  {
    "code": "47",
    "type": "EDUCATION",
    "name": "MBA",
    "value": "MBA",
    "relation": "0"
  },
  {
    "code": "48",
    "type": "EDUCATION",
    "name": "BCA",
    "value": "BCA",
    "relation": "0"
  },
  {
    "code": "49",
    "type": "EDUCATION",
    "name": "BSC",
    "value": "BSC",
    "relation": "0"
  },
  {
    "code": "50",
    "type": "EDUCATION",
    "name": "MSC",
    "value": "MSC",
    "relation": "0"
  },
  {
    "code": "51",
    "type": "EDUCATION",
    "name": "BBM",
    "value": "BBM",
    "relation": "0"
  },
  {
    "code": "52",
    "type": "EDUCATION",
    "name": "BA",
    "value": "BA",
    "relation": "0"
  },
  {
    "code": "53",
    "type": "EDUCATION",
    "name": "MCA",
    "value": "MCA",
    "relation": "0"
  },
  {
    "code": "54",
    "type": "EDUCATION",
    "name": "BCOM",
    "value": "BCOM",
    "relation": "0"
  },
  {
    "code": "55",
    "type": "EDUCATION",
    "name": "BHM",
    "value": "BHM",
    "relation": "0"
  },
  {
    "code": "56",
    "type": "EDUCATION",
    "name": "LLB",
    "value": "LLB",
    "relation": "0"
  },
  {
    "code": "57",
    "type": "STATE",
    "name": "Karnataka",
    "value": "Karnataka",
    "relation": "0"
  },
  {
    "code": "58",
    "type": "STATE",
    "name": "Tamil Nadu",
    "value": "Tamil Nadu",
    "relation": "0"
  },
  {
    "code": "59",
    "type": "STATE",
    "name": "UP",
    "value": "UP",
    "relation": "0"
  },
  {
    "code": "60",
    "type": "STATE",
    "name": "Himachal Pradesh",
    "value": "Himachal Pradesh",
    "relation": "0"
  },
  {
    "code": "61",
    "type": "STATE",
    "name": "Gujrat",
    "value": "Gujrat",
    "relation": "0"
  },
  {
    "code": "62",
    "type": "CITY",
    "name": "Bangalore",
    "value": "Bangalore",
    "relation": "57"
  },
  {
    "code": "63",
    "type": "CITY",
    "name": "Mysore",
    "value": "Mysore",
    "relation": "57"
  },
  {
    "code": "64",
    "type": "CITY",
    "name": "Bellary",
    "value": "Bellary",
    "relation": "57"
  },
  {
    "code": "65",
    "type": "CITY",
    "name": "Mangalore",
    "value": "Mangalore",
    "relation": "57"
  },
  {
    "code": "66",
    "type": "CITY",
    "name": "Dharwad",
    "value": "Dharwad",
    "relation": "57"
  },
  {
    "code": "67",
    "type": "CITY",
    "name": "Chennai",
    "value": "Chennai",
    "relation": "58"
  },
  {
    "code": "68",
    "type": "CITY",
    "name": "Coimbatore",
    "value": "Coimbatore",
    "relation": "58"
  },
  {
    "code": "69",
    "type": "CITY",
    "name": "Madurai",
    "value": "Madurai",
    "relation": "58"
  },
  {
    "code": "70",
    "type": "CITY",
    "name": "Tiruchirappalli",
    "value": "Tiruchirappalli",
    "relation": "58"
  },
  {
    "code": "71",
    "type": "CITY",
    "name": "Kumbakonam",
    "value": "Kumbakonam",
    "relation": "58"
  },
  {
    "code": "72",
    "type": "CITY",
    "name": "Lucknow",
    "value": "Lucknow",
    "relation": "59"
  },
  {
    "code": "73",
    "type": "CITY",
    "name": "Kanpur",
    "value": "Kanpur",
    "relation": "59"
  },
  {
    "code": "74",
    "type": "CITY",
    "name": "Varanasi",
    "value": "Varanasi",
    "relation": "59"
  },
  {
    "code": "75",
    "type": "CITY",
    "name": "Allahabad",
    "value": "Allahabad",
    "relation": "59"
  },
  {
    "code": "76",
    "type": "CITY",
    "name": "Jhansi",
    "value": "Jhansi",
    "relation": "59"
  },
  {
    "code": "77",
    "type": "CITY",
    "name": "Dharamsala",
    "value": "Dharamsala",
    "relation": "60"
  },
  {
    "code": "78",
    "type": "CITY",
    "name": "Shimla",
    "value": "Shimla",
    "relation": "60"
  },
  {
    "code": "79",
    "type": "CITY",
    "name": "Dalhousie",
    "value": "Dalhousie",
    "relation": "60"
  },
  {
    "code": "80",
    "type": "CITY",
    "name": "Kasauli",
    "value": "Kasauli",
    "relation": "60"
  },
  {
    "code": "81",
    "type": "CITY",
    "name": "Parwanoo",
    "value": "Parwanoo",
    "relation": "60"
  },
  {
    "code": "82",
    "type": "CITY",
    "name": "Vadodara",
    "value": "Vadodara",
    "relation": "61"
  },
  {
    "code": "83",
    "type": "CITY",
    "name": "Surat",
    "value": "Surat",
    "relation": "61"
  },
  {
    "code": "84",
    "type": "CITY",
    "name": "Gandhinagar",
    "value": "Gandhinagar",
    "relation": "61"
  },
  {
    "code": "85",
    "type": "CITY",
    "name": "Bhuj",
    "value": "Bhuj",
    "relation": "61"
  },
  {
    "code": "86",
    "type": "CITY",
    "name": "Jamnagar",
    "value": "Jamnagar",
    "relation": "61"
  },
  {
    "code": "87",
    "type": "LOCATION",
    "name": "BTM",
    "value": "BTM",
    "relation": "62"
  },
  {
    "code": "88",
    "type": "LOCATION",
    "name": "Koramangala",
    "value": "Koramangala",
    "relation": "62"
  },
  {
    "code": "89",
    "type": "LOCATION",
    "name": "Brindavan Gardens",
    "value": "Brindavan Gardens",
    "relation": "63"
  },
  {
    "code": "90",
    "type": "LOCATION",
    "name": "Mysore Palace",
    "value": "Mysore Palace",
    "relation": "63"
  },
  {
    "code": "91",
    "type": "LOCATION",
    "name": "Vijayanagara",
    "value": "Vijayanagara",
    "relation": "64"
  },
  {
    "code": "92",
    "type": "LOCATION",
    "name": "Royal Enclosures",
    "value": "Royal Enclosures",
    "relation": "64"
  },
  {
    "code": "93",
    "type": "LOCATION",
    "name": "Kenjar Airport Road",
    "value": "Kenjar Airport Road",
    "relation": "65"
  },
  {
    "code": "94",
    "type": "LOCATION",
    "name": "Benjana Padavu",
    "value": "Benjana Padavu",
    "relation": "65"
  },
  {
    "code": "95",
    "type": "LOCATION",
    "name": "Dhavalagiri, Khalgatgi Road",
    "value": "Dhavalagiri, Khalgatgi Road",
    "relation": "66"
  },
  {
    "code": "96",
    "type": "LOCATION",
    "name": "Kaveri nagar",
    "value": "Kaveri nagar",
    "relation": "66"
  },
  {
    "code": "97",
    "type": "LOCATION",
    "name": "Annanagar",
    "value": "Annanagar",
    "relation": "67"
  },
  {
    "code": "98",
    "type": "LOCATION",
    "name": "Alandur",
    "value": "Alandur",
    "relation": "67"
  },
  {
    "code": "99",
    "type": "LOCATION",
    "name": "Vattamalaipalayam",
    "value": "Vattamalaipalayam",
    "relation": "68"
  },
  {
    "code": "100",
    "type": "LOCATION",
    "name": "Avinashi road",
    "value": "Avinashi road",
    "relation": "68"
  },
  {
    "code": "101",
    "type": "LOCATION",
    "name": "GST road",
    "value": "GST road",
    "relation": "69"
  },
  {
    "code": "102",
    "type": "LOCATION",
    "name": "Viraganoor",
    "value": "Viraganoor",
    "relation": "69"
  },
  {
    "code": "103",
    "type": "LOCATION",
    "name": "Pudukottai",
    "value": "Pudukottai",
    "relation": "70"
  },
  {
    "code": "104",
    "type": "LOCATION",
    "name": "Piratiyur",
    "value": "Piratiyur",
    "relation": "70"
  },
  {
    "code": "105",
    "type": "LOCATION",
    "name": "Ammapettai",
    "value": "Ammapettai",
    "relation": "71"
  },
  {
    "code": "106",
    "type": "LOCATION",
    "name": "Anakudi road",
    "value": "Anakudi road",
    "relation": "71"
  },
  {
    "code": "107",
    "type": "LOCATION",
    "name": "Akhilesh das nagar",
    "value": "Akhilesh das nagar",
    "relation": "72"
  },
  {
    "code": "108",
    "type": "LOCATION",
    "name": "sitapur road",
    "value": "sitapur road",
    "relation": "72"
  },
  {
    "code": "109",
    "type": "LOCATION",
    "name": "Kalyanpur",
    "value": "Kalyanpur",
    "relation": "73"
  },
  {
    "code": "110",
    "type": "LOCATION",
    "name": "Shatabdi road",
    "value": "Shatabdi road",
    "relation": "73"
  },
  {
    "code": "111",
    "type": "LOCATION",
    "name": "Narayanpur",
    "value": "Narayanpur",
    "relation": "74"
  },
  {
    "code": "112",
    "type": "LOCATION",
    "name": "Suddhipur",
    "value": "Suddhipur",
    "relation": "74"
  },
  {
    "code": "113",
    "type": "LOCATION",
    "name": "Devghat",
    "value": "Devghat",
    "relation": "75"
  },
  {
    "code": "114",
    "type": "LOCATION",
    "name": "Teliyarghanj",
    "value": "Teliyarghanj",
    "relation": "75"
  },
  {
    "code": "115",
    "type": "LOCATION",
    "name": "Kanpur road",
    "value": "Kanpur road",
    "relation": "76"
  },
  {
    "code": "116",
    "type": "LOCATION",
    "name": "Bundelkhand",
    "value": "Bundelkhand",
    "relation": "76"
  },
  {
    "code": "117",
    "type": "LOCATION",
    "name": "Jawahar nagar",
    "value": "Jawahar nagar",
    "relation": "77"
  },
  {
    "code": "118",
    "type": "LOCATION",
    "name": "Mandi-Pathankot Road",
    "value": "Mandi-Pathankot Road",
    "relation": "77"
  },
  {
    "code": "119",
    "type": "LOCATION",
    "name": "Mehli-Shoghi Bypass Road",
    "value": "Mehli-Shoghi Bypass Road",
    "relation": "78"
  },
  {
    "code": "120",
    "type": "LOCATION",
    "name": "Pragati nagar",
    "value": "Pragati nagar",
    "relation": "78"
  },
  {
    "code": "121",
    "type": "LOCATION",
    "name": "Dalhousie road",
    "value": "Dalhousie road",
    "relation": "79"
  },
  {
    "code": "122",
    "type": "LOCATION",
    "name": "Ram nagar",
    "value": "Ram nagar",
    "relation": "79"
  },
  {
    "code": "123",
    "type": "LOCATION",
    "name": "Green Hills Engineering College Rd",
    "value": "Green Hills Engineering College Rd",
    "relation": "80"
  },
  {
    "code": "124",
    "type": "LOCATION",
    "name": "Nahan Road",
    "value": "Nahan Road",
    "relation": "80"
  },
  {
    "code": "125",
    "type": "LOCATION",
    "name": "Waknaghat",
    "value": "Waknaghat",
    "relation": "81"
  },
  {
    "code": "126",
    "type": "LOCATION",
    "name": "Rajgarh",
    "value": "Rajgarh",
    "relation": "81"
  },
  {
    "code": "127",
    "type": "LOCATION",
    "name": "Kotambi",
    "value": "Kotambi",
    "relation": "82"
  },
  {
    "code": "128",
    "type": "LOCATION",
    "name": "Ajwa road",
    "value": "Ajwa road",
    "relation": "82"
  },
  {
    "code": "129",
    "type": "LOCATION",
    "name": "Ichchhanath Circle",
    "value": "Ichchhanath Circle",
    "relation": "83"
  },
  {
    "code": "130",
    "type": "LOCATION",
    "name": "New city light road",
    "value": "New city light road",
    "relation": "83"
  },
  {
    "code": "131",
    "type": "LOCATION",
    "name": "Near GEB Cross Road",
    "value": "Near GEB Cross Road",
    "relation": "84"
  },
  {
    "code": "132",
    "type": "LOCATION",
    "name": "Indroda Circle",
    "value": "Indroda Circle",
    "relation": "84"
  },
  {
    "code": "133",
    "type": "LOCATION",
    "name": "Kargh road",
    "value": "Kargh road",
    "relation": "85"
  },
  {
    "code": "134",
    "type": "LOCATION",
    "name": "inter circle",
    "value": "inter circle",
    "relation": "85"
  },
  {
    "code": "135",
    "type": "LOCATION",
    "name": "Aliyabada road",
    "value": "Aliyabada road",
    "relation": "86"
  },
  {
    "code": "136",
    "type": "LOCATION",
    "name": "Polytechnic road",
    "value": "Polytechnic road",
    "relation": "86"
  }
]);

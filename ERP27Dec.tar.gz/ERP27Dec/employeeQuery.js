db.employeeDetails.insert([

{
	"generalInfo": {
		"id": "",
		"empCode": "14",
		"firstName": "chetan",
		"middleName": "kumar",
		"lastName": "pandey",
		"shortName": "chetan",
		"dob": "02-12-1992",
		"fatherName": "Arvind",
		"spouseName": "vtplhr",
		"mobile": "99809908",
		"gender": "Male",
		"Place of Birth": "",
		"Religion": "",
		"marritalStatus": "",
		"nationality": "",
		"caste": "",
		"languages": "hr",
		"motherTongue": "",
		"identificationMark": "",
		"bloodGroup": "",
		"weight": "",
		"height": "",
		"remarks": ""
	},
	"contactInfo": {
		"empCode": "",
		"landLine": "",
		"mobile1": "",
		"mobile2": "",
		"email": ""
	},
"bankDetails": {
		"bankIfsc": "",
		"bankAcc": "",
		"branchAddress": "",
		"salaryAcc": "Yes/No",
		"email": ""
	},
"jobDetails": [{
		"category": "",
		"department": "",
		"designation": "",
		"reportingManager": "Yes",
		"fromDate": "",
                "toDate": "",
		"relievingReason": "",
		"referredPersonName": "",
                "remarks": ""

	}],
"skills": ["","",""],
"experienceDetails": [{
		"companyName": "",
		"fromDate": "",
		"toDate": "",
		"experience": "",
		"designation": "",
                "relievingReason": "",
		"lastSalary": "",
		"duties": "",
                "achievement": "",
                "referencePerson": "",
		"address": "",
                "city": "",
		"state": "",
		"country":""
	}],

"addressDetails": [{
		"addressType": "",
		"address1": "",
		"address2": "",
		"city": "",
		"state": "",
                "country": "",
		"pincode": ""
		
	}],
"educationDetails": [{
		"courseCode": "",
		"course": "",
		"duration": "",
		"startDate": "",
		"endDate": "",
                "class": "",
		"percentage": "",
		"achievement": "",
                "universityName": "",
                "institutionName": "",
		"institutionAddress": "",
                "city": "",
		"state": "",
		"country":"",
               "pincode": "",
               "comments":""
	}],
"familyDetails": [{
		"firstName": "",
		"middleName": "",
		"lastName": "",
		"relation": "",
		"dob": "",
                "gender": "",
		"isDependent": "",
		"isEmployee": "",
                "pfNominee": "yes/no",
                "occupation": "",
		"remark": ""
                
	}],
"vehicleDetails": [{
		"vehicleType": "",
		"vehicleColor": "",
		"vehicleRegNo": "",
		"vehicleMake": "",
		"vehicleModel": "",
                "vehicleOwner": "",
		"vehicleDesc": "",
		"parkingStickerIssuedDate": "",
                "parkingStickerExpiryDate": "",
                "parkingSlot": ""
		
                
	}],

"identificationProofs": [{
		"type": "",
		"uniqueNumber": "",
		"issuedDate": "",
		"expiryDate": "",
		"issuedPlace": ""
                
	}],

"insuranceDetails": [{
		"policyNo": "",
		"policyName": "",
		"issuedDate": "",
		"expiryDate": "",
		"insuredAmount": "",
                "premiumAmount": "",
		"nomineeName": "",
		"salaryDeductible": "yes/no",
                "deductibleAmount": ""
                
	}],
"documentsDetails": [{
		"documentType": "",
		"documentDescription": ""
                
	}],

}

])


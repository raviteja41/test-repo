# -*- coding: utf-8 -*-
"""
Created on Fri Jan 06 17:01:40 2017

@author: Kshama Zingade
"""

import pandas as pd
import numpy as np
import xlwt 

#loading data from CSV file
healthdf = pd.read_csv('claims_data.csv')

print healthdf.head(4)

print healthdf.shape

s = pd.isnull(healthdf).any(axis=0)
nc = s.to_frame()
writer = pd.ExcelWriter('output3.xlsx',engine='xlsxwriter')


nc.to_excel(writer ,sheet_name='null_columns')
nc.to_excel(writer, sheet_name='nc2')


'''wb = xlwt.Workbook()
ws1 = wb.add_sheet('null_cols1')
ws2 =''' 

#checking for null valued columns and removing them
list_nc =[]        
for col in healthdf:
    print col
    s = healthdf[col].value_counts(dropna=False)
    if pd.isnull(s.axes).any():
        if s.loc[np.nan]==13541:
            list_nc.append(col)

print list_nc 
s1 = pd.DataFrame(list_nc)    
s1.to_excel(writer, sheet_name='empty_cols')
writer.save()



mod1_hdf = healthdf.drop(labels=list_nc, axis=1) 

print mod1_hdf.shape
'''s = healthdf['CARDType'].value_counts(dropna=False)
print s
l = np.asarray(s.axes)
if pd.isnull(s.axes).any():
    print s.loc[np.nan]'''



''' s = pd.DataFrame([1,2,3,4],columns = {'Numbers'})
print s
mod1_hdf = pd.concat([mod1_hdf,s], axis=1 )
print mod1_hdf.columns'''


#iterate through columns to find unique values and their number


unq_vals = pd.DataFrame()
unq_shape = pd.DataFrame()
unq_valc = pd.DataFrame()
for c in mod1_hdf:
    vc_2=pd.DataFrame()
    
    #create df of unique values
    unq_ar = mod1_hdf[c].unique()
    unq_ar = pd.DataFrame(unq_ar, columns={c})
    unq_vals = pd.concat([unq_vals, unq_ar], axis=1)
    
    #create df of the number of unique values
    unq_s_ar = mod1_hdf[c].unique().shape[0]
    unq_s_ar = pd.DataFrame([c, unq_s_ar])
    unq_shape = pd.concat([unq_shape, unq_s_ar], axis=1)
        
    #unq_ar = np.append(unq_ar, mod1_hdf[c].unique().shape)
    vc = mod1_hdf[c].value_counts(dropna=False)
    l1 = c
    l2 = c+'counts'
    vc_df = pd.DataFrame({l1:vc.index, l2:vc.values})
    unq_valc = pd.concat([unq_valc, vc_df], axis=1)
    
    

wr = pd.ExcelWriter('column_dets.xlsx', engine='xlsxwriter')
unq_vals.to_excel(wr, sheet_name='unique values')
unq_shape.to_excel(wr, sheet_name='shape')
unq_valc.to_excel(wr, sheet_name='value_counts')
wr.save()

print unq_shape 
    




''' pol_ar = mod1_hdf.PolicyNumber.unique()
pol_ar = np.append(mod1_hdf, mod1_hdf.PolicyNumber.unique().shape)
col_name = 'PolicyNumber'
s = pd.DataFrame(pol_ar, columns={col_name})
details = pd.concat([details, s], axis=1 )
print details 

# to get value counts properly
pns = mod1_hdf.PolicyNumber.value_counts(dropna=False)
pnvc_df = pd.DataFrame({'a_values':pns.index, 'counts':pns.values},)
print pnvc_df

print mod1_hdf.PolicyNumber.uni

#converting single no. to dataframe
col = 'no.'
df = pd.DataFrame(['no.', 2])
print df'''

l1 = 's'
l2 = 'v'
df = pd.DataFrame({l1:[1,2,3],l2:[2,3,4]})
print df
print mod1_hdf.PolicyNumber.unique().shape[0]